import { StudentUser, FeePaymentRecord, PaymentSettings } from '../types';

export interface MonthInfo {
  currentMonthEn: string;
  previousMonthEn: string;
  currentMonthBn: string;
  previousMonthBn: string;
  dayOfMonth: number;
  isPrimaryDueDays: boolean; // 1st or 2nd of the month
  isFirstWeek: boolean;      // 1st to 7th of the month
  formattedDueRangeBn: string;
  formattedDueRangeEn: string;
}

const BENGALI_MONTHS = [
  'জানুয়ারি',
  'ফেব্রুয়ারি',
  'মার্চ',
  'এপ্রিল',
  'মে',
  'জুন',
  'জুলাই',
  'আগস্ট',
  'সেপ্টেম্বর',
  'অক্টোবর',
  'নভেম্বর',
  'ডিসেম্বর',
];

const ENGLISH_MONTHS = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

/**
 * Calculates month names, day of the month, and fee payment periods
 */
export function getMonthInfo(simulatedDate?: Date): MonthInfo {
  const d = simulatedDate || new Date();
  const currentMonthIdx = d.getMonth();
  const currentYear = d.getFullYear();
  const dayOfMonth = d.getDate();

  const prevDate = new Date(currentYear, currentMonthIdx - 1, 1);
  const prevMonthIdx = prevDate.getMonth();
  const prevYear = prevDate.getFullYear();

  const currentMonthEn = `${ENGLISH_MONTHS[currentMonthIdx]} ${currentYear}`;
  const previousMonthEn = `${ENGLISH_MONTHS[prevMonthIdx]} ${prevYear}`;
  const currentMonthBn = `${BENGALI_MONTHS[currentMonthIdx]} ${currentYear}`;
  const previousMonthBn = `${BENGALI_MONTHS[prevMonthIdx]} ${prevYear}`;

  const isPrimaryDueDays = dayOfMonth >= 1 && dayOfMonth <= 2;
  const isFirstWeek = dayOfMonth >= 1 && dayOfMonth <= 7;

  return {
    currentMonthEn,
    previousMonthEn,
    currentMonthBn,
    previousMonthBn,
    dayOfMonth,
    isPrimaryDueDays,
    isFirstWeek,
    formattedDueRangeBn: `১লা ও ২রা ${currentMonthBn}`,
    formattedDueRangeEn: `1st & 2nd ${currentMonthEn}`,
  };
}

export interface StudentFeeStatus {
  student: StudentUser;
  monthInfo: MonthInfo;
  previousMonthPayment?: FeePaymentRecord;
  status: 'PAID' | 'PENDING_APPROVAL' | 'UNPAID';
  amountDue: number;
  isReminderActive: boolean; // Whether the in-app popup or urgent banner should trigger
}

/**
 * Evaluates whether a student has cleared previous month's tuition fee
 */
export function evaluateStudentFeeStatus(
  student: StudentUser,
  feePayments: FeePaymentRecord[],
  paymentSettings: PaymentSettings,
  forceTestMode = false
): StudentFeeStatus {
  // Use simulated date if test mode is active or configured in settings
  const isTesting = forceTestMode || paymentSettings.autoReminder?.simulateDuePeriodForTesting;
  
  // When testing, simulate 1st of current month
  const dateToUse = isTesting ? new Date(new Date().getFullYear(), new Date().getMonth(), 1) : new Date();
  const monthInfo = getMonthInfo(dateToUse);

  // Match previous month's record (case-insensitive search)
  const prevMonthTarget = monthInfo.previousMonthEn.toLowerCase().trim();

  const relevantPayment = feePayments.find((p) => {
    const isSameStudent =
      p.studentId === student.id ||
      p.studentRoll.toLowerCase() === student.rollNumber.toLowerCase() ||
      (p.studentPhone && student.phone && p.studentPhone.slice(-10) === student.phone.slice(-10));

    if (!isSameStudent) return false;

    const pMonth = (p.month || '').toLowerCase().trim();
    return pMonth.includes(prevMonthTarget) || prevMonthTarget.includes(pMonth);
  });

  // Calculate amount due based on class
  const isHigherSec =
    student.classLevel.includes('11') ||
    student.classLevel.includes('12') ||
    student.classLevel.includes('একাদশ') ||
    student.classLevel.includes('দ্বাদশ');

  const amountDue = isHigherSec
    ? paymentSettings.classFeeStructure.class11And12 || 600
    : paymentSettings.classFeeStructure.class9And10 || 500;

  let status: 'PAID' | 'PENDING_APPROVAL' | 'UNPAID' = 'UNPAID';

  // Check if admin manually marked the previous month as paid in paidMonths tracking
  const isMarkedPaidInRoster = student.paidMonths?.some((m) => {
    const cleanM = m.toLowerCase().trim();
    return cleanM.includes(prevMonthTarget) || prevMonthTarget.includes(cleanM);
  });

  if (isMarkedPaidInRoster) {
    status = 'PAID';
  } else if (relevantPayment) {
    if (relevantPayment.status === 'APPROVED') {
      status = 'PAID';
    } else if (relevantPayment.status === 'PENDING') {
      status = 'PENDING_APPROVAL';
    }
  }

  // Reminder is active if enabled and student is UNPAID (and currently within due period or test mode)
  const isWindowActive = isTesting || monthInfo.isFirstWeek;
  const isReminderActive = (paymentSettings.autoReminder?.enabled ?? true) && status === 'UNPAID' && isWindowActive;

  return {
    student,
    monthInfo,
    previousMonthPayment: relevantPayment,
    status,
    amountDue,
    isReminderActive,
  };
}

/**
 * Builds the Option B polite yet firm WhatsApp/SMS message text
 */
export function buildReminderMessage(
  student: StudentUser,
  feeStatus: StudentFeeStatus,
  paymentSettings: PaymentSettings,
  language: 'bn' | 'en' = 'bn'
): string {
  const { monthInfo, amountDue } = feeStatus;
  const upiId = paymentSettings.upiId;

  if (language === 'bn') {
    return `নমস্কার,
ভূগোল দিশারী (নারায়ণ স্যার)-এর পক্ষ থেকে শ্রদ্ধাপূর্ণ শুভেচ্ছা।

শিক্ষার্থী: ${student.name} (রোল: ${student.rollNumber}, শ্রেণি: ${student.classLevel})

পূর্ববর্তী মাস (${monthInfo.previousMonthBn})-এর মাসিক টিউশন ফি চলতি মাসের ১লা ও ২রা তারিখ (${monthInfo.currentMonthBn}-এর ১ ও ২ তারিখ)-এর মধ্যে পরিশোধের জন্য বিনীত অনুরোধ জানানো হচ্ছে।

📌 পেমেন্ট তথ্য:
• UPI ID: ${upiId}
• টাকার পরিমাণ: ₹${amountDue}
• প্রদেয় সময়সীমা: ${monthInfo.formattedDueRangeBn}

পেমেন্ট সম্পন্ন করে অনুগ্রহ করে অ্যাপের 'Fees Payment' অপশনে ১২ ডিজিটের UTR ট্রানজ্যাকশন নম্বর জমা দিন অথবা এই নম্বরে স্ক্রিনশট পাঠান।

সময়মতো ফি পরিশোধের মাধ্যমে নিরবচ্ছিন্ন পঠনপাঠন বজায় রাখতে সাহায্য করুন।
— নারায়ণ স্যার (ভূগোল দিশারী)`;
  }

  return `Dear Student / Parents,

Greetings from Bhugol Dishari (Narayan Sir).

Student: ${student.name} (Class: ${student.classLevel}, Roll: ${student.rollNumber})

This is a friendly reminder that the tuition fee for the previous month (${monthInfo.previousMonthEn}) is due for payment between the 1st and 2nd of ${monthInfo.currentMonthEn}.

📌 Payment Details:
• UPI ID: ${upiId}
• Amount: ₹${amountDue}
• Due Window: ${monthInfo.formattedDueRangeEn}

Kindly submit your 12-digit UTR reference number on the Bhugol Dishari app or share the payment screenshot once completed. Thank you for your continued cooperation.

— Narayan Sir
Bhugol Dishari`;
}

/**
 * Creates direct WhatsApp link with prefilled reminder message
 */
export function createWhatsAppReminderLink(
  phone: string,
  message: string
): string {
  // Strip non-digit characters
  let cleanPhone = phone.replace(/[^0-9]/g, '');
  if (cleanPhone.length === 10) {
    cleanPhone = '91' + cleanPhone;
  }
  return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
}

export const ACADEMIC_MONTHS_2026 = [
  'January 2026',
  'February 2026',
  'March 2026',
  'April 2026',
  'May 2026',
  'June 2026',
  'July 2026',
  'August 2026',
  'September 2026',
  'October 2026',
  'November 2026',
  'December 2026',
];

export const ACADEMIC_MONTHS_BN_MAP: Record<string, string> = {
  'January 2026': 'জানুয়ারি ২০২৬',
  'February 2026': 'ফেব্রুয়ারি ২০২৬',
  'March 2026': 'মার্চ ২০২৬',
  'April 2026': 'এপ্রিল ২০২৬',
  'May 2026': 'মে ২০২৬',
  'June 2026': 'জুন ২০২৬',
  'July 2026': 'জুলাই ২০২৬',
  'August 2026': 'আগস্ট ২০২৬',
  'September 2026': 'সেপ্টেম্বর ২০২৬',
  'October 2026': 'অক্টোবর ২০২৬',
  'November 2026': 'নভেম্বর ২০২৬',
  'December 2026': 'ডিসেম্বর ২০২৬',
};

export function isMonthPaidForStudent(
  student: StudentUser,
  feePayments: FeePaymentRecord[],
  monthName: string
): boolean {
  const cleanTarget = monthName.toLowerCase().trim();
  
  // 1. Check in student.paidMonths array
  if (student.paidMonths?.some((m) => m.toLowerCase().trim().includes(cleanTarget) || cleanTarget.includes(m.toLowerCase().trim()))) {
    return true;
  }

  // 2. Check approved fee payment records
  return feePayments.some((p) => {
    const isSameStudent =
      p.studentId === student.id ||
      p.studentRoll.toLowerCase() === student.rollNumber.toLowerCase() ||
      (p.studentPhone && student.phone && p.studentPhone.slice(-10) === student.phone.slice(-10));
    if (!isSameStudent || p.status !== 'APPROVED') return false;
    const pMonth = (p.month || '').toLowerCase().trim();
    return pMonth.includes(cleanTarget) || cleanTarget.includes(pMonth);
  });
}
