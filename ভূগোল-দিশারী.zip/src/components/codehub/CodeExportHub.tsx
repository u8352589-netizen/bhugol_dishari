import React, { useState } from 'react';
import {
  Code2,
  FileText,
  Copy,
  Check,
  Download,
  FolderTree,
  Terminal,
  Shield,
  Smartphone,
  Layers,
  Sparkles,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const CodeExportHub: React.FC = () => {
  const { showToast } = useApp();
  const [activeTab, setActiveTab] = useState<
    | 'pubspec'
    | 'notes_pin'
    | 'recording'
    | 'home'
    | 'rules'
    | 'fcm'
    | 'tests'
    | 'deployment'
    | 'structure'
  >('notes_pin');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    showToast('কোড কপি হয়েছে', `${key} ক্লিপবোর্ডে কপি করা হয়েছে`, 'success');
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const codeSnippets = {
    pubspec: `name: bhugol_dishari
description: "ভূগোল দিশারী (Bhugol Dishari) - ভূগোল মানেই নারায়ণ স্যার (Android Study App)"
publish_to: 'none'
version: 2.4.0+24

environment:
  sdk: '>=3.2.0 <4.0.0'
  flutter: ">=3.16.0"

dependencies:
  flutter:
    sdk: flutter
  
  # Firebase Production Ecosystem
  firebase_core: ^2.24.2
  firebase_auth: ^4.16.0
  cloud_firestore: ^4.14.0
  firebase_messaging: ^14.7.10
  firebase_storage: ^11.6.0
  
  # State Management & DI
  flutter_riverpod: ^2.4.9
  
  # UI, Animation & Bengali Typography
  google_fonts: ^6.1.0
  carousel_slider: ^4.2.1
  cached_network_image: ^3.3.1
  flutter_spinkit: ^5.2.0
  shimmer: ^3.0.0
  
  # 4-Digit Security Code & PIN Input
  pinput: ^3.0.1
  
  # Video, Drive PDF & URL Launching
  url_launcher: ^6.2.2
  chewie: ^1.7.4
  video_player: ^2.8.2
  
  # Local Storage & Notifications
  shared_preferences: ^2.2.2
  flutter_local_notifications: ^16.3.1
  intl: ^0.19.0
  dio: ^5.4.0
  path_provider: ^2.1.2

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^3.0.1
  mockito: ^5.4.4
  build_runner: ^2.4.8

flutter:
  uses-material-design: true
  assets:
    - assets/images/
    - assets/icons/`,

    notes_pin: `// lib/features/notes/screens/notes_pdf_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:pinput/pinput.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class NotesPdfScreen extends ConsumerStatefulWidget {
  const NotesPdfScreen({Key? key}) : super(key: key);

  @override
  ConsumerState<NotesPdfScreen> createState() => _NotesPdfScreenState();
}

class _NotesPdfScreenState extends ConsumerState<NotesPdfScreen> {
  String _selectedClassLevel = 'Class 10';
  final Set<String> _unlockedClasses = {};

  final List<String> _classes = ['Class 9', 'Class 10', 'Class 11', 'Class 12'];

  void _showPinDialog(String classLevel, String expectedPin) {
    final pinController = TextEditingController();

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          title: Row(
            children: [
              const Icon(Icons.lock_rounded, color: Colors.orange, size: 28),
              const SizedBox(width: 8),
              Text(
                '$classLevel সিকিউরিটি কোড',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'এই ক্লাসের সমস্ত অধ্যায়ের রঙিন PDF নোটস অ্যাক্সেস করতে নারায়ণ স্যারের ৪ ডিজিট কোড লিখুন।',
                style: TextStyle(fontSize: 13, color: Colors.grey.shade700),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              Pinput(
                length: 4,
                controller: pinController,
                obscureText: true,
                autofocus: true,
                onCompleted: (pin) {
                  if (pin == expectedPin) {
                    setState(() {
                      _unlockedClasses.add(classLevel);
                    });
                    Navigator.of(ctx).pop();
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('$classLevel নোটস আনলক হয়েছে!'),
                        backgroundColor: Colors.green,
                      ),
                    );
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('ভুল সিকিউরিটি কোড! নারায়ণ স্যারের সাথে যোগাযোগ করুন।'),
                        backgroundColor: Colors.red,
                      ),
                    );
                    pinController.clear();
                  }
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: const Text('বাতিল করুন'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _openDrivePdf(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Notes (PDF) স্পেশাল মডিউল',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color(0xFFD97706),
        elevation: 1,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('class_notes').snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final sections = snapshot.data!.docs;
          final currentDoc = sections.firstWhere(
            (d) => d['classLevel'] == _selectedClassLevel,
            orElse: () => sections.first,
          );
          final String expectedPin = currentDoc['securityCode'] ?? '2010';
          final List chapters = currentDoc['chapters'] ?? [];
          final bool isUnlocked = _unlockedClasses.contains(_selectedClassLevel);

          return Column(
            children: [
              // Sequential Class Hierarchy Tabs
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                color: Colors.grey.shade100,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: _classes.map((cls) {
                    final isSelected = _selectedClassLevel == cls;
                    final unlocked = _unlockedClasses.contains(cls);

                    return ChoiceChip(
                      label: Row(
                        children: [
                          Icon(
                            unlocked ? Icons.lock_open : Icons.lock,
                            size: 14,
                            color: isSelected ? Colors.white : Colors.amber.shade900,
                          ),
                          const SizedBox(width: 4),
                          Text(cls),
                        ],
                      ),
                      selected: isSelected,
                      selectedColor: const Color(0xFFD97706),
                      onSelected: (val) {
                        setState(() {
                          _selectedClassLevel = cls;
                        });
                        if (!unlocked) {
                          _showPinDialog(cls, expectedPin);
                        }
                      },
                    );
                  }).toList(),
                ),
              ),

              // Unlocked Chapter Cards or Lock Wall
              Expanded(
                child: isUnlocked
                    ? ListView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: chapters.length,
                        itemBuilder: (ctx, idx) {
                          final ch = chapters[idx];
                          return Card(
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                            elevation: 2,
                            margin: const EdgeInsets.only(bottom: 12),
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      CircleAvatar(
                                        backgroundColor: Colors.amber.shade100,
                                        child: Text(
                                          '\${ch['chapterNumber']}',
                                          style: const TextStyle(
                                            color: Colors.brown,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                      const SizedBox(width: 12),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              ch['chapterName'] ?? '',
                                              style: const TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 15,
                                              ),
                                            ),
                                            Text(
                                              '\${ch['totalPages']} পৃষ্ঠা • \${ch['fileSize']}',
                                              style: TextStyle(
                                                fontSize: 12,
                                                color: Colors.grey.shade600,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 12),
                                  ElevatedButton.icon(
                                    onPressed: () => _openDrivePdf(ch['drivePdfUrl']),
                                    icon: const Icon(Icons.open_in_new),
                                    label: const Text('গুগল ড্রাইভ PDF খুলুন'),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: const Color(0xFFD97706),
                                      foregroundColor: Colors.white,
                                      minimumSize: const Size.fromHeight(40),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      )
                    : Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(Icons.lock_person_rounded, size: 64, color: Colors.orange),
                            const SizedBox(height: 12),
                            Text(
                              '$_selectedClassLevel এর নোটস লক করা আছে',
                              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                            ),
                            const SizedBox(height: 8),
                            ElevatedButton(
                              onPressed: () => _showPinDialog(_selectedClassLevel, expectedPin),
                              child: const Text('৪ ডিজিট পিন দিয়ে আনলক করুন'),
                            ),
                          ],
                        ),
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}`,

    recording: `// lib/features/recording/screens/recording_class_screen.dart
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:url_launcher/url_launcher.dart';

class RecordingClassScreen extends StatefulWidget {
  const RecordingClassScreen({Key? key}) : super(key: key);

  @override
  State<RecordingClassScreen> createState() => _RecordingClassScreenState();
}

class _RecordingClassScreenState extends State<RecordingClassScreen> {
  String _filterClass = 'All';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Recording Class (ভিডিও লেকচার)'),
        backgroundColor: const Color(0xFF059669),
      ),
      body: Column(
        children: [
          // Class Filters
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(
              children: ['All', 'Class 9', 'Class 10', 'Class 11', 'Class 12'].map((cls) {
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: FilterChip(
                    label: Text(cls == 'All' ? 'সকল ক্লাস' : cls),
                    selected: _filterClass == cls,
                    onSelected: (val) {
                      setState(() => _filterClass = cls);
                    },
                  ),
                );
              }).toList(),
            ),
          ),

          // Video Lecture Stream
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance.collection('recordings').snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                final docs = snapshot.data!.docs.where((doc) {
                  if (_filterClass == 'All') return true;
                  return doc['classLevel'] == _filterClass;
                }).toList();

                return ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: docs.length,
                  itemBuilder: (ctx, idx) {
                    final item = docs[idx];
                    return Card(
                      clipBehavior: Clip.antiAlias,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      margin: const EdgeInsets.only(bottom: 12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Stack(
                            alignment: Alignment.center,
                            children: [
                              Image.network(
                                item['thumbnailUrl'],
                                height: 180,
                                width: double.infinity,
                                fit: BoxFit.cover,
                              ),
                              const CircleAvatar(
                                radius: 26,
                                backgroundColor: Colors.black54,
                                child: Icon(Icons.play_arrow, color: Colors.white, size: 32),
                              ),
                              Positioned(
                                bottom: 8,
                                right: 8,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: Colors.black87,
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Text(
                                    item['duration'] ?? '1h',
                                    style: const TextStyle(color: Colors.white, fontSize: 11),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Padding(
                            padding: const EdgeInsets.all(12),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  item['title'],
                                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  'টপিক: \${item['topic']} • \${item['classLevel']}',
                                  style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}`,

    home: `// lib/features/home/screens/student_home_screen.dart
import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../widgets/action_cards_grid.dart';
import '../widgets/notice_board_widget.dart';
import '../widgets/testimonials_widget.dart';

class StudentHomeScreen extends StatelessWidget {
  const StudentHomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF0288D1),
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'ভূগোল দিশারী (নারায়ণ স্যার)',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            Text(
              'ভূগোল মানেই নারায়ণ স্যার',
              style: TextStyle(fontSize: 11, color: Colors.white70),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_active_outlined),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Promotional Banner Slider (Firestore Managed, Max 5)
            StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('banners')
                  .where('active', isEqualTo: true)
                  .orderBy('order')
                  .limit(5)
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return const SizedBox(height: 180);
                }

                final banners = snapshot.data!.docs;

                return CarouselSlider.builder(
                  itemCount: banners.length,
                  itemBuilder: (ctx, idx, realIdx) {
                    final b = banners[idx];
                    return Container(
                      margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        image: DecorationImage(
                          image: NetworkImage(b['imageUrl']),
                          fit: BoxFit.cover,
                        ),
                      ),
                    );
                  },
                  options: CarouselOptions(
                    height: 180,
                    autoPlay: true,
                    autoPlayInterval: const Duration(seconds: 4),
                    enlargeCenterPage: true,
                  ),
                );
              },
            ),

            // 4 Action Cards Matching Screenshot 1
            const ActionCardsGrid(),

            // Live Real-Time Notice Board
            const NoticeBoardWidget(),

            // Student Testimonials
            const TestimonialsWidget(),
          ],
        ),
      ),
    );
  }
}`,

    rules: `// firestore.rules
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Check if user is Super Admin (Narayan Sir)
    function isAdmin() {
      return request.auth != null && 
        (request.auth.token.admin == true || 
         request.auth.token.email == 'narayansir.bhugol@gmail.com');
    }
    
    // Check if user is authenticated student
    function isStudent() {
      return request.auth != null;
    }

    // Promotional Banners: Public read, Admin write
    match /banners/{bannerId} {
      allow read: if true;
      allow write: if isAdmin();
    }

    // Recordings: Enrolled students read, Admin write
    match /recordings/{recordingId} {
      allow read: if isStudent();
      allow write: if isAdmin();
    }

    // Notes & 4-Digit Security Codes:
    // Students can read chapters; security codes strictly checked
    match /class_notes/{classId} {
      allow read: if isStudent();
      allow write: if isAdmin();
    }

    // Broadcast Notices: Public read, Admin write
    match /notices/{noticeId} {
      allow read: if true;
      allow write: if isAdmin();
    }

    // Fee Payments: Students can create and view own payments; Admin can approve/reject
    match /fee_payments/{paymentId} {
      allow create: if isStudent();
      allow read: if isAdmin() || (isStudent() && resource.data.studentId == request.auth.uid);
      allow update, delete: if isAdmin();
    }

    // Daily Attendance: Students read own; Admin write
    match /attendance/{attendanceId} {
      allow read: if isStudent();
      allow write: if isAdmin();
    }
  }
}`,

    fcm: `// lib/core/services/fcm_service.dart
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class FCMService {
  static final FirebaseMessaging _messaging = FirebaseMessaging.instance;
  static final FlutterLocalNotificationsPlugin _localPlugin =
      FlutterLocalNotificationsPlugin();

  static Future<void> initialize() async {
    // Request notification permission
    NotificationSettings settings = await _messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    // Setup Local Notification Channel for Android
    const AndroidNotificationChannel channel = AndroidNotificationChannel(
      'bhugol_dishari_urgent',
      'ভূগোল দিশারী নোটিশ ও ক্লাস অ্যালার্ট',
      importance: Importance.max,
    );

    await _localPlugin
        .resolvePlatformInterface<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);

    // Subscribe to all-student broadcast topic
    await _messaging.subscribeToTopic('all_students');

    // Handle foreground FCM notifications
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      RemoteNotification? notification = message.notification;
      if (notification != null) {
        _localPlugin.show(
          notification.hashCode,
          notification.title,
          notification.body,
          NotificationDetails(
            android: AndroidNotificationDetails(
              channel.id,
              channel.name,
              icon: '@mipmap/ic_launcher',
            ),
          ),
        );
      }
    });
  }
}`,

    tests: `// test/unit_test.dart
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('ভূগোল দিশারী (Bhugol Dishari) Security & Business Logic Tests', () {
    test('4-Digit Security Code validation logic', () {
      const String correctCode = '2010';
      
      expect(correctCode.length, 4);
      expect(RegExp(r'^[0-9]{4}$').hasMatch(correctCode), isTrue);
      expect('1234' == correctCode, isFalse);
      expect('2010' == correctCode, isTrue);
    });

    test('Promotional Banner Limit constraint (Max 5)', () {
      final List<String> banners = ['B1', 'B2', 'B3', 'B4', 'B5'];
      expect(banners.length, lessThanOrEqualTo(5));
    });

    test('12-Digit UPI UTR Validation for Fee Payments', () {
      final String utr = '626104899201';
      expect(utr.length, 12);
      expect(RegExp(r'^[0-9]+$').hasMatch(utr), isTrue);
    });
  });
}`,

    deployment: `# ভূগোল দিশারী (Bhugol Dishari) Production Deployment Guide

## 1. Android Google Play Store Deployment (AAB)

### Generate Production Keystore:
\`\`\`bash
keytool -genkey -v -keystore android/upload-keystore.jks \\
  -keyalg RSA -keysize 2048 -validity 10000 \\
  -alias bhugol_dishari_key
\`\`\`

### Create \`android/key.properties\`:
\`\`\`properties
storePassword=YOUR_SECURE_PASSWORD
keyPassword=YOUR_SECURE_PASSWORD
keyAlias=bhugol_dishari_key
storeFile=../upload-keystore.jks
\`\`\`

### Build Production Android App Bundle:
\`\`\`bash
flutter clean
flutter pub get
flutter build appbundle --release --obfuscate --split-debug-info=./symbols
\`\`\`
Output file: \`build/app/outputs/bundle/release/app-release.aab\`

---

## 2. iOS App Store / TestFlight Deployment

\`\`\`bash
flutter build ipa --release
xcrun altool --upload-app --type ios -f build/ios/ipa/*.ipa --apiKey YOUR_KEY_ID --apiIssuer YOUR_ISSUER_ID
\`\`\`

---

## 3. Firebase Deployment

\`\`\`bash
firebase deploy --only firestore:rules,storage
\`\`\``,

    structure: `bhugol_dishari/
├── android/
│   ├── app/src/main/res/values/strings.xml ("ভূগোল দিশারী")
│   └── key.properties
├── ios/
├── lib/
│   ├── main.dart
│   ├── core/
│   │   ├── constants/
│   │   ├── services/fcm_service.dart
│   │   └── theme/app_theme.dart
│   ├── features/
│   │   ├── auth/
│   │   │   ├── screens/student_login_screen.dart
│   │   │   └── screens/admin_login_screen.dart
│   │   ├── home/
│   │   │   ├── screens/student_home_screen.dart
│   │   │   └── widgets/action_cards_grid.dart
│   │   ├── notes/
│   │   │   ├── screens/notes_pdf_screen.dart (4-Digit PIN Lock)
│   │   │   └── widgets/pin_dialog.dart
│   │   ├── recording/
│   │   │   └── screens/recording_class_screen.dart
│   │   ├── courses/
│   │   │   └── screens/course_screen.dart
│   │   ├── fees/
│   │   │   └── screens/fees_payment_screen.dart
│   │   └── profile/
│   │       └── screens/student_profile_screen.dart
│   └── data/
│       └── models/
├── test/
│   ├── unit_test.dart
│   └── widget_test.dart
├── pubspec.yaml
└── firestore.rules`,
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-slate-900 text-slate-100">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-sky-500/20 text-sky-300 border border-sky-500/30">
                Flutter 3.16+ & Firebase Ready
              </span>
              <span className="text-xs text-amber-400 font-semibold">Production Architecture</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white mt-1">
              ভূগোল দিশারী (Bhugol Dishari) Source Code Hub
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              সম্পূর্ণ ফ্ল্যাটার অ্যান্ড্রয়েড কোডবেস, ফায়ারবেস রুলস, টেস্ট স্যুট এবং রিলিজ নির্দেশিকা
            </p>
          </div>

          <button
            onClick={() => handleCopy(codeSnippets[activeTab], activeTab)}
            className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md transition-colors self-start"
          >
            {copiedKey === activeTab ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
            <span>{copiedKey === activeTab ? 'কপিকৃত!' : 'সম্পূর্ণ কোড কপি করুন'}</span>
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center space-x-1.5 overflow-x-auto pb-2 text-xs font-bold">
          <button
            onClick={() => setActiveTab('notes_pin')}
            className={`px-3 py-2 rounded-xl whitespace-nowrap transition-all flex items-center gap-1.5 ${
              activeTab === 'notes_pin'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
            }`}
          >
            <span>🔐 Notes PDF (4-Digit PIN)</span>
          </button>

          <button
            onClick={() => setActiveTab('recording')}
            className={`px-3 py-2 rounded-xl whitespace-nowrap transition-all flex items-center gap-1.5 ${
              activeTab === 'recording'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
            }`}
          >
            <span>▶ Recording Class Screen</span>
          </button>

          <button
            onClick={() => setActiveTab('home')}
            className={`px-3 py-2 rounded-xl whitespace-nowrap transition-all ${
              activeTab === 'home'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
            }`}
          >
            <span>📱 Home Screen (Flutter)</span>
          </button>

          <button
            onClick={() => setActiveTab('pubspec')}
            className={`px-3 py-2 rounded-xl whitespace-nowrap transition-all ${
              activeTab === 'pubspec'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
            }`}
          >
            <span>📦 pubspec.yaml</span>
          </button>

          <button
            onClick={() => setActiveTab('rules')}
            className={`px-3 py-2 rounded-xl whitespace-nowrap transition-all ${
              activeTab === 'rules'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
            }`}
          >
            <span>🛡️ firestore.rules</span>
          </button>

          <button
            onClick={() => setActiveTab('fcm')}
            className={`px-3 py-2 rounded-xl whitespace-nowrap transition-all ${
              activeTab === 'fcm'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
            }`}
          >
            <span>🔔 FCM Notifications</span>
          </button>

          <button
            onClick={() => setActiveTab('tests')}
            className={`px-3 py-2 rounded-xl whitespace-nowrap transition-all ${
              activeTab === 'tests'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
            }`}
          >
            <span>🧪 Unit Tests</span>
          </button>

          <button
            onClick={() => setActiveTab('deployment')}
            className={`px-3 py-2 rounded-xl whitespace-nowrap transition-all ${
              activeTab === 'deployment'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
            }`}
          >
            <span>🚀 Play Store Deployment</span>
          </button>

          <button
            onClick={() => setActiveTab('structure')}
            className={`px-3 py-2 rounded-xl whitespace-nowrap transition-all ${
              activeTab === 'structure'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
            }`}
          >
            <span>📂 Project Tree</span>
          </button>
        </div>

        {/* Code View Canvas */}
        <div className="rounded-2xl bg-slate-950 border border-slate-800 shadow-2xl overflow-hidden">
          <div className="p-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-xs text-slate-400 font-mono">
            <div className="flex items-center space-x-2">
              <span className="w-3 h-3 rounded-full bg-rose-500/80 inline-block" />
              <span className="w-3 h-3 rounded-full bg-amber-500/80 inline-block" />
              <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block" />
              <span className="text-slate-300 font-semibold ml-2">
                {activeTab === 'pubspec' && 'pubspec.yaml'}
                {activeTab === 'notes_pin' && 'lib/features/notes/screens/notes_pdf_screen.dart'}
                {activeTab === 'recording' && 'lib/features/recording/screens/recording_class_screen.dart'}
                {activeTab === 'home' && 'lib/features/home/screens/student_home_screen.dart'}
                {activeTab === 'rules' && 'firestore.rules'}
                {activeTab === 'fcm' && 'lib/core/services/fcm_service.dart'}
                {activeTab === 'tests' && 'test/unit_test.dart'}
                {activeTab === 'deployment' && 'DEPLOYMENT_GUIDE.md'}
                {activeTab === 'structure' && 'PROJECT_STRUCTURE.txt'}
              </span>
            </div>

            <button
              onClick={() => handleCopy(codeSnippets[activeTab], activeTab)}
              className="hover:text-white flex items-center gap-1 transition-colors"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>Copy</span>
            </button>
          </div>

          <pre className="p-4 sm:p-6 overflow-x-auto text-xs font-mono text-slate-200 leading-relaxed max-h-[560px]">
            <code>{codeSnippets[activeTab]}</code>
          </pre>
        </div>
      </div>
    </div>
  );
};
