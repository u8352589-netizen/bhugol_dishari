import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Users,
  CheckCircle2,
  XCircle,
  Clock,
  Calendar,
  Search,
  CheckCheck,
  TrendingUp,
} from 'lucide-react';

export const AttendanceManager: React.FC = () => {
  const { studentRoster, attendance, setStudentAttendance, showToast } = useApp();
  const [selectedClass, setSelectedClass] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const today = new Date().toISOString().split('T')[0];

  const filteredStudents = studentRoster.filter((s) => {
    const matchesClass = selectedClass === 'All' || s.classLevel === selectedClass;
    const matchesSearch =
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.rollNumber.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesClass && matchesSearch;
  });

  // Calculate attendance status for each student
  const getTodayStatus = (studentId: string) => {
    const record = attendance.find((a) => a.studentId === studentId && a.date === today);
    return record?.status || 'NOT_MARKED';
  };

  const presentCount = studentRoster.filter((s) => getTodayStatus(s.id) === 'PRESENT').length;
  const absentCount = studentRoster.filter((s) => getTodayStatus(s.id) === 'ABSENT').length;
  const lateCount = studentRoster.filter((s) => getTodayStatus(s.id) === 'LATE').length;

  const handleMarkAllPresent = () => {
    filteredStudents.forEach((s) => {
      setStudentAttendance(s.id, 'PRESENT', 'অনলাইন লাইভ ক্লাসে উপস্থিত');
    });
    showToast('উপস্থিতি সম্পন্ন', `${filteredStudents.length} জন ছাত্রকে উপস্থিত হিসেবে চিহ্নিত করা হলো`, 'success');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Users className="w-5 h-5 text-indigo-500" />
            <span>দৈনিক ডিজিটাল হাজিরা (Attendance Roll-Call Tool)</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            আজকের তারিখ: <span className="font-bold text-sky-600 dark:text-sky-400">{today}</span> • লাইভ ব্যাচভিত্তিক রোল-কল ও পরিসংখ্যান
          </p>
        </div>

        <button
          onClick={handleMarkAllPresent}
          className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition-all flex items-center gap-1.5 self-start active:scale-95"
        >
          <CheckCheck className="w-4 h-4" />
          <span>সকলকে উপস্থিত (Present) মার্ক করুন</span>
        </button>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs text-slate-500 font-medium">মোট ছাত্র তালিকা</span>
          <h4 className="text-xl font-black text-slate-900 dark:text-white mt-1">
            {studentRoster.length} জন
          </h4>
        </div>

        <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 shadow-xs">
          <span className="text-xs text-emerald-700 dark:text-emerald-300 font-semibold flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" /> উপস্থিত (Present)
          </span>
          <h4 className="text-xl font-black text-emerald-700 dark:text-emerald-300 mt-1">
            {presentCount} জন
          </h4>
        </div>

        <div className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800 shadow-xs">
          <span className="text-xs text-rose-700 dark:text-rose-300 font-semibold flex items-center gap-1">
            <XCircle className="w-3.5 h-3.5" /> অনুপস্থিত (Absent)
          </span>
          <h4 className="text-xl font-black text-rose-700 dark:text-rose-300 mt-1">
            {absentCount} জন
          </h4>
        </div>

        <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 shadow-xs">
          <span className="text-xs text-amber-700 dark:text-amber-300 font-semibold flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" /> দেরিতে উপস্থিত (Late)
          </span>
          <h4 className="text-xl font-black text-amber-700 dark:text-amber-300 mt-1">
            {lateCount} জন
          </h4>
        </div>
      </div>

      {/* Roster & Actions */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden">
        {/* Filter Bar */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            {['All', 'Class 10', 'Class 12', 'Class 11', 'Class 9'].map((cls) => (
              <button
                key={cls}
                onClick={() => setSelectedClass(cls)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                  selectedClass === cls
                    ? 'bg-sky-600 text-white shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                }`}
              >
                {cls === 'All' ? 'সকল ক্লাস' : cls}
              </button>
            ))}
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="রোল বা নাম খুঁজুন..."
              className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none"
            />
          </div>
        </div>

        {/* Student Roster Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="p-3.5 font-bold">রোল নম্বর</th>
                <th className="p-3.5 font-bold">ছাত্র/ছাত্রীর নাম</th>
                <th className="p-3.5 font-bold">শ্রেণি</th>
                <th className="p-3.5 font-bold">মোবাইল</th>
                <th className="p-3.5 font-bold text-center">আজকের হাজিরা স্থিতি</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredStudents.map((s) => {
                const status = getTodayStatus(s.id);
                return (
                  <tr key={s.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/50 transition-colors">
                    <td className="p-3.5 font-mono font-bold text-slate-700 dark:text-slate-300">
                      {s.rollNumber}
                    </td>
                    <td className="p-3.5">
                      <span className="font-bold text-slate-900 dark:text-white block">{s.name}</span>
                      <span className="text-[11px] text-slate-400">{s.about || 'নিয়মিত শিক্ষার্থী'}</span>
                    </td>
                    <td className="p-3.5">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300">
                        {s.classLevel}
                      </span>
                    </td>
                    <td className="p-3.5 font-mono text-slate-500">{s.phone}</td>
                    <td className="p-3.5">
                      <div className="flex items-center justify-center space-x-1.5">
                        <button
                          onClick={() => setStudentAttendance(s.id, 'PRESENT', 'নিয়মিত উপস্থিত')}
                          className={`px-3 py-1.5 rounded-xl font-bold text-xs transition-all ${
                            status === 'PRESENT'
                              ? 'bg-emerald-600 text-white shadow-xs'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-500 hover:bg-emerald-50 hover:text-emerald-700'
                          }`}
                        >
                          Present
                        </button>

                        <button
                          onClick={() => setStudentAttendance(s.id, 'LATE', '১৫ মিনিট দেরিতে যুক্ত হয়েছে')}
                          className={`px-3 py-1.5 rounded-xl font-bold text-xs transition-all ${
                            status === 'LATE'
                              ? 'bg-amber-500 text-slate-950 shadow-xs'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-500 hover:bg-amber-50 hover:text-amber-700'
                          }`}
                        >
                          Late
                        </button>

                        <button
                          onClick={() => setStudentAttendance(s.id, 'ABSENT', 'অনুপস্থিত')}
                          className={`px-3 py-1.5 rounded-xl font-bold text-xs transition-all ${
                            status === 'ABSENT'
                              ? 'bg-rose-600 text-white shadow-xs'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-500 hover:bg-rose-50 hover:text-rose-700'
                          }`}
                        >
                          Absent
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
