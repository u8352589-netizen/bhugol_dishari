import React, { useState } from 'react';
import {
  BellRing,
  Send,
  MessageCircle,
  Copy,
  CheckCircle2,
  AlertTriangle,
  Calendar,
  Sparkles,
  Users,
  Settings,
  Megaphone,
  ExternalLink,
  ShieldAlert,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import {
  evaluateStudentFeeStatus,
  buildReminderMessage,
  createWhatsAppReminderLink,
  getMonthInfo,
} from '../../utils/feeReminderUtils';

export const FeeAutoReminderHub: React.FC = () => {
  const {
    studentRoster,
    feePayments,
    paymentSettings,
    updatePaymentSettings,
    addNotice,
    showToast,
  } = useApp();

  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [selectedLanguage, setSelectedLanguage] = useState<'bn' | 'en'>('bn');

  const monthInfo = getMonthInfo();
  const autoSettings = paymentSettings.autoReminder;

  // Evaluate status for each registered student
  const studentStatuses = studentRoster.map((student) =>
    evaluateStudentFeeStatus(student, feePayments, paymentSettings)
  );

  const unpaidStudents = studentStatuses.filter((s) => s.status === 'UNPAID');
  const pendingStudents = studentStatuses.filter((s) => s.status === 'PENDING_APPROVAL');
  const paidStudents = studentStatuses.filter((s) => s.status === 'PAID');

  const handleCopyMessage = (studentId: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(studentId);
    showToast('কপি হয়েছে', 'হোয়াটসঅ্যাপ রিমাইন্ডার বার্তা ক্লিপবোর্ডে কপি করা হয়েছে', 'info');
    setTimeout(() => setCopiedId(null), 2500);
  };

  // Broadcast official notice to in-app notice board
  const handlePublishInAppNotice = () => {
    addNotice({
      title: `🔔 জরুরি ফি নোটিশ: ${monthInfo.previousMonthBn}-এর টিউশন ফি পরিশোধ (${monthInfo.formattedDueRangeBn})`,
      message: `সকল শিক্ষার্থী ও অভিভাবকদের জানানো যাচ্ছে যে, পূর্ববর্তী মাস (${monthInfo.previousMonthBn})-এর মাসিক টিউশন ফি চলতি মাসের ১লা ও ২রা তারিখের মধ্যে পরিশোধের জন্য অনুরোধ করা হচ্ছে। অনুগ্রহ করে অ্যাপের 'Fees Payment' অপশনে UPI স্ক্যানার ব্যবহার করে ফি প্রদান করুন এবং ১২ ডিজিটের UTR ট্রানজ্যাকশন নম্বর জমা দিন।`,
      priority: 'URGENT',
      targetBatch: 'All Batches (Class 9 - 12)',
      author: 'Narayan Sir (নারায়ণ স্যার)',
    });
    showToast(
      'নোটিশ জারি সম্পন্ন',
      'ইন-অ্যাপ নোটিশ বোর্ডে ১লা ও ২রা তারিখের ফি বিজ্ঞপ্তি প্রকাশিত হয়েছে',
      'success'
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Quick Controls */}
      <div className="p-5 rounded-3xl bg-gradient-to-r from-amber-500/15 via-orange-500/10 to-amber-600/15 border border-amber-500/30 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-500 text-slate-950 flex items-center justify-center font-black shadow-md shrink-0">
            <BellRing className="w-6 h-6 animate-bounce" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] font-black uppercase tracking-wider bg-amber-500 text-slate-950 px-2 py-0.5 rounded-full">
                অটোমেটিক ইন-অ্যাপ সিস্টেম
              </span>
              <span className="text-xs font-bold text-amber-700 dark:text-amber-300">
                পদ্ধতি নিয়ম: ১লা ও ২রা তারিখ
              </span>
            </div>
            <h3 className="text-lg font-black text-slate-900 dark:text-white mt-1">
              মাসিক ফি অটোমেটিক রিমাইন্ডার হাব
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
              পূর্ববর্তী মাস (<strong className="text-sky-600 dark:text-sky-400">{monthInfo.previousMonthBn}</strong>)-এর ফি সংগ্রহের স্বয়ংক্রিয় রুটিন ও হোয়াটসঅ্যাপ বার্তা ব্যবস্থা
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 self-start md:self-auto">
          {/* Toggle Simulated 1st-2nd Due Mode */}
          <button
            onClick={() => {
              const currentSim = autoSettings?.simulateDuePeriodForTesting ?? true;
              updatePaymentSettings({
                autoReminder: {
                  ...autoSettings,
                  simulateDuePeriodForTesting: !currentSim,
                },
              });
              showToast(
                'টেস্ট মোড সুইচ',
                !currentSim ? '১লা-২রা তারিখের ডিউ পিরিয়ড সিমুলেশন সক্রিয়' : 'লাইভ ক্যালেন্ডার ডেট সক্রিয়',
                'info'
              );
            }}
            className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs ${
              autoSettings?.simulateDuePeriodForTesting
                ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                : 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
            }`}
            title="লাইভ টেস্ট মোড অন/অফ করুন"
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>{autoSettings?.simulateDuePeriodForTesting ? '১লা-২রা তারিখ টেস্ট: সক্রিয়' : '১লা-২রা তারিখ টেস্ট: বন্ধ'}</span>
          </button>

          {/* 1-Click Broadcast Notice */}
          <button
            onClick={handlePublishInAppNotice}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-500 hover:to-blue-500 text-white text-xs font-black flex items-center gap-1.5 shadow-xs transition-transform active:scale-95"
          >
            <Megaphone className="w-3.5 h-3.5" />
            <span>ইন-অ্যাপ নোটিশ জারি করুন</span>
          </button>
        </div>
      </div>

      {/* 3 Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 block">
              বকেয়া শিক্ষার্থী (Unpaid)
            </span>
            <span className="text-2xl font-black text-rose-600 dark:text-rose-400 mt-1 block">
              {unpaidStudents.length} জন
            </span>
            <span className="text-[10px] text-slate-400">রিমাইন্ডার নোটিফিকেশন সচল</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-rose-500/15 text-rose-500 flex items-center justify-center font-bold">
            <AlertTriangle className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 block">
              যাচাই অপেক্ষমাণ (Pending UTR)
            </span>
            <span className="text-2xl font-black text-amber-500 mt-1 block">
              {pendingStudents.length} জন
            </span>
            <span className="text-[10px] text-slate-400">অ্যাডমিন অ্যাপ্রুভালের জন্য রেডি</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-500/15 text-amber-500 flex items-center justify-center font-bold">
            <Calendar className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 block">
              পরিশোধিত শিক্ষার্থী (Cleared)
            </span>
            <span className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1 block">
              {paidStudents.length} জন
            </span>
            <span className="text-[10px] text-slate-400">{monthInfo.previousMonthBn} মাস সম্পন্ন</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-500/15 text-emerald-500 flex items-center justify-center font-bold">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Unpaid Students Table & Quick WhatsApp Dispatch */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-rose-500/15 text-rose-500 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                বকেয়া শিক্ষার্থীদের তালিকা ({unpaidStudents.length} জন)
              </h4>
              <p className="text-[11px] text-slate-500">
                এদের ফোনে স্বয়ংক্রিয় ইন-অ্যাপ রিমাইন্ডার ভেসে উঠছে এবং নিচে ১-ক্লিকে হোয়াটসঅ্যাপ পাঠানো সম্ভব
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-1.5 p-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold">
            <button
              onClick={() => setSelectedLanguage('bn')}
              className={`px-3 py-1 rounded-lg transition-all ${
                selectedLanguage === 'bn'
                  ? 'bg-amber-500 text-slate-950 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              বাংলা বার্তা
            </button>
            <button
              onClick={() => setSelectedLanguage('en')}
              className={`px-3 py-1 rounded-lg transition-all ${
                selectedLanguage === 'en'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              English (Option B)
            </button>
          </div>
        </div>

        {unpaidStudents.length === 0 ? (
          <div className="p-8 text-center text-slate-500">
            <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
            <p className="font-bold text-sm text-slate-800 dark:text-slate-200">
              সকল শিক্ষার্থীর পূর্ববর্তী মাসের ফি পরিশোধিত রয়েছে!
            </p>
            <p className="text-xs text-slate-400 mt-1">কোনো বকেয়া শিক্ষার্থী নেই।</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {unpaidStudents.map((statusItem) => {
              const { student, amountDue } = statusItem;
              const msgText = buildReminderMessage(
                student,
                statusItem,
                paymentSettings,
                selectedLanguage
              );
              const waLink = createWhatsAppReminderLink(student.phone, msgText);
              const isCopied = copiedId === student.id;

              return (
                <div
                  key={student.id}
                  className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition-colors"
                >
                  <div className="flex items-start gap-3">
                    <img
                      src={student.avatarUrl}
                      alt={student.name}
                      className="w-10 h-10 rounded-xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                    />
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-sm text-slate-900 dark:text-white">
                          {student.name}
                        </span>
                        <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                          {student.rollNumber}
                        </span>
                        <span className="text-[11px] px-2 py-0.5 rounded bg-sky-50 dark:bg-sky-950 text-sky-600 dark:text-sky-300 border border-sky-200 dark:border-sky-800">
                          {student.classLevel}
                        </span>
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400 mt-1 flex items-center gap-3">
                        <span>ফোন: <strong className="font-mono text-slate-700 dark:text-slate-300">{student.phone}</strong></span>
                        <span>•</span>
                        <span>বকেয়া মাস: <strong className="text-sky-600 dark:text-sky-400">{monthInfo.previousMonthBn}</strong></span>
                        <span>•</span>
                        <span>পরিমাণ: <strong className="text-rose-600 dark:text-rose-400 font-bold">₹{amountDue}</strong></span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-start md:self-auto">
                    <button
                      onClick={() => handleCopyMessage(student.id, msgText)}
                      className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                      title="মেসেজ কপি করুন"
                    >
                      {isCopied ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                          <span>কপি হয়েছে</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5 text-slate-400" />
                          <span>কপি টেক্সট</span>
                        </>
                      )}
                    </button>

                    <a
                      href={waLink}
                      target="_blank"
                      rel="noreferrer"
                      className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition-transform active:scale-95"
                      title="সরাসরি হোয়াটসঅ্যাপে বার্তা পাঠান"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>WhatsApp পাঠান (Option B)</span>
                    </a>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Routine & Rules Quick Guide Card */}
      <div className="p-4 rounded-3xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700 text-xs space-y-2">
        <h5 className="font-black text-slate-800 dark:text-slate-200 flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-amber-500" />
          <span>টিউশন ফি রুটিন ও অটোমেশন নির্দেশিকা</span>
        </h5>
        <ul className="list-disc pl-5 space-y-1 text-slate-600 dark:text-slate-400">
          <li>
            <strong>১লা ও ২রা তারিখ:</strong> ছাত্রছাত্রী অ্যাপে প্রবেশ করলেই লাল/হলুদ ব্যানার ও ফি রিমাইন্ডার পপ-আপ স্বয়ংক্রিয়ভাবে তাদের সামনে ভেসে ওঠে।
          </li>
          <li>
            <strong>আগের মাসের ফি যাচাই:</strong> ছাত্রছাত্রী পূর্ববর্তী মাসের ফি জমা দিয়ে থাকলে পপ-আপ নিজে থেকেই বন্ধ হয়ে যায়।
          </li>
          <li>
            <strong>১-ক্লিক হোয়াটসঅ্যাপ:</strong> ওপরের প্রতিটি শিক্ষার্থীর পাশে দেওয়া <em>"WhatsApp পাঠান"</em> বাটনে ক্লিক করলে রেডিমেড Option B ফরম্যাটে মেসেজ তৈরি হয়ে যায়।
          </li>
        </ul>
      </div>
    </div>
  );
};
