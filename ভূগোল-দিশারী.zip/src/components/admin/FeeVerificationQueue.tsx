import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  CreditCard,
  CheckCircle2,
  XCircle,
  Clock,
  Eye,
  Search,
  Check,
  X,
  ExternalLink,
  ShieldCheck,
  AlertCircle,
  QrCode,
  ArrowRight,
  BellRing,
} from 'lucide-react';
import { FeePaymentRecord } from '../../types';

interface FeeVerificationQueueProps {
  onNavigateToSettings?: () => void;
  onNavigateToReminders?: () => void;
}

export const FeeVerificationQueue: React.FC<FeeVerificationQueueProps> = ({
  onNavigateToSettings,
  onNavigateToReminders,
}) => {
  const { feePayments, approvePayment, rejectPayment, showToast, paymentSettings } = useApp();
  const [filterStatus, setFilterStatus] = useState<'ALL' | 'PENDING' | 'APPROVED' | 'REJECTED'>('PENDING');
  const [selectedScreenshotUrl, setSelectedScreenshotUrl] = useState<string | null>(null);
  const [rejectingPaymentId, setRejectingPaymentId] = useState<string | null>(null);
  const [rejectionReason, setRejectionReason] = useState('UPI UTR স্টেটমেন্টে পাওয়া যায়নি');

  const filteredPayments = feePayments.filter((p) => {
    if (filterStatus === 'ALL') return true;
    return p.status === filterStatus;
  });

  const handleApprove = (payment: FeePaymentRecord) => {
    approvePayment(payment.id, 'Narayan Sir (Admin)');
  };

  const handleConfirmReject = (e: React.FormEvent) => {
    e.preventDefault();
    if (rejectingPaymentId) {
      rejectPayment(rejectingPaymentId, rejectionReason);
      setRejectingPaymentId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-amber-500" />
            <span>ফি পেমেন্ট ভেরিফিকেশন কিউ (Fee Verification Queue)</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            ছাত্রছাত্রীদের জমা দেওয়া ১২ ডিজিট UPI UTR নম্বর ও রসিদ যাচাই করে অনুমোদন বা বাতিল করুন
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {onNavigateToReminders && (
            <button
              onClick={onNavigateToReminders}
              className="px-3 py-1.5 rounded-xl bg-amber-50 dark:bg-amber-950/50 hover:bg-amber-100 dark:hover:bg-amber-900 text-amber-700 dark:text-amber-300 text-xs font-bold border border-amber-300 dark:border-amber-800 flex items-center gap-1.5 transition-all shadow-xs active:scale-95"
            >
              <BellRing className="w-3.5 h-3.5 text-amber-500" />
              <span>১লা-২রা তারিখ ফি রিমাইন্ডার হাব</span>
              <ArrowRight className="w-3 h-3 text-amber-500" />
            </button>
          )}

          {onNavigateToSettings && (
            <button
              onClick={onNavigateToSettings}
              className="px-3 py-1.5 rounded-xl bg-sky-50 dark:bg-sky-950/50 hover:bg-sky-100 dark:hover:bg-sky-900 text-sky-700 dark:text-sky-300 text-xs font-bold border border-sky-200 dark:border-sky-800 flex items-center gap-1.5 transition-all shadow-xs active:scale-95"
            >
              <QrCode className="w-3.5 h-3.5 text-sky-500" />
              <span>UPI ও স্ক্যানার পরিবর্তন করুন</span>
              <ArrowRight className="w-3 h-3 text-sky-400" />
            </button>
          )}

          {/* Filter Tabs */}
          <div className="flex items-center space-x-1.5 p-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold">
            <button
              onClick={() => setFilterStatus('PENDING')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                filterStatus === 'PENDING'
                  ? 'bg-amber-500 text-slate-950 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              অপেক্ষমাণ (Pending)
            </button>
            <button
              onClick={() => setFilterStatus('APPROVED')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                filterStatus === 'APPROVED'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              অনুমোদিত (Approved)
            </button>
            <button
              onClick={() => setFilterStatus('REJECTED')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                filterStatus === 'REJECTED'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              বাতিল (Rejected)
            </button>
            <button
              onClick={() => setFilterStatus('ALL')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                filterStatus === 'ALL'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              সবগুলো ({feePayments.length})
            </button>
          </div>
        </div>
      </div>

      {/* Active UPI ID & Gateway Quick Status Pill */}
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-sky-900/40 via-slate-900/30 to-blue-900/40 border border-sky-500/20 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
            <QrCode className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-slate-400 text-[11px]">বর্তমান সক্রিয় টিউশন ফি UPI:</span>
              <span className="font-mono font-bold text-sky-400 dark:text-sky-300">{paymentSettings.upiId}</span>
              <span className="text-[10px] px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 font-semibold border border-emerald-500/25">
                {paymentSettings.bankName}
              </span>
            </div>
            <span className="text-[11px] text-slate-400">
              প্রাপক: <strong className="text-slate-200">{paymentSettings.payeeName}</strong> • স্ক্যানার মোড: {paymentSettings.useCustomQrImage ? 'কাস্টম ইমেজ' : 'অটো-জেনারেটেড ডায়নামিক QR'}
            </span>
          </div>
        </div>

        {onNavigateToSettings && (
          <button
            onClick={onNavigateToSettings}
            className="text-xs font-bold text-sky-400 hover:text-sky-300 flex items-center gap-1 hover:underline ml-auto"
          >
            <span>UPI আইডি বা QR স্ক্যানার বদলান</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Verification Queue Table */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden">
        {filteredPayments.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-400">
            এই ফিল্টারে কোনো পেমেন্ট রেকর্ড নেই।
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="p-3.5 font-bold">ছাত্রের নাম ও বিবরণ</th>
                  <th className="p-3.5 font-bold">শ্রেণি ও মাস</th>
                  <th className="p-3.5 font-bold">পরিমাণ</th>
                  <th className="p-3.5 font-bold">UPI UTR রেফারেন্স</th>
                  <th className="p-3.5 font-bold">স্ক্রিনশট</th>
                  <th className="p-3.5 font-bold">স্ট্যাটাস</th>
                  <th className="p-3.5 font-bold text-right">পদক্ষেপ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredPayments.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/50 transition-colors">
                    <td className="p-3.5">
                      <span className="font-bold text-slate-900 dark:text-white block">{p.studentName}</span>
                      <span className="text-[11px] font-mono text-slate-400">রোল: {p.studentRoll} • {p.studentPhone}</span>
                    </td>
                    <td className="p-3.5">
                      <span className="font-semibold text-slate-800 dark:text-slate-200 block">{p.month}</span>
                      <span className="text-[10px] text-slate-400">{p.classLevel}</span>
                    </td>
                    <td className="p-3.5 font-bold text-sm text-slate-900 dark:text-white">
                      ₹ {p.amount}
                    </td>
                    <td className="p-3.5 font-mono text-xs font-bold text-sky-600 dark:text-sky-400">
                      {p.utrNumber}
                    </td>
                    <td className="p-3.5">
                      {p.screenshotUrl ? (
                        <button
                          onClick={() => setSelectedScreenshotUrl(p.screenshotUrl || null)}
                          className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 text-[11px] font-semibold flex items-center gap-1 transition-colors"
                        >
                          <Eye className="w-3.5 h-3.5 text-sky-500" />
                          <span>রসিদ দেখুন</span>
                        </button>
                      ) : (
                        <span className="text-slate-400">অনুপলব্ধ</span>
                      )}
                    </td>
                    <td className="p-3.5">
                      {p.status === 'APPROVED' && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 flex items-center gap-1 w-fit">
                          <CheckCircle2 className="w-3 h-3" /> অনুমোদিত
                        </span>
                      )}
                      {p.status === 'PENDING' && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30 flex items-center gap-1 w-fit">
                          <Clock className="w-3 h-3" /> যাচাই অপেক্ষমাণ
                        </span>
                      )}
                      {p.status === 'REJECTED' && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/15 text-rose-600 dark:text-rose-400 border border-rose-500/30 flex items-center gap-1 w-fit">
                          <XCircle className="w-3 h-3" /> বাতিল
                        </span>
                      )}
                    </td>
                    <td className="p-3.5 text-right">
                      {p.status === 'PENDING' ? (
                        <div className="flex items-center justify-end space-x-1.5">
                          <button
                            onClick={() => handleApprove(p)}
                            className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs flex items-center gap-1"
                          >
                            <Check className="w-3.5 h-3.5" /> অনুমোদন
                          </button>
                          <button
                            onClick={() => setRejectingPaymentId(p.id)}
                            className="px-2.5 py-1.5 rounded-xl bg-rose-50 text-rose-600 dark:bg-rose-950/40 dark:text-rose-400 hover:bg-rose-100 font-semibold text-xs"
                          >
                            বাতিল
                          </button>
                        </div>
                      ) : (
                        <span className="text-[11px] text-slate-400">
                          {p.verifiedAt ? `যাচাই: ${p.verifiedAt}` : 'সম্পন্ন'}
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Screenshot Preview Modal */}
      {selectedScreenshotUrl && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-sm w-full p-4 border border-slate-200 dark:border-slate-800 shadow-2xl relative">
            <button
              onClick={() => setSelectedScreenshotUrl(null)}
              className="absolute top-4 right-4 p-1 rounded-full bg-black/60 text-white"
            >
              <X className="w-4 h-4" />
            </button>
            <h4 className="font-bold text-xs text-slate-800 dark:text-slate-200 mb-2">
              পেমেন্ট স্ক্রিনশট প্রিভিউ
            </h4>
            <div className="rounded-xl overflow-hidden max-h-[420px] bg-slate-100 flex items-center justify-center border">
              <img
                src={selectedScreenshotUrl}
                alt="Payment Screenshot"
                className="w-full h-auto object-contain"
              />
            </div>
            <p className="text-[11px] text-slate-500 mt-2 text-center">
              Google Pay / PhonePe ট্রানজাকশন হিস্ট্রি কপি
            </p>
          </div>
        </div>
      )}

      {/* Rejection Reason Dialog */}
      {rejectingPaymentId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-sm w-full p-5 border border-slate-200 dark:border-slate-800 shadow-2xl">
            <h4 className="font-bold text-sm text-slate-900 dark:text-white">
              পেমেন্ট বাতিলের কারণ উল্লেখ করুন
            </h4>
            <p className="text-xs text-slate-500 mt-0.5">
              এই কারণটি সংশ্লিষ্ট ছাত্রের অ্যাপ স্ক্রিনে দৃশ্যমান হবে।
            </p>

            <form onSubmit={handleConfirmReject} className="mt-4 space-y-3">
              <select
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
              >
                <option value="UPI UTR স্টেটমেন্টে পাওয়া যায়নি">UPI UTR স্টেটমেন্টে পাওয়া যায়নি</option>
                <option value="ভুল ট্রানজাকশন রেফারেন্স নম্বর">ভুল ট্রানজাকশন রেফারেন্স নম্বর</option>
                <option value="স্ক্রিনশট অস্পষ্ট বা জাল">স্ক্রিনশট অস্পষ্ট বা জাল</option>
                <option value="টাকার পরিমাণ কম জমা পড়েছে">টাকার পরিমাণ কম জমা পড়েছে</option>
              </select>

              <div className="flex items-center justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setRejectingPaymentId(null)}
                  className="px-3 py-2 text-xs text-slate-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-sm"
                >
                  Confirm Reject
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
