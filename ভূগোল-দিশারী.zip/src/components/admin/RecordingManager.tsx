import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Video,
  Plus,
  Trash2,
  Edit2,
  Clock,
  Eye,
  FileText,
  Play,
  CheckCircle,
} from 'lucide-react';
import { RecordingClass } from '../../types';

export const RecordingManager: React.FC = () => {
  const { recordings, addRecording, updateRecording, deleteRecording, showToast } = useApp();
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const [title, setTitle] = useState('');
  const [classLevel, setClassLevel] = useState('Class 10');
  const [topic, setTopic] = useState('');
  const [duration, setDuration] = useState('1h 15m');
  const [videoUrl, setVideoUrl] = useState('');
  const [thumbnailUrl, setThumbnailUrl] = useState('');
  const [pdfNotesUrl, setPdfNotesUrl] = useState('');

  const sampleThumbnails = [
    {
      label: 'বহির্জাত ভূমিরূপ',
      url: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80',
    },
    {
      label: 'ভারতের ভূপ্রকৃতি',
      url: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=800&q=80',
    },
    {
      label: 'মৃত্তিকা ও জলবায়ু',
      url: 'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=800&q=80',
    },
  ];

  const handleOpenAdd = () => {
    setEditingId(null);
    setTitle('বায়ুমণ্ডলের স্তরবিন্যাস ও তাপমাত্রার তারতম্যের কারণসমূহ');
    setClassLevel('Class 10');
    setTopic('বায়ুমণ্ডল (Atmosphere)');
    setDuration('1h 10m');
    setVideoUrl('https://www.youtube.com/watch?v=dQw4w9WgXcQ');
    setThumbnailUrl(sampleThumbnails[0].url);
    setPdfNotesUrl('https://drive.google.com/file/d/1BhugolDishari_Notes_Demo/view');
    setShowModal(true);
  };

  const handleOpenEdit = (rec: RecordingClass) => {
    setEditingId(rec.id);
    setTitle(rec.title);
    setClassLevel(rec.classLevel);
    setTopic(rec.topic);
    setDuration(rec.duration);
    setVideoUrl(rec.videoUrl);
    setThumbnailUrl(rec.thumbnailUrl);
    setPdfNotesUrl(rec.pdfNotesUrl || '');
    setShowModal(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !thumbnailUrl) {
      showToast('ত্রুটি', 'টাইটেল ও থাম্বনেল আবশ্যক', 'warning');
      return;
    }

    if (editingId) {
      updateRecording(editingId, {
        title,
        classLevel,
        topic,
        duration,
        videoUrl,
        thumbnailUrl,
        pdfNotesUrl,
      });
    } else {
      addRecording({
        title,
        classLevel,
        topic,
        duration,
        videoUrl,
        thumbnailUrl,
        instructor: 'Narayan Sir (নারায়ণ স্যার)',
        pdfNotesUrl,
      });
    }

    setShowModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Video className="w-5 h-5 text-emerald-500" />
            <span>রেকর্ডিং ক্লাস (Recording Class) ম্যানেজার</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            ছাত্র অ্যাপের 'Recording Class' সেকশনে প্রদর্শিত ভিডিও লেকচার ও রিভিশন ক্লাস পরিচালনা করুন
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition-all flex items-center gap-1.5 self-start active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>নতুন লেকচার যুক্ত করুন</span>
        </button>
      </div>

      {/* Grid of Recordings */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {recordings.map((rec) => (
          <div
            key={rec.id}
            className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden flex flex-col group hover:shadow-md transition-all"
          >
            <div className="relative h-44 bg-slate-800">
              <img
                src={rec.thumbnailUrl}
                alt={rec.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <span className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-black/60 text-white text-[10px] font-bold backdrop-blur-xs">
                {rec.classLevel}
              </span>
              <span className="absolute bottom-2 right-2 px-2 py-0.5 rounded-md bg-emerald-600 text-white text-[10px] font-bold flex items-center gap-1">
                <Clock className="w-3 h-3" /> {rec.duration}
              </span>
            </div>

            <div className="p-4 flex-1 flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
                  {rec.topic}
                </span>
                <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white mt-1 leading-snug line-clamp-2">
                  {rec.title}
                </h4>
                <p className="text-[11px] text-slate-500 mt-1">
                  প্রশিক্ষক: {rec.instructor}
                </p>
              </div>

              <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <span className="text-[11px] text-slate-400 flex items-center gap-1">
                  <Eye className="w-3.5 h-3.5" /> {rec.viewsCount} ভিউজ
                </span>

                <div className="flex items-center space-x-1.5">
                  <button
                    onClick={() => handleOpenEdit(rec)}
                    className="p-1.5 rounded-lg text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
                    title="Edit Lecture"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => deleteRecording(rec.id)}
                    className="p-1.5 rounded-lg text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                    title="Delete Lecture"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 border border-slate-200 dark:border-slate-800 shadow-2xl">
            <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
              {editingId ? 'রেকর্ডিং লেকচার সম্পাদনা' : 'নতুন ভিডিও লেকচার যুক্ত করুন'}
            </h3>

            <form onSubmit={handleSubmit} className="mt-4 space-y-3">
              <div>
                <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  লেকচার টাইটেল
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    শ্রেণি
                  </label>
                  <select
                    value={classLevel}
                    onChange={(e) => setClassLevel(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  >
                    <option value="Class 9">Class 9</option>
                    <option value="Class 10">Class 10</option>
                    <option value="Class 11">Class 11</option>
                    <option value="Class 12">Class 12</option>
                  </select>
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    সময়কাল (Duration)
                  </label>
                  <input
                    type="text"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    placeholder="1h 15m"
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  টপিক / বিষয়
                </label>
                <input
                  type="text"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  placeholder="যেমন: বায়ুমণ্ডল বা নদীর সঞ্চয়কার্য"
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  required
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  থাম্বনেল ছবি URL
                </label>
                <input
                  type="url"
                  value={thumbnailUrl}
                  onChange={(e) => setThumbnailUrl(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono"
                  required
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  যুক্ত লেকচার নোটস (PDF ড্রাইভ লিংক - ঐচ্ছিক)
                </label>
                <input
                  type="url"
                  value={pdfNotesUrl}
                  onChange={(e) => setPdfNotesUrl(e.target.value)}
                  placeholder="https://drive.google.com/..."
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono"
                />
              </div>

              <div className="pt-3 flex items-center justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-3 py-2 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-100 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-sm"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
