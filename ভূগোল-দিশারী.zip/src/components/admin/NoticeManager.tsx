import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Bell,
  Plus,
  Trash2,
  AlertTriangle,
  Award,
  Calendar,
  Send,
  Sparkles,
} from 'lucide-react';
import { NoticeItem } from '../../types';

export const NoticeManager: React.FC = () => {
  const { notices, addNotice, deleteNotice, showToast } = useApp();
  const [showModal, setShowModal] = useState(false);

  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [priority, setPriority] = useState<NoticeItem['priority']>('URGENT');
  const [targetBatch, setTargetBatch] = useState('All Classes (সকল ছাত্রছাত্রী)');

  const handleOpenAdd = () => {
    setTitle('মাধ্যমিক ২০২৬ স্পেশাল মানচিত্র ও প্র্যাক্টিক্যাল ক্লাস');
    setMessage('আগামীকাল বুধবার রাত ৮টায় গুগল মিট ও অ্যাপ লাইভে ভারতের ভূপ্রকৃতি ও নদী তীরবর্তী শহরের ম্যাপ পয়েন্টিং শেখানো হবে। সকল ছাত্রছাত্রীদের উপস্থিতি বাধ্যতামূলক।');
    setPriority('URGENT');
    setShowModal(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !message) {
      showToast('ত্রুটি', 'বিজ্ঞপ্তির শিরোনাম ও বিস্তারিত বার্তা আবশ্যক', 'warning');
      return;
    }

    addNotice({
      title,
      message,
      priority,
      author: 'Narayan Sir (নারায়ণ স্যার)',
      targetBatch,
    });

    setShowModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Bell className="w-5 h-5 text-sky-600 dark:text-sky-400" />
            <span>লাইভ ব্রডকাস্ট নোটিশ বোর্ড (FCM Push Alerts)</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            জরুরি ঘোষণা, পরীক্ষা ও ছুটির নোটিশ প্রকাশ করুন (তাৎক্ষণিক পুশ নোটিফিকেশন সিঙ্ক)
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs shadow-md transition-all flex items-center gap-1.5 self-start active:scale-95"
        >
          <Send className="w-3.5 h-3.5" />
          <span>নতুন বিজ্ঞপ্তি ব্রডকাস্ট করুন</span>
        </button>
      </div>

      {/* Notices List */}
      <div className="space-y-3">
        {notices.map((n) => (
          <div
            key={n.id}
            className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:shadow-sm transition-all"
          >
            <div className="space-y-1 max-w-2xl">
              <div className="flex items-center gap-2 flex-wrap">
                {n.priority === 'URGENT' && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/15 text-rose-600 dark:text-rose-400 border border-rose-500/30 flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3" /> জরুরি
                  </span>
                )}
                {n.priority === 'EXAM' && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30 flex items-center gap-1">
                    <Award className="w-3 h-3" /> পরীক্ষা বিজ্ঞপ্তি
                  </span>
                )}
                {n.priority === 'HOLIDAY' && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                    <Calendar className="w-3 h-3" /> ছুটির নোটিশ
                  </span>
                )}
                {n.priority === 'GENERAL' && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-500/15 text-sky-600 dark:text-sky-400 border border-sky-500/30">
                    সাধারণ
                  </span>
                )}

                <span className="text-[11px] text-slate-400">📅 {n.date}</span>
                <span className="text-[11px] text-slate-400">• {n.author}</span>
              </div>

              <h4 className="font-bold text-sm text-slate-900 dark:text-white mt-1">
                {n.title}
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed whitespace-pre-line">
                {n.message}
              </p>
            </div>

            <div className="flex items-center space-x-2 self-end sm:self-center">
              <button
                onClick={() => deleteNotice(n.id)}
                className="p-2 rounded-xl text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                title="Delete Notice"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 border border-slate-200 dark:border-slate-800 shadow-2xl">
            <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
              নোটিশ ব্রডকাস্ট প্রকাশ করুন
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              এই বিজ্ঞপ্তিটি ছাত্র অ্যাপের নোটিশ বোর্ডে ও নোটিফিকেশন সেন্টারে পৌঁছে যাবে।
            </p>

            <form onSubmit={handleSubmit} className="mt-4 space-y-3.5">
              <div>
                <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  বিজ্ঞপ্তির শিরোনাম (Title)
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    ক্যাটাগরি / অগ্রাধিকার
                  </label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  >
                    <option value="URGENT">জরুরি (URGENT)</option>
                    <option value="EXAM">পরীক্ষা (EXAM)</option>
                    <option value="HOLIDAY">ছুটি (HOLIDAY)</option>
                    <option value="GENERAL">সাধারণ (GENERAL)</option>
                  </select>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    টার্গেট ব্যাচ
                  </label>
                  <select
                    value={targetBatch}
                    onChange={(e) => setTargetBatch(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  >
                    <option value="All Classes">সকল ছাত্রছাত্রী (All)</option>
                    <option value="Class 10">Class 10 Madhyamik</option>
                    <option value="Class 12">Class 12 WBCHSE</option>
                    <option value="Class 11">Class 11</option>
                    <option value="Class 9">Class 9</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  বিস্তারিত বার্তা (Message)
                </label>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  rows={4}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white resize-none"
                  required
                />
              </div>

              <div className="pt-3 flex items-center justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-3 py-2 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-100 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold shadow-sm flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>এখনই ব্রডকাস্ট করুন</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
