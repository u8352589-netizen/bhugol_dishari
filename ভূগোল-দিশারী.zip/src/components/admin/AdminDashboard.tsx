import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  LayoutDashboard,
  Image,
  Video,
  KeyRound,
  Bell,
  Users,
  CreditCard,
  RefreshCw,
  LogOut,
  ShieldCheck,
  Smartphone,
  ExternalLink,
  QrCode,
  BellRing,
  GraduationCap,
} from 'lucide-react';
import { AdminOverview } from './AdminOverview';
import { BannerManager } from './BannerManager';
import { RecordingManager } from './RecordingManager';
import { NotesCodeManager } from './NotesCodeManager';
import { NoticeManager } from './NoticeManager';
import { AttendanceManager } from './AttendanceManager';
import { FeeVerificationQueue } from './FeeVerificationQueue';
import { PaymentSettingsManager } from './PaymentSettingsManager';
import { FeeAutoReminderHub } from './FeeAutoReminderHub';
import { StudentManagement } from './StudentManagement';

export const AdminDashboard: React.FC<{ isSplitView?: boolean }> = ({ isSplitView = false }) => {
  const { adminUser, adminLogout, isDarkMode, triggerSyncPulse, feePayments, studentRoster } = useApp();
  const [activeTab, setActiveTab] = useState<
    'overview' | 'students' | 'fee_reminders' | 'payment_settings' | 'fees' | 'notes' | 'banners' | 'recordings' | 'notices' | 'attendance'
  >('overview');

  const pendingCount = feePayments.filter((p) => p.status === 'PENDING').length;
  const activeStudentsCount = studentRoster.filter((s) => s.status !== 'ARCHIVED').length;

  const navItems = [
    { id: 'overview', label: 'ওভারভিউ (Overview)', icon: LayoutDashboard },
    { id: 'students', label: 'শিক্ষার্থী ব্যবস্থাপনা', icon: GraduationCap, badge: `${activeStudentsCount}` },
    { id: 'fee_reminders', label: 'ফি রিমাইন্ডার (১ম-২য় তারিখ)', icon: BellRing, badge: 'Auto' },
    { id: 'payment_settings', label: 'UPI ও QR স্ক্যানার পরিবর্তন', icon: QrCode, badge: 'New' },
    { id: 'fees', label: 'ফি ভেরিফিকেশন (Fees)', icon: CreditCard, count: pendingCount },
    { id: 'notes', label: 'নোটস ও ৪ ডিজিট পিন', icon: KeyRound, badge: 'Security' },
    { id: 'attendance', label: 'ডিজিটাল হাজিরা (Attendance)', icon: Users },
    { id: 'banners', label: 'ব্যানার স্লাইডার (Banners)', icon: Image },
    { id: 'recordings', label: 'রেকর্ডিং ক্লাস (Videos)', icon: Video },
    { id: 'notices', label: 'নোটিশ বোর্ড (Notices)', icon: Bell },
  ];

  return (
    <div className={`w-full flex-1 flex flex-col ${isDarkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-100 text-slate-800'}`}>
      {/* Top Admin Sub-Header */}
      <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 py-3 flex flex-wrap items-center justify-between gap-3 shadow-xs">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-amber-500/15 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold border border-amber-500/30">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <span>{adminUser?.name || 'Narayan Sir (নারায়ণ স্যার)'}</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 font-semibold border border-emerald-500/30">
                Super Admin
              </span>
            </h2>
            <p className="text-[11px] text-slate-500">
              Web Admin Management Panel • ভূগোল মানেই নারায়ণ স্যার
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => triggerSyncPulse('ম্যানুয়াল ফায়ারস্টোর সিঙ্ক সম্পন্ন হয়েছে')}
            className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors border border-slate-200 dark:border-slate-700"
            title="Force Real-time Sync to Mobile App"
          >
            <RefreshCw className="w-3.5 h-3.5 text-sky-500" />
            <span className="hidden sm:inline">Firebase Sync Pulse</span>
          </button>

          <button
            onClick={adminLogout}
            className="p-1.5 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
            title="Logout"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Admin Workspace with Sidebar & Content */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        {/* Navigation Sidebar */}
        <div
          className={`w-full md:w-64 p-3 border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/60 shrink-0 overflow-x-auto md:overflow-y-auto flex md:flex-col gap-1 text-xs`}
        >
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id as any)}
                className={`flex items-center justify-between px-3 py-2.5 rounded-xl font-bold transition-all text-left whitespace-nowrap md:whitespace-normal ${
                  isActive
                    ? 'bg-sky-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center space-x-2.5">
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{item.label}</span>
                </div>

                {item.count !== undefined && item.count > 0 && (
                  <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-black ${
                    isActive ? 'bg-amber-400 text-slate-950' : 'bg-amber-500/20 text-amber-600 dark:text-amber-400'
                  }`}>
                    {item.count}
                  </span>
                )}

                {item.badge && !isActive && (
                  <span className="hidden lg:inline-block px-1.5 py-0.5 rounded text-[9px] font-bold bg-purple-500/10 text-purple-600 dark:text-purple-300">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Workspace Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          {activeTab === 'overview' && <AdminOverview onNavigateTab={(t) => setActiveTab(t as any)} />}
          {activeTab === 'students' && <StudentManagement onNavigateTab={(t) => setActiveTab(t as any)} />}
          {activeTab === 'banners' && <BannerManager />}
          {activeTab === 'recordings' && <RecordingManager />}
          {activeTab === 'notes' && <NotesCodeManager />}
          {activeTab === 'notices' && <NoticeManager />}
          {activeTab === 'attendance' && <AttendanceManager />}
          {activeTab === 'fees' && (
            <FeeVerificationQueue
              onNavigateToSettings={() => setActiveTab('payment_settings')}
              onNavigateToReminders={() => setActiveTab('fee_reminders')}
            />
          )}
          {activeTab === 'fee_reminders' && <FeeAutoReminderHub />}
          {activeTab === 'payment_settings' && <PaymentSettingsManager />}
        </div>
      </div>
    </div>
  );
};
