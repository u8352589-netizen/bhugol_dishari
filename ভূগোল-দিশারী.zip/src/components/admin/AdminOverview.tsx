import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Users,
  CreditCard,
  Video,
  FileText,
  Bell,
  CheckCircle,
  Clock,
  ArrowUpRight,
  Sparkles,
  KeyRound,
  ShieldCheck,
  QrCode,
  ArrowRight,
  BellRing,
  GraduationCap,
} from 'lucide-react';

interface AdminOverviewProps {
  onNavigateTab: (tab: string) => void;
}

export const AdminOverview: React.FC<AdminOverviewProps> = ({ onNavigateTab }) => {
  const {
    banners,
    recordings,
    classNotes,
    notices,
    feePayments,
    attendance,
    studentRoster,
    paymentSettings,
  } = useApp();

  const pendingPayments = feePayments.filter((p) => p.status === 'PENDING');
  const totalApprovedAmount = feePayments
    .filter((p) => p.status === 'APPROVED')
    .reduce((acc, curr) => acc + curr.amount, 0);

  const stats = [
    {
      label: 'শ্রেণিভিত্তিক নিবন্ধিত শিক্ষার্থী',
      value: studentRoster.filter((s) => s.status !== 'ARCHIVED').length,
      sublabel: '৯ম, ১০ম, ১১শ ও ১২শ শ্রেণির সম্পূর্ণ তালিকা',
      icon: GraduationCap,
      color: 'from-emerald-500 to-teal-600',
      action: () => onNavigateTab('students'),
    },
    {
      label: 'অনুমোদন অপেক্ষমাণ ফি (Pending)',
      value: pendingPayments.length,
      sublabel: `মোট সংগৃহীত: ₹${totalApprovedAmount.toLocaleString()}`,
      icon: CreditCard,
      color: 'from-amber-500 to-orange-600',
      action: () => onNavigateTab('fees'),
    },
    {
      label: 'ভিডিও রেকর্ডিং লেকচার',
      value: recordings.length,
      sublabel: '৯ম, ১০ম, ১১শ ও ১২শ শ্রেণি',
      icon: Video,
      color: 'from-emerald-500 to-teal-600',
      action: () => onNavigateTab('recordings'),
    },
    {
      label: 'নোটস (PDF) ও সিকিউরিটি লক',
      value: classNotes.length,
      sublabel: '৪টি শ্রেণির পৃথক ৪ ডিজিট পিন কোড',
      icon: KeyRound,
      color: 'from-purple-500 to-indigo-600',
      action: () => onNavigateTab('notes'),
    },
  ];

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-slate-900 via-sky-950 to-slate-900 text-white shadow-xl border border-sky-500/20 relative overflow-hidden">
        <div className="relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-500/20 text-sky-300 text-xs font-semibold border border-sky-500/30 mb-2">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Master Admin Control • ভূগোল দিশারী ম্যানেজমেন্ট</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white">
            স্বাগতম, নারায়ণ স্যার (Narayan Sir)!
          </h2>
          <p className="text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
            এখানে করা যেকোনো পরিবর্তন—ব্যানার, রেকর্ডিং ভিডিও, ৪ ডিজিটের সিকিউরিটি কোড, বা লাইভ নোটিস—ছাত্রদের অ্যান্ড্রয়েড অ্যাপে তাৎক্ষণিকভাবে রিয়েল-টাইমে সিঙ্ক হবে।
          </p>

          <div className="mt-4 flex flex-wrap gap-2.5">
            <button
              onClick={() => onNavigateTab('students')}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs shadow-md transition-all flex items-center gap-1.5 active:scale-95"
            >
              <GraduationCap className="w-4 h-4" /> শিক্ষার্থী ব্যবস্থাপনা (Student Hub)
            </button>
            <button
              onClick={() => onNavigateTab('fee_reminders')}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs shadow-md transition-all flex items-center gap-1.5 active:scale-95"
            >
              <BellRing className="w-4 h-4" /> ১ম-২য় তারিখ অটো রিমাইন্ডার
            </button>
            <button
              onClick={() => onNavigateTab('payment_settings')}
              className="px-4 py-2 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 transition-all flex items-center gap-1.5 active:scale-95"
            >
              <QrCode className="w-4 h-4 text-sky-400" /> UPI আইডি ও QR স্ক্যানার
            </button>
            <button
              onClick={() => onNavigateTab('notes')}
              className="px-4 py-2 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 transition-all flex items-center gap-1.5 active:scale-95"
            >
              <KeyRound className="w-4 h-4 text-amber-400" /> ৪ ডিজিট পিন পরিচালনা
            </button>
            <button
              onClick={() => onNavigateTab('fees')}
              className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs shadow-md transition-all flex items-center gap-1.5 active:scale-95"
            >
              <CreditCard className="w-4 h-4" /> ফি ভেরিফিকেশন কিউ ({pendingPayments.length})
            </button>
            <button
              onClick={() => onNavigateTab('notices')}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700 transition-all flex items-center gap-1.5"
            >
              <Bell className="w-4 h-4" /> নোটিশ ব্রডকাস্ট করুন
            </button>
          </div>
        </div>

        {/* Decorative background shape */}
        <div className="absolute -right-10 -bottom-10 w-64 h-64 rounded-full bg-sky-500/10 blur-3xl pointer-events-none" />
      </div>

      {/* KPI Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((st, idx) => {
          const Icon = st.icon;
          return (
            <div
              key={idx}
              onClick={st.action}
              className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs hover:shadow-lg transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
                    {st.label}
                  </span>
                  <div className={`w-10 h-10 rounded-xl bg-gradient-to-tr ${st.color} text-white flex items-center justify-center shadow-md group-hover:scale-110 transition-transform`}>
                    <Icon className="w-5 h-5" />
                  </div>
                </div>
                <div className="mt-3">
                  <h3 className="text-2xl font-black text-slate-900 dark:text-white">
                    {st.value}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    {st.sublabel}
                  </p>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-semibold text-sky-600 dark:text-sky-400 group-hover:underline">
                <span>ম্যানেজ করুন</span>
                <ArrowUpRight className="w-4 h-4" />
              </div>
            </div>
          );
        })}
      </div>

      {/* 2-Column Section: Active Security PINs & Pending Fee Submissions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Card 1: Active 4-Digit Security PINs Summary */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center space-x-2">
              <KeyRound className="w-4 h-4 text-amber-500" />
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                শ্রেণিভিত্তিক ৪ ডিজিট সিকিউরিটি কোড স্ট্যাটাস
              </h3>
            </div>
            <button
              onClick={() => onNavigateTab('notes')}
              className="text-xs text-amber-600 dark:text-amber-400 font-bold hover:underline"
            >
              পরিবর্তন করুন →
            </button>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-800 mt-2">
            {classNotes.map((sec) => (
              <div key={sec.id} className="py-3 flex items-center justify-between text-xs">
                <div>
                  <h4 className="font-bold text-slate-900 dark:text-white">{sec.classLevel}</h4>
                  <p className="text-[11px] text-slate-500">{sec.chapters.length} টি অধ্যায় আপলোড করা আছে</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-mono font-black text-sm px-3 py-1 rounded-xl bg-amber-100 text-amber-900 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-300 dark:border-amber-700">
                    {sec.securityCode}
                  </span>
                  <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold">
                    ✓ অ্যাক্টিভ
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Card 2: Pending Fee Submissions */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4 text-sky-500" />
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                জরুরি ভেরিফিকেশন কিউ ({pendingPayments.length})
              </h3>
            </div>
            <button
              onClick={() => onNavigateTab('fees')}
              className="text-xs text-sky-600 dark:text-sky-400 font-bold hover:underline"
            >
              সবগুলো দেখুন →
            </button>
          </div>

          {pendingPayments.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-400">
              কোনো অপেক্ষমাণ পেমেন্ট নেই। সমস্ত ফি যাচাই করা সম্পন্ন হয়েছে!
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800 mt-2">
              {pendingPayments.slice(0, 3).map((p) => (
                <div key={p.id} className="py-2.5 flex items-center justify-between text-xs">
                  <div>
                    <h5 className="font-bold text-slate-900 dark:text-white">{p.studentName}</h5>
                    <p className="text-[11px] text-slate-500">
                      {p.classLevel} • UTR: <span className="font-mono">{p.utrNumber}</span>
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="font-bold text-slate-900 dark:text-white">₹ {p.amount}</span>
                    <button
                      onClick={() => onNavigateTab('fees')}
                      className="block text-[10px] text-sky-600 font-bold hover:underline"
                    >
                      যাচাই করুন
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Card 3: Active Payment Gateway UPI & Scanner Status Banner */}
      <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/15 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold border border-amber-500/30 shrink-0">
            <QrCode className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-500 dark:text-slate-400">অফিসিয়াল টিউশন ফি UPI গেটওয়ে:</span>
              <span className="font-mono font-bold text-xs sm:text-sm text-sky-600 dark:text-sky-400">
                {paymentSettings.upiId}
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
                সক্রিয় (Active)
              </span>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
              প্রাপক: <strong>{paymentSettings.payeeName}</strong> ({paymentSettings.bankName}) • মাসিক ফি: ৯ম/১০ম ₹{paymentSettings.classFeeStructure.class9And10}, ১১শ/১২শ ₹{paymentSettings.classFeeStructure.class11And12}
            </p>
          </div>
        </div>

        <button
          onClick={() => onNavigateTab('payment_settings')}
          className="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-sky-50 dark:hover:bg-sky-950 hover:text-sky-600 text-slate-700 dark:text-slate-200 text-xs font-bold transition-all border border-slate-200 dark:border-slate-700 flex items-center gap-1.5 shrink-0 self-start sm:self-auto"
        >
          <span>UPI আইডি ও স্ক্যানার পরিবর্তন করুন</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
