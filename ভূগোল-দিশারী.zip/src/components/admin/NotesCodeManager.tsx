import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  KeyRound,
  FileText,
  Plus,
  Trash2,
  Edit2,
  ExternalLink,
  ShieldCheck,
  Check,
  Layers,
  Sparkles,
} from 'lucide-react';
import { ChapterNote } from '../../types';

export const NotesCodeManager: React.FC = () => {
  const { classNotes, updateSecurityCode, addChapterNote, updateChapterNote, deleteChapterNote, showToast } = useApp();
  const [selectedClassId, setSelectedClassId] = useState<string>(classNotes[1]?.id || 'sec-class10'); // Default to Class 10
  const [pinEditingClassId, setPinEditingClassId] = useState<string | null>(null);
  const [newPinCode, setNewPinCode] = useState<string>('');

  // Chapter Modal Form
  const [showChapterModal, setShowChapterModal] = useState(false);
  const [editingChapterId, setEditingChapterId] = useState<string | null>(null);
  const [chapterNumber, setChapterNumber] = useState<number>(1);
  const [chapterName, setChapterName] = useState('');
  const [description, setDescription] = useState('');
  const [drivePdfUrl, setDrivePdfUrl] = useState('');
  const [totalPages, setTotalPages] = useState(24);
  const [fileSize, setFileSize] = useState('4.8 MB');

  const currentSection = classNotes.find((sec) => sec.id === selectedClassId) || classNotes[0];

  const handleStartEditPin = (secId: string, currentPin: string) => {
    setPinEditingClassId(secId);
    setNewPinCode(currentPin);
  };

  const handleSavePin = (secId: string) => {
    if (newPinCode.length !== 4 || !/^\d{4}$/.test(newPinCode)) {
      showToast('অবৈধ পিন', 'সিকিউরিটি কোড অবশ্যই ঠিক ৪ ডিজিটের সংখ্যা হতে হবে (যেমন: 2010)', 'warning');
      return;
    }
    updateSecurityCode(secId, newPinCode);
    setPinEditingClassId(null);
  };

  const handleOpenAddChapter = () => {
    setEditingChapterId(null);
    setChapterNumber(currentSection.chapters.length + 1);
    setChapterName('');
    setDescription('');
    setDrivePdfUrl('https://drive.google.com/file/d/1BhugolDishari_Notes_Demo/view?usp=sharing');
    setTotalPages(25);
    setFileSize('5.2 MB');
    setShowChapterModal(true);
  };

  const handleOpenEditChapter = (ch: ChapterNote) => {
    setEditingChapterId(ch.id);
    setChapterNumber(ch.chapterNumber);
    setChapterName(ch.chapterName);
    setDescription(ch.description || '');
    setDrivePdfUrl(ch.drivePdfUrl);
    setTotalPages(ch.totalPages || 20);
    setFileSize(ch.fileSize || '4.0 MB');
    setShowChapterModal(true);
  };

  const handleSaveChapter = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chapterName || !drivePdfUrl) {
      showToast('ত্রুটি', 'অধ্যায়ের নাম ও গুগল ড্রাইভ লিংক আবশ্যক', 'warning');
      return;
    }

    if (editingChapterId) {
      updateChapterNote(selectedClassId, editingChapterId, {
        chapterNumber,
        chapterName,
        description,
        drivePdfUrl,
        totalPages,
        fileSize,
      });
    } else {
      addChapterNote(selectedClassId, {
        chapterNumber,
        chapterName,
        description,
        drivePdfUrl,
        totalPages,
        fileSize,
      });
    }
    setShowChapterModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <KeyRound className="w-5 h-5 text-amber-500" />
          <span>Notes (PDF) ও ৪ ডিজিট সিকিউরিটি কোড ম্যানেজার</span>
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          প্রতিটি শ্রেণির জন্য নির্দিষ্ট ৪ ডিজিট কোড এবং গুগল ড্রাইভ পিডিএফ লিংক নিয়ন্ত্রণ করুন
        </p>
      </div>

      {/* 4-Digit Security Code Dashboard by Class */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs">
        <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100 dark:border-slate-800">
          <span className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            শ্রেণিভিত্তিক সক্রিয় ৪ ডিজিট সিকিউরিটি কোড (Firestore Managed)
          </span>
          <span className="text-[11px] text-slate-400">রিয়েল-টাইম বাইডিরেকশনাল সিঙ্ক</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {classNotes.map((sec) => {
            const isEditingThis = pinEditingClassId === sec.id;
            return (
              <div
                key={sec.id}
                className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-slate-800 dark:text-slate-200">
                      {sec.classLevel}
                    </span>
                    <span className="text-[10px] text-slate-400 font-medium">
                      {sec.chapters.length} অধ্যায়
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-500 truncate mt-0.5">{sec.banglaTitle}</p>
                </div>

                <div className="mt-3 pt-2 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between">
                  {isEditingThis ? (
                    <div className="flex items-center gap-1.5 w-full">
                      <input
                        type="text"
                        maxLength={4}
                        value={newPinCode}
                        onChange={(e) => setNewPinCode(e.target.value)}
                        className="w-20 px-2 py-1 text-center font-mono font-black text-sm rounded-lg bg-white dark:bg-slate-900 border border-amber-500 focus:outline-none text-slate-900 dark:text-white"
                        autoFocus
                      />
                      <button
                        onClick={() => handleSavePin(sec.id)}
                        className="p-1 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700"
                        title="Save PIN"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setPinEditingClassId(null)}
                        className="text-[10px] text-slate-400 hover:text-slate-600 px-1"
                      >
                        বাতিল
                      </button>
                    </div>
                  ) : (
                    <>
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] text-slate-400 font-medium">বর্তমান PIN:</span>
                        <span className="font-mono font-black text-sm px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-200 border border-amber-300 dark:border-amber-700">
                          {sec.securityCode}
                        </span>
                      </div>
                      <button
                        onClick={() => handleStartEditPin(sec.id, sec.securityCode)}
                        className="text-[11px] font-bold text-sky-600 dark:text-sky-400 hover:underline"
                      >
                        কোড পরিবর্তন
                      </button>
                    </>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Chapter Notes Management Panel */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden">
        {/* Class Selector Tabs */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center space-x-1.5 overflow-x-auto text-xs">
            {classNotes.map((sec) => (
              <button
                key={sec.id}
                onClick={() => setSelectedClassId(sec.id)}
                className={`px-3.5 py-2 rounded-xl font-bold transition-all whitespace-nowrap ${
                  selectedClassId === sec.id
                    ? 'bg-sky-600 text-white shadow-sm'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                {sec.classLevel} ({sec.chapters.length})
              </button>
            ))}
          </div>

          <button
            onClick={handleOpenAddChapter}
            className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-sm transition-all flex items-center gap-1.5 self-start active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>নতুন অধ্যায় নোটস যুক্ত করুন</span>
          </button>
        </div>

        {/* Chapters Table */}
        <div className="divide-y divide-slate-100 dark:divide-slate-800">
          {currentSection.chapters.map((ch) => (
            <div
              key={ch.id}
              className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors"
            >
              <div className="flex items-start space-x-3">
                <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 font-black text-sm flex items-center justify-center shrink-0 border border-amber-500/20">
                  {ch.chapterNumber}
                </div>
                <div>
                  <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white leading-tight">
                    {ch.chapterName}
                  </h4>
                  {ch.description && (
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      {ch.description}
                    </p>
                  )}
                  <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-1">
                    <span>📄 {ch.totalPages} পৃষ্ঠা</span>
                    <span>💾 {ch.fileSize}</span>
                    <span>📅 {ch.dateUploaded}</span>
                  </div>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center space-x-2 self-end sm:self-center">
                <a
                  href={ch.drivePdfUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="px-2.5 py-1.5 rounded-lg bg-sky-50 dark:bg-sky-950/40 text-sky-600 dark:text-sky-400 hover:bg-sky-100 text-xs font-semibold flex items-center gap-1 transition-colors"
                  title="Open Google Drive Link"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>ড্রাইভ লিঙ্ক</span>
                </a>
                <button
                  onClick={() => handleOpenEditChapter(ch)}
                  className="p-1.5 rounded-lg text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 transition-colors"
                  title="Edit Chapter"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => deleteChapterNote(selectedClassId, ch.id)}
                  className="p-1.5 rounded-lg text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                  title="Delete Chapter"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add / Edit Chapter Modal */}
      {showChapterModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 border border-slate-200 dark:border-slate-800 shadow-2xl">
            <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
              {editingChapterId ? 'অধ্যায় নোটস সম্পাদনা' : 'নতুন অধ্যায় ও গুগল ড্রাইভ PDF যোগ করুন'}
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              শ্রেণি: <span className="font-bold text-sky-600">{currentSection.classLevel}</span>
            </p>

            <form onSubmit={handleSaveChapter} className="mt-4 space-y-3.5">
              <div className="grid grid-cols-4 gap-2">
                <div>
                  <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    অধ্যায় নং
                  </label>
                  <input
                    type="number"
                    value={chapterNumber}
                    onChange={(e) => setChapterNumber(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
                    required
                  />
                </div>
                <div className="col-span-3">
                  <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    অধ্যায়ের নাম
                  </label>
                  <input
                    type="text"
                    value={chapterName}
                    onChange={(e) => setChapterName(e.target.value)}
                    placeholder="যেমন: অধ্যায় ১ - বহির্জাত প্রক্রিয়া ও সৃষ্ট ভূমিরূপ"
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  সংক্ষিপ্ত বিবরণ
                </label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="যেমন: নদীর ক্ষয় ও সঞ্চয়কার্য, হিমবাহ ও বায়ুর কাজ সম্পূর্ণ রঙিন নোটস"
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  গুগল ড্রাইভ শেয়ারযোগ্য PDF লিংক (View Permission)
                </label>
                <input
                  type="url"
                  value={drivePdfUrl}
                  onChange={(e) => setDrivePdfUrl(e.target.value)}
                  placeholder="https://drive.google.com/file/d/..."
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    মোট পৃষ্ঠা
                  </label>
                  <input
                    type="number"
                    value={totalPages}
                    onChange={(e) => setTotalPages(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    ফাইলের সাইজ
                  </label>
                  <input
                    type="text"
                    value={fileSize}
                    onChange={(e) => setFileSize(e.target.value)}
                    placeholder="4.5 MB"
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowChapterModal(false)}
                  className="px-3 py-2 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-100 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold shadow-sm"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
