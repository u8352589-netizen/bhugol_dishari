import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Image,
  Plus,
  Trash2,
  Edit2,
  CheckCircle,
  Eye,
  Tag,
  ExternalLink,
  Sparkles,
} from 'lucide-react';
import { BannerItem } from '../../types';

export const BannerManager: React.FC = () => {
  const { banners, addBanner, updateBanner, deleteBanner, showToast } = useApp();
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingBannerId, setEditingBannerId] = useState<string | null>(null);

  // Form State
  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [discountBadge, setDiscountBadge] = useState('');
  const [targetCourseId, setTargetCourseId] = useState('');

  const sampleBannerImages = [
    {
      label: 'Class 10 Dhamaka Batch',
      url: 'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?auto=format&fit=crop&w=1200&q=80',
    },
    {
      label: 'Class 12 Semester 4',
      url: 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&w=1200&q=80',
    },
    {
      label: 'Map Pointing Masterclass',
      url: 'https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80',
    },
  ];

  const handleOpenAdd = () => {
    setTitle('মাধ্যমিক ২০২৬ ভূগোল স্পেশাল রিভিশন ব্যাচ');
    setSubtitle('১০০% সিলেবাস কমপ্লিট ও টেস্ট পেপার সমাধান');
    setImageUrl(sampleBannerImages[0].url);
    setDiscountBadge('FLAT ₹200 OFF');
    setTargetCourseId('course-10-dhamaka');
    setEditingBannerId(null);
    setShowAddModal(true);
  };

  const handleEdit = (banner: BannerItem) => {
    setTitle(banner.title);
    setSubtitle(banner.subtitle || '');
    setImageUrl(banner.imageUrl);
    setDiscountBadge(banner.discountBadge || '');
    setTargetCourseId(banner.targetCourseId || '');
    setEditingBannerId(banner.id);
    setShowAddModal(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !imageUrl) {
      showToast('ত্রুটি', 'ব্যানারের শিরোনাম ও ইমেজ লিংক আবশ্যক', 'warning');
      return;
    }

    if (editingBannerId) {
      updateBanner(editingBannerId, {
        title,
        subtitle,
        imageUrl,
        discountBadge,
        targetCourseId,
      });
      showToast('আপডেট সম্পন্ন', 'ব্যানার সফলভাবে আপডেট ও সিঙ্ক হয়েছে', 'success');
    } else {
      if (banners.length >= 5) {
        showToast('সীমা উত্তীর্ণ', 'সর্বোচ্চ ৫টি ব্যানার রাখা সম্ভব। পুরনোগুলি এডিট করুন বা মুছে ফেলুন।', 'warning');
        return;
      }
      addBanner({
        title,
        subtitle,
        imageUrl,
        discountBadge,
        targetCourseId,
        active: true,
      });
    }

    setShowAddModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Image className="w-5 h-5 text-sky-600 dark:text-sky-400" />
            <span>হোম ব্যানার স্লাইডার ম্যানেজার</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            ছাত্র অ্যাপের হোম স্ক্রিনে সর্বোচ্চ ৫টি ব্যানার অটো-স্লাইড হয় (রিয়েল-টাইম ফায়ারস্টোর সিঙ্ক)
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          disabled={banners.length >= 5}
          className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 disabled:opacity-50 text-white font-bold text-xs shadow-md transition-all flex items-center gap-1.5 self-start active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>নতুন ব্যানার যুক্ত করুন ({banners.length}/5)</span>
        </button>
      </div>

      {/* Banner Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {banners.map((banner, index) => (
          <div
            key={banner.id}
            className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden flex flex-col group hover:shadow-md transition-all"
          >
            {/* Banner Preview image */}
            <div className="relative h-40 bg-slate-800 overflow-hidden">
              <img
                src={banner.imageUrl}
                alt={banner.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/40 to-transparent flex flex-col justify-between p-3">
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-black/60 text-white backdrop-blur-xs">
                    ক্রম: #{index + 1}
                  </span>
                  {banner.discountBadge && (
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-400 text-slate-950 shadow-xs">
                      {banner.discountBadge}
                    </span>
                  )}
                </div>

                <div>
                  <h4 className="font-extrabold text-sm text-white line-clamp-1">
                    {banner.title}
                  </h4>
                  {banner.subtitle && (
                    <p className="text-xs text-sky-200 line-clamp-1 mt-0.5">
                      {banner.subtitle}
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* Banner Actions */}
            <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <label className="flex items-center space-x-2 text-xs font-semibold cursor-pointer">
                <input
                  type="checkbox"
                  checked={banner.active}
                  onChange={(e) => updateBanner(banner.id, { active: e.target.checked })}
                  className="rounded text-sky-600 focus:ring-sky-500 w-3.5 h-3.5"
                />
                <span className={banner.active ? 'text-emerald-600 font-bold' : 'text-slate-400'}>
                  {banner.active ? 'সক্রিয় (Live)' : 'নিষ্ক্রিয় (Draft)'}
                </span>
              </label>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => handleEdit(banner)}
                  className="p-1.5 rounded-lg text-slate-600 hover:bg-slate-200 dark:text-slate-300 dark:hover:bg-slate-700 transition-colors"
                  title="Edit Banner"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => deleteBanner(banner.id)}
                  className="p-1.5 rounded-lg text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                  title="Delete Banner"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add / Edit Banner Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 border border-slate-200 dark:border-slate-800 shadow-2xl">
            <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
              {editingBannerId ? 'ব্যানার সম্পাদনা করুন' : 'নতুন প্রচারণামূলক ব্যানার যুক্ত করুন'}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              ছাত্রদের অ্যাপে এই ব্যানারটি তাৎক্ষণিকভাবে অটো-স্লাইডারে প্রদর্শিত হবে।
            </p>

            <form onSubmit={handleSubmit} className="mt-4 space-y-3.5">
              <div>
                <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  ব্যানার টাইটেল (শিরোনাম)
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="যেমন: CLASS X DHAMAKA BATCH 2.0"
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
                  required
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  সাবটাইটেল বা অফার বিবরণ
                </label>
                <input
                  type="text"
                  value={subtitle}
                  onChange={(e) => setSubtitle(e.target.value)}
                  placeholder="যেমন: সম্পূর্ণ সিলেবাস ও টেস্ট পেপার বিশ্লেষণ"
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  ডিসকাউন্ট ব্যাজ টেক্সট (ঐচ্ছিক)
                </label>
                <input
                  type="text"
                  value={discountBadge}
                  onChange={(e) => setDiscountBadge(e.target.value)}
                  placeholder="যেমন: FIRST TIME ₹200 COUPON"
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  ব্যানার ইমেজ URL (16:9 Aspect Ratio)
                </label>
                <input
                  type="url"
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono"
                  required
                />
              </div>

              {/* Sample Quick Image Selection */}
              <div>
                <span className="text-[10px] text-slate-400 block mb-1.5">নমুনা ছবি থেকে বেছে নিন:</span>
                <div className="grid grid-cols-3 gap-1.5">
                  {sampleBannerImages.map((s, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setImageUrl(s.url)}
                      className="text-[10px] p-1 rounded-lg border border-slate-200 dark:border-slate-700 hover:border-sky-500 text-slate-600 dark:text-slate-300 truncate text-left"
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-2 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold shadow-sm"
                >
                  {editingBannerId ? 'আপডেট করুন' : 'ব্যানার প্রকাশ করুন'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
