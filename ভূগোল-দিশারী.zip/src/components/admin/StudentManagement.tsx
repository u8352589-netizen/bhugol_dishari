import React, { useState, useMemo } from 'react';
import {
  Users,
  UserPlus,
  Search,
  Filter,
  Eye,
  Edit,
  Trash2,
  Archive,
  RotateCcw,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Phone,
  MessageCircle,
  Calendar,
  School,
  MapPin,
  Sparkles,
  X,
  Save,
  Check,
  CreditCard,
  GraduationCap,
  ChevronRight,
  Send,
  Copy,
  Clock,
  UserCheck,
  FileSpreadsheet,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { StudentUser } from '../../types';
import {
  ACADEMIC_MONTHS_2026,
  ACADEMIC_MONTHS_BN_MAP,
  isMonthPaidForStudent,
  evaluateStudentFeeStatus,
  createWhatsAppReminderLink,
  buildReminderMessage,
  getMonthInfo,
} from '../../utils/feeReminderUtils';

const CLASS_OPTIONS = ['Class 9', 'Class 10', 'Class 11', 'Class 12'] as const;

interface StudentManagementProps {
  onNavigateTab?: (tabId: string) => void;
}

export const StudentManagement: React.FC<StudentManagementProps> = ({ onNavigateTab }) => {
  const {
    studentRoster,
    addStudent,
    updateStudent,
    deleteStudent,
    archiveStudent,
    restoreStudent,
    toggleStudentPaidMonth,
    feePayments,
    paymentSettings,
    showToast,
  } = useApp();

  // Active Class Tab: 'ALL' | 'Class 9' | 'Class 10' | 'Class 11' | 'Class 12' | 'ARCHIVED'
  const [selectedClass, setSelectedClass] = useState<string>('Class 10');
  const [searchQuery, setSearchQuery] = useState('');
  const [feeStatusFilter, setFeeStatusFilter] = useState<'ALL' | 'PAID' | 'DUE'>('ALL');

  // Modal States
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<StudentUser | null>(null);
  const [viewingStudent, setViewingStudent] = useState<StudentUser | null>(null);
  const [studentToDelete, setStudentToDelete] = useState<StudentUser | null>(null);
  const [whatsappModalStudent, setWhatsappModalStudent] = useState<StudentUser | null>(null);

  // Form State for Add / Edit
  const [formData, setFormData] = useState({
    name: '',
    fatherName: '',
    phone: '',
    email: '',
    rollNumber: '',
    classLevel: 'Class 10',
    admissionDate: new Date().toISOString().split('T')[0],
    schoolName: '',
    district: 'Paschim Medinipur',
    paidMonths: [] as string[],
    notes: '',
  });

  const monthInfo = useMemo(() => getMonthInfo(new Date()), []);

  // Compute counts per class
  const classCounts = useMemo(() => {
    const counts: Record<string, number> = {
      ALL: 0,
      'Class 9': 0,
      'Class 10': 0,
      'Class 11': 0,
      'Class 12': 0,
      ARCHIVED: 0,
    };

    studentRoster.forEach((s) => {
      if (s.status === 'ARCHIVED') {
        counts.ARCHIVED += 1;
      } else {
        counts.ALL += 1;
        if (counts[s.classLevel] !== undefined) {
          counts[s.classLevel] += 1;
        }
      }
    });

    return counts;
  }, [studentRoster]);

  // Filtered Students List
  const filteredStudents = useMemo(() => {
    return studentRoster.filter((student) => {
      // 1. Class filter
      if (selectedClass === 'ARCHIVED') {
        if (student.status !== 'ARCHIVED') return false;
      } else {
        if (student.status === 'ARCHIVED') return false;
        if (selectedClass !== 'ALL' && student.classLevel !== selectedClass) {
          return false;
        }
      }

      // 2. Search query filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchName = student.name.toLowerCase().includes(q);
        const matchRoll = student.rollNumber.toLowerCase().includes(q);
        const matchPhone = student.phone.includes(q);
        const matchFather = student.fatherName?.toLowerCase().includes(q) || false;
        const matchSchool = student.schoolName.toLowerCase().includes(q);
        if (!matchName && !matchRoll && !matchPhone && !matchFather && !matchSchool) {
          return false;
        }
      }

      // 3. Fee status filter
      if (feeStatusFilter !== 'ALL') {
        const feeStatus = evaluateStudentFeeStatus(student, feePayments, paymentSettings);
        const isPaid = feeStatus.status === 'PAID';
        if (feeStatusFilter === 'PAID' && !isPaid) return false;
        if (feeStatusFilter === 'DUE' && isPaid) return false;
      }

      return true;
    });
  }, [studentRoster, selectedClass, searchQuery, feeStatusFilter, feePayments, paymentSettings]);

  // Calculate Fee Summary for current filtered list
  const feeSummary = useMemo(() => {
    let paidCount = 0;
    let dueCount = 0;
    filteredStudents.forEach((student) => {
      const status = evaluateStudentFeeStatus(student, feePayments, paymentSettings);
      if (status.status === 'PAID') {
        paidCount++;
      } else {
        dueCount++;
      }
    });
    return { paidCount, dueCount, total: filteredStudents.length };
  }, [filteredStudents, feePayments, paymentSettings]);

  // Open Add Modal
  const handleOpenAddModal = (presetClass?: string) => {
    const targetClass =
      presetClass && CLASS_OPTIONS.includes(presetClass as any)
        ? presetClass
        : selectedClass !== 'ALL' && selectedClass !== 'ARCHIVED'
        ? selectedClass
        : 'Class 10';

    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    setFormData({
      name: '',
      fatherName: '',
      phone: '',
      email: '',
      rollNumber: `BD-2026-${randomSuffix}`,
      classLevel: targetClass,
      admissionDate: new Date().toISOString().split('T')[0],
      schoolName: '',
      district: 'Paschim Medinipur, West Bengal',
      paidMonths: [monthInfo.currentMonthEn],
      notes: '',
    });
    setIsAddModalOpen(true);
  };

  // Open Edit Modal
  const handleOpenEditModal = (student: StudentUser) => {
    setEditingStudent(student);
    setFormData({
      name: student.name,
      fatherName: student.fatherName || '',
      phone: student.phone || '',
      email: student.email || '',
      rollNumber: student.rollNumber || '',
      classLevel: student.classLevel || 'Class 10',
      admissionDate: student.admissionDate || student.joinDate || new Date().toISOString().split('T')[0],
      schoolName: student.schoolName || '',
      district: student.district || 'West Bengal',
      paidMonths: student.paidMonths ? [...student.paidMonths] : [],
      notes: student.notes || '',
    });
  };

  // Submit Add / Edit Form
  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim()) {
      showToast('ত্রুটি', 'অনুগ্রহ করে শিক্ষার্থীর নাম লিখুন', 'error');
      return;
    }
    if (!formData.phone.trim()) {
      showToast('ত্রুটি', 'মোবাইল নম্বর প্রদান আবশ্যক', 'error');
      return;
    }

    // Standardize phone number with 91 prefix
    let cleanPhone = formData.phone.replace(/[^0-9]/g, '');
    if (cleanPhone.length === 10) {
      cleanPhone = '91' + cleanPhone;
    }

    if (editingStudent) {
      // Update existing student
      updateStudent(editingStudent.id, {
        name: formData.name.trim(),
        fatherName: formData.fatherName.trim(),
        phone: cleanPhone,
        email: formData.email.trim() || `${formData.name.toLowerCase().replace(/\s+/g, '.')}@student.com`,
        rollNumber: formData.rollNumber.trim(),
        classLevel: formData.classLevel,
        admissionDate: formData.admissionDate,
        schoolName: formData.schoolName.trim() || 'High School',
        district: formData.district.trim(),
        paidMonths: formData.paidMonths,
        notes: formData.notes.trim(),
      });
      showToast('আপডেট সফল', `${formData.name}-এর তথ্য সফলভাবে আপডেট হয়েছে`, 'success');
      setEditingStudent(null);
    } else {
      // Add new student
      const newStudent = addStudent({
        name: formData.name.trim(),
        fatherName: formData.fatherName.trim(),
        phone: cleanPhone,
        email: formData.email.trim() || `${formData.name.toLowerCase().replace(/\s+/g, '.')}@student.com`,
        rollNumber: formData.rollNumber.trim(),
        classLevel: formData.classLevel,
        admissionDate: formData.admissionDate,
        schoolName: formData.schoolName.trim() || 'High School',
        district: formData.district.trim(),
        paidMonths: formData.paidMonths,
        status: 'ACTIVE',
        attendancePercentage: 95,
        avatarUrl: `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80`,
        organizationCode: 'WZKHLU',
        enrolledCourseIds: ['c-madhyamik'],
        joinDate: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }),
        notes: formData.notes.trim(),
      });
      showToast('শিক্ষার্থী যুক্ত হয়েছে', `${newStudent.name} (${newStudent.classLevel})-কে সফলভাবে তালিকায় যুক্ত করা হয়েছে`, 'success');
      setIsAddModalOpen(false);
    }
  };

  // Toggle Month in Form State
  const handleToggleFormMonth = (month: string) => {
    setFormData((prev) => {
      const exists = prev.paidMonths.includes(month);
      return {
        ...prev,
        paidMonths: exists
          ? prev.paidMonths.filter((m) => m !== month)
          : [...prev.paidMonths, month],
      };
    });
  };

  // Mark all months up to current
  const handleSelectMonthsUpToCurrent = () => {
    const currentMonthIdx = new Date().getMonth(); // 0 to 11
    const monthsToSelect = ACADEMIC_MONTHS_2026.slice(0, currentMonthIdx + 1);
    setFormData((prev) => ({
      ...prev,
      paidMonths: Array.from(new Set([...prev.paidMonths, ...monthsToSelect])),
    }));
  };

  // Copy Phone Numbers
  const handleCopyPhones = () => {
    const phones = filteredStudents
      .map((s) => s.phone)
      .filter(Boolean)
      .join(', ');
    navigator.clipboard.writeText(phones);
    showToast('কপি সম্পন্ন', `${filteredStudents.length} জন শিক্ষার্থীর ফোন নম্বর ক্লিপবোর্ডে কপি করা হয়েছে`, 'info');
  };

  return (
    <div className="space-y-6 pb-12">
      {/* 1. Header Banner & Class Selector */}
      <div className="bg-slate-900/95 border border-slate-800 rounded-3xl p-6 md:p-8 text-white shadow-xl relative overflow-hidden">
        {/* Background glow */}
        <div className="absolute -right-16 -top-16 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute right-1/3 -bottom-20 w-80 h-80 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold mb-3 border border-emerald-500/30">
              <GraduationCap className="w-4 h-4" />
              <span>শ্রেণিভিত্তিক শিক্ষার্থী ম্যানেজমেন্ট হাব • Class-wise Roster</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight text-white flex items-center gap-3">
              শিক্ষার্থী তথ্য ও ফি ট্র্যাকিং
            </h1>
            <p className="text-slate-300 text-sm mt-1 max-w-2xl leading-relaxed">
              নবম, দশম, একাদশ ও দ্বাদশ শ্রেণির ছাত্রছাত্রীদের তালিকা, পিতার নাম, মোবাইল নম্বর, ভর্তির তারিখ
              এবং প্রতি মাসের ফি পরিশোধের হিসাব সহজে নিয়ন্ত্রণ করুন।
            </p>
          </div>

          {/* Quick Action Add Student Button */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => handleOpenAddModal()}
              className="px-5 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-sm shadow-lg shadow-emerald-500/25 transition-all flex items-center gap-2 active:scale-95"
            >
              <UserPlus className="w-4 h-4" />
              <span>নতুন শিক্ষার্থী যোগ করুন</span>
            </button>

            {onNavigateTab && (
              <button
                onClick={() => onNavigateTab('fee_reminders')}
                className="px-4 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 transition-all flex items-center gap-1.5"
              >
                <span>ফি রিমাইন্ডার হাব</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Class-wise Selection Pills */}
        <div className="mt-8 pt-6 border-t border-slate-800/80 flex flex-wrap items-center gap-2">
          <span className="text-xs font-bold text-slate-400 mr-2 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" /> শ্রেণি নির্বাচন:
          </span>

          {[
            { id: 'ALL', label: 'সকল শ্রেণি', sub: 'All Classes', count: classCounts.ALL },
            { id: 'Class 9', label: 'Class 9', sub: 'নবম শ্রেণি', count: classCounts['Class 9'] },
            { id: 'Class 10', label: 'Class 10', sub: 'দশম শ্রেণি', count: classCounts['Class 10'] },
            { id: 'Class 11', label: 'Class 11', sub: 'একাদশ শ্রেণি', count: classCounts['Class 11'] },
            { id: 'Class 12', label: 'Class 12', sub: 'দ্বাদশ শ্রেণি', count: classCounts['Class 12'] },
            { id: 'ARCHIVED', label: 'আর্কাইভ / প্রাক্তনী', sub: 'Archived', count: classCounts.ARCHIVED },
          ].map((cls) => {
            const isActive = selectedClass === cls.id;
            return (
              <button
                key={cls.id}
                onClick={() => setSelectedClass(cls.id)}
                className={`px-4 py-2.5 rounded-2xl font-bold text-xs transition-all flex items-center gap-2 border ${
                  isActive
                    ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-md shadow-emerald-500/20'
                    : 'bg-slate-800/70 hover:bg-slate-800 text-slate-300 border-slate-700/80'
                }`}
              >
                <span>{cls.label}</span>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-black ${
                  isActive ? 'bg-slate-950/20 text-slate-950' : 'bg-slate-700 text-slate-300'
                }`}>
                  {cls.count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Stats Bar & Search Toolbar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 dark:text-slate-400 font-semibold block">
              {selectedClass === 'ALL' ? 'মোট সক্রিয় শিক্ষার্থী' : `${selectedClass}-এ মোট ছাত্রছাত্রী`}
            </span>
            <span className="text-2xl font-black text-slate-900 dark:text-white">
              {feeSummary.total} <span className="text-xs font-normal text-slate-500">জন</span>
            </span>
          </div>
          <div className="w-11 h-11 rounded-2xl bg-sky-50 dark:bg-sky-950/40 text-sky-600 dark:text-sky-400 flex items-center justify-center font-bold">
            <Users className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 dark:text-slate-400 font-semibold block">
              চলতি মাসের ফি পরিশোধিত
            </span>
            <span className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
              {feeSummary.paidCount} <span className="text-xs font-normal text-slate-500">জন</span>
            </span>
          </div>
          <div className="w-11 h-11 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 dark:text-slate-400 font-semibold block">
              ফি বকেয়া / স্মরণযোগ্য
            </span>
            <span className="text-2xl font-black text-amber-600 dark:text-amber-400">
              {feeSummary.dueCount} <span className="text-xs font-normal text-slate-500">জন</span>
            </span>
          </div>
          <div className="w-11 h-11 rounded-2xl bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold">
            <AlertCircle className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* 3. Search Bar, Filter & Quick Tools */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Search input */}
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="নাম, রোল, পিতা বা ফোন নম্বর দিয়ে খুঁজুন..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-9 py-2.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 rounded-xl text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Filter Pills & Actions */}
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto justify-between md:justify-end">
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs font-semibold">
            <button
              onClick={() => setFeeStatusFilter('ALL')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                feeStatusFilter === 'ALL'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800'
              }`}
            >
              সব
            </button>
            <button
              onClick={() => setFeeStatusFilter('PAID')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                feeStatusFilter === 'PAID'
                  ? 'bg-emerald-500 text-white shadow-xs'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800'
              }`}
            >
              পেইড (Paid)
            </button>
            <button
              onClick={() => setFeeStatusFilter('DUE')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                feeStatusFilter === 'DUE'
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-xs'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800'
              }`}
            >
              বকেয়া (Due)
            </button>
          </div>

          <button
            onClick={handleCopyPhones}
            title="বর্তমান ফিল্টারের সকল ফোন নম্বর কপি করুন"
            className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold transition-all flex items-center gap-1.5"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>ফোন কপি</span>
          </button>
        </div>
      </div>

      {/* 4. Student Roster Table / Card List */}
      {filteredStudents.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-dashed border-slate-300 dark:border-slate-800 rounded-3xl p-12 text-center">
          <div className="w-14 h-14 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-400 flex items-center justify-center mx-auto mb-4">
            <Users className="w-7 h-7" />
          </div>
          <h3 className="text-base font-bold text-slate-800 dark:text-slate-200">
            কোনো শিক্ষার্থী পাওয়া যায়নি
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-md mx-auto">
            {searchQuery
              ? `"${searchQuery}" এর সাথে মিলে এমন কোনো শিক্ষার্থী নেই। অনুসন্ধান ফিল্টার পরিবর্তন করুন।`
              : `${selectedClass}-এর জন্য এখনও কোনো শিক্ষার্থী যুক্ত করা হয়নি।`}
          </p>
          <button
            onClick={() => handleOpenAddModal(selectedClass !== 'ARCHIVED' ? selectedClass : 'Class 10')}
            className="mt-5 px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs inline-flex items-center gap-2 shadow-md"
          >
            <UserPlus className="w-4 h-4" />
            <span>নতুন শিক্ষার্থী যোগ করুন</span>
          </button>
        </div>
      ) : (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-xs overflow-hidden">
          {/* Table Header for Desktop */}
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-800/50 text-[11px] font-black uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  <th className="py-3.5 px-4">শিক্ষার্থী ও রোল</th>
                  <th className="py-3.5 px-4">শ্রেণি ও প্রতিষ্ঠান</th>
                  <th className="py-3.5 px-4">পিতার নাম ও যোগাযোগ</th>
                  <th className="py-3.5 px-4">ভর্তির তারিখ</th>
                  <th className="py-3.5 px-4">ফি পরিশোধ স্ট্যাটাস</th>
                  <th className="py-3.5 px-4 text-right">ম্যানেজমেন্ট ও অ্যাকশন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 text-xs">
                {filteredStudents.map((student) => {
                  const feeStatus = evaluateStudentFeeStatus(student, feePayments, paymentSettings);
                  const isPaid = feeStatus.status === 'PAID';
                  const paidMonthsCount = student.paidMonths?.length || 0;

                  return (
                    <tr
                      key={student.id}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors group"
                    >
                      {/* 1. Name & Roll */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={student.avatarUrl}
                            alt={student.name}
                            className="w-10 h-10 rounded-2xl object-cover border border-slate-200 dark:border-slate-700 shadow-xs"
                            onError={(e) => {
                              (e.target as HTMLElement).style.display = 'none';
                            }}
                          />
                          <div>
                            <div className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                              <span>{student.name}</span>
                              {student.status === 'ARCHIVED' && (
                                <span className="text-[9px] px-1.5 py-0.2 rounded-md bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 font-semibold">
                                  আর্কাইভড
                                </span>
                              )}
                            </div>
                            <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                              {student.rollNumber}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* 2. Class & School */}
                      <td className="py-3.5 px-4">
                        <span className="inline-block px-2 py-0.5 rounded-lg bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300 font-bold text-[11px] border border-sky-200 dark:border-sky-800/50 mb-0.5">
                          {student.classLevel}
                        </span>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate max-w-[170px]" title={student.schoolName}>
                          {student.schoolName || 'বিদ্যালয় উল্লেখ নেই'}
                        </div>
                      </td>

                      {/* 3. Father's Name & Phone */}
                      <td className="py-3.5 px-4">
                        <div className="font-medium text-slate-800 dark:text-slate-200">
                          {student.fatherName ? `পিতা: ${student.fatherName}` : 'পিতার নাম নেই'}
                        </div>
                        <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400 flex items-center gap-1 mt-0.5">
                          <Phone className="w-3 h-3 text-slate-400" />
                          <span>{student.phone}</span>
                        </div>
                      </td>

                      {/* 4. Admission Date */}
                      <td className="py-3.5 px-4">
                        <div className="text-slate-700 dark:text-slate-300 font-medium">
                          {student.admissionDate || student.joinDate || '২০২৬'}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          উপস্থিতি: {student.attendancePercentage}%
                        </div>
                      </td>

                      {/* 5. Fee Status Indicator */}
                      <td className="py-3.5 px-4">
                        <div className="space-y-1">
                          {isPaid ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 font-black text-[11px] border border-emerald-200 dark:border-emerald-800">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                              <span>পরিশোধিত (Paid)</span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 font-black text-[11px] border border-amber-200 dark:border-amber-800">
                              <AlertCircle className="w-3.5 h-3.5 text-amber-500" />
                              <span>বকেয়া ({feeStatus.monthInfo.previousMonthBn})</span>
                            </span>
                          )}
                          <div className="text-[10px] text-slate-500 dark:text-slate-400 font-medium">
                            {paidMonthsCount > 0 ? `${paidMonthsCount}টি মাস পেইড` : 'কোনো মাস পেইড মার্ক করা নেই'}
                          </div>
                        </div>
                      </td>

                      {/* 6. Management & Access Options */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* View Button */}
                          <button
                            onClick={() => setViewingStudent(student)}
                            title="সম্পূর্ণ প্রোফাইল ও বিবরণ দেখুন"
                            className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition-all active:scale-95"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          {/* Edit Button */}
                          <button
                            onClick={() => handleOpenEditModal(student)}
                            title="তথ্য এডিট ও পরিবর্তন করুন"
                            className="p-2 rounded-xl bg-sky-50 hover:bg-sky-100 dark:bg-sky-950/50 dark:hover:bg-sky-900/60 text-sky-600 dark:text-sky-300 transition-all active:scale-95"
                          >
                            <Edit className="w-4 h-4" />
                          </button>

                          {/* WhatsApp Reminder Button */}
                          <button
                            onClick={() => setWhatsappModalStudent(student)}
                            title="সরাসরি WhatsApp বার্তা বা রিমাইন্ডার পাঠান"
                            className="p-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/50 dark:hover:bg-emerald-900/60 text-emerald-600 dark:text-emerald-300 transition-all active:scale-95"
                          >
                            <MessageCircle className="w-4 h-4" />
                          </button>

                          {/* Archive or Restore */}
                          {student.status === 'ARCHIVED' ? (
                            <button
                              onClick={() => restoreStudent(student.id)}
                              title="সক্রিয় তালিকায় পুনরুদ্ধার করুন"
                              className="p-2 rounded-xl bg-teal-50 hover:bg-teal-100 dark:bg-teal-950/50 dark:hover:bg-teal-900/60 text-teal-600 dark:text-teal-300 transition-all"
                            >
                              <RotateCcw className="w-4 h-4" />
                            </button>
                          ) : (
                            <button
                              onClick={() => archiveStudent(student.id)}
                              title="উত্তীর্ণ বা আর্কাইভ তালিকায় স্থানান্তর করুন"
                              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 transition-all"
                            >
                              <Archive className="w-4 h-4" />
                            </button>
                          )}

                          {/* Delete Button */}
                          <button
                            onClick={() => setStudentToDelete(student)}
                            title="তালিকা থেকে অপসারণ করুন"
                            className="p-2 rounded-xl bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/50 dark:hover:bg-rose-900/60 text-rose-600 dark:text-rose-400 transition-all"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL 1: ADD / EDIT STUDENT MODAL */}
      {/* ========================================================= */}
      {(isAddModalOpen || editingStudent) && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="px-6 py-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/80 dark:bg-slate-800/50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
                  {editingStudent ? <Edit className="w-5 h-5" /> : <UserPlus className="w-5 h-5" />}
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900 dark:text-white">
                    {editingStudent ? 'শিক্ষার্থীর তথ্য পরিবর্তন (Edit Student)' : 'নতুন শিক্ষার্থী নিবন্ধন (Add Student)'}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {editingStudent
                      ? `রোল: ${editingStudent.rollNumber} • শ্রেণি: ${editingStudent.classLevel}`
                      : 'শিক্ষার্থীর নাম, পিতা, মোবাইল নম্বর ও ফি পরিশোধের মাস পূরণ করুন'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setIsAddModalOpen(false);
                  setEditingStudent(null);
                }}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSubmitForm} className="p-6 space-y-5">
              {/* Row 1: Name & Class */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    শিক্ষার্থীর নাম (Student Name) *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: শুভজিৎ অধিকারী"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    শ্রেণি নির্বাচন (Class) *
                  </label>
                  <select
                    value={formData.classLevel}
                    onChange={(e) => setFormData({ ...formData, classLevel: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden font-bold"
                  >
                    {CLASS_OPTIONS.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Row 2: Father's Name & Mobile Number */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    পিতার নাম (Father's Name) *
                  </label>
                  <input
                    type="text"
                    placeholder="যেমন: প্রদীপ অধিকারী"
                    value={formData.fatherName}
                    onChange={(e) => setFormData({ ...formData, fatherName: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    মোবাইল নম্বর (Mobile Number) *
                  </label>
                  <div className="relative">
                    <input
                      type="tel"
                      required
                      placeholder="10 ডিজিট মোবাইল নম্বর"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Row 3: Admission Date & Roll Number */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    ভর্তির তারিখ (Admission Date) *
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.admissionDate}
                    onChange={(e) => setFormData({ ...formData, admissionDate: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    রোল নম্বর (Roll Number)
                  </label>
                  <input
                    type="text"
                    value={formData.rollNumber}
                    onChange={(e) => setFormData({ ...formData, rollNumber: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden font-mono"
                  />
                </div>
              </div>

              {/* Row 4: School Name & District */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    বিদ্যালয়ের নাম (School Name)
                  </label>
                  <input
                    type="text"
                    placeholder="যেমন: খড়গপুর সিলভার জুবিলি হাই স্কুল"
                    value={formData.schoolName}
                    onChange={(e) => setFormData({ ...formData, schoolName: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    জেলা / স্থান (District)
                  </label>
                  <input
                    type="text"
                    placeholder="যেমন: পশ্চিম মেদিনীপুর"
                    value={formData.district}
                    onChange={(e) => setFormData({ ...formData, district: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                </div>
              </div>

              {/* SECTION: Paid Months Tracking */}
              <div className="pt-3 border-t border-slate-200 dark:border-slate-800">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <label className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
                      <CreditCard className="w-4 h-4 text-emerald-500" />
                      <span>ফি পরিশোধিত মাস ট্র্যাকিং (Paid Months Tracking)</span>
                    </label>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400">
                      কোন কোন মাসের ফি এই শিক্ষার্থী পরিশোধ করেছে তা টিকচিহ্ন দিয়ে নির্ধারণ করুন:
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={handleSelectMonthsUpToCurrent}
                    className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 hover:underline"
                  >
                    চলতি মাস পর্যন্ত পেইড করুন
                  </button>
                </div>

                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 mt-3">
                  {ACADEMIC_MONTHS_2026.map((month) => {
                    const isChecked = formData.paidMonths.includes(month);
                    const bnLabel = ACADEMIC_MONTHS_BN_MAP[month] || month;
                    return (
                      <button
                        type="button"
                        key={month}
                        onClick={() => handleToggleFormMonth(month)}
                        className={`p-2.5 rounded-xl border text-left transition-all flex items-center justify-between ${
                          isChecked
                            ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-400 text-emerald-900 dark:text-emerald-200 font-bold'
                            : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                        }`}
                      >
                        <span className="text-[11px] truncate">{bnLabel}</span>
                        {isChecked ? (
                          <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 ml-1" />
                        ) : (
                          <div className="w-3.5 h-3.5 rounded-full border border-slate-300 dark:border-slate-600 shrink-0 ml-1" />
                        )}
                      </button>
                    );
                  })}
                </div>
                <div className="mt-2 text-[11px] text-slate-500 flex items-center justify-between">
                  <span>মোট পরিশোধিত: <strong className="text-emerald-600 dark:text-emerald-400 font-black">{formData.paidMonths.length}টি মাস</strong></span>
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, paidMonths: [] })}
                    className="text-[11px] text-rose-500 hover:underline"
                  >
                    সব খালি করুন
                  </button>
                </div>
              </div>

              {/* Modal Buttons */}
              <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddModalOpen(false);
                    setEditingStudent(null);
                  }}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  বাতিল করুন
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs shadow-md shadow-emerald-500/20 flex items-center gap-1.5 active:scale-95"
                >
                  <Save className="w-4 h-4" />
                  <span>{editingStudent ? 'আপডেট সংরক্ষণ করুন' : 'শিক্ষার্থী যুক্ত করুন'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL 2: FULL STUDENT PROFILE VIEW MODAL */}
      {/* ========================================================= */}
      {viewingStudent && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
            {/* View Header */}
            <div className="relative p-6 bg-gradient-to-r from-slate-900 to-slate-800 text-white">
              <button
                onClick={() => setViewingStudent(null)}
                className="absolute right-4 top-4 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-700/50"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-4">
                <img
                  src={viewingStudent.avatarUrl}
                  alt={viewingStudent.name}
                  className="w-16 h-16 rounded-2xl object-cover border-2 border-emerald-500 shadow-md"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-xl font-black text-white">{viewingStudent.name}</h3>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/30">
                      {viewingStudent.classLevel}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 font-mono mt-0.5">
                    রোল: {viewingStudent.rollNumber}
                  </p>
                  <p className="text-xs text-slate-400 mt-0.5 flex items-center gap-1">
                    <School className="w-3.5 h-3.5" />
                    <span>{viewingStudent.schoolName || 'স্কুল উল্লেখ নেই'}</span>
                  </p>
                </div>
              </div>
            </div>

            {/* View Details Body */}
            <div className="p-6 space-y-5">
              {/* Quick Contact & WhatsApp Actions */}
              <div className="flex flex-wrap items-center gap-2 p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700/60">
                <a
                  href={`tel:${viewingStudent.phone}`}
                  className="flex-1 py-2 px-3 rounded-xl bg-white dark:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold text-center border border-slate-200 dark:border-slate-600 hover:bg-slate-100 flex items-center justify-center gap-1.5"
                >
                  <Phone className="w-3.5 h-3.5 text-sky-500" /> কল করুন
                </a>
                <button
                  onClick={() => {
                    const target = viewingStudent;
                    setViewingStudent(null);
                    setWhatsappModalStudent(target);
                  }}
                  className="flex-1 py-2 px-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black text-center shadow-xs flex items-center justify-center gap-1.5"
                >
                  <MessageCircle className="w-3.5 h-3.5" /> WhatsApp পাঠান
                </button>
              </div>

              {/* Information Grid */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">পিতার নাম</span>
                  <span className="font-bold text-slate-900 dark:text-white mt-0.5 block">
                    {viewingStudent.fatherName || 'উল্লেখ নেই'}
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">ভর্তির তারিখ</span>
                  <span className="font-bold text-slate-900 dark:text-white mt-0.5 block font-mono">
                    {viewingStudent.admissionDate || viewingStudent.joinDate || '২০২৬'}
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">মোবাইল নম্বর</span>
                  <span className="font-bold text-slate-900 dark:text-white mt-0.5 block font-mono">
                    {viewingStudent.phone}
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">জেলা / ঠিকানা</span>
                  <span className="font-bold text-slate-900 dark:text-white mt-0.5 block">
                    {viewingStudent.district || 'পশ্চিম মেদিনীপুর'}
                  </span>
                </div>
              </div>

              {/* Monthly Fee Paid Breakdown */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
                    <CreditCard className="w-4 h-4 text-emerald-500" />
                    <span>২০২৬ অ্যাকাডেমিক বর্ষের ফি স্ট্যাটাস</span>
                  </h4>
                  <span className="text-[11px] text-slate-500">
                    ক্লিক করে ফি পরিশোধ অন/অফ করুন
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  {ACADEMIC_MONTHS_2026.map((month) => {
                    const isPaid = isMonthPaidForStudent(viewingStudent, feePayments, month);
                    const bnMonth = ACADEMIC_MONTHS_BN_MAP[month] || month;
                    return (
                      <button
                        key={month}
                        onClick={() => toggleStudentPaidMonth(viewingStudent.id, month)}
                        className={`p-2 rounded-xl border text-left text-xs transition-all flex items-center justify-between ${
                          isPaid
                            ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 font-bold'
                            : 'bg-rose-50/50 dark:bg-rose-950/20 border-rose-200 dark:border-rose-900/40 text-rose-700 dark:text-rose-400'
                        }`}
                      >
                        <span className="text-[11px] truncate">{bnMonth.split(' ')[0]}</span>
                        {isPaid ? (
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        ) : (
                          <XCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Modal Footer */}
              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <button
                  onClick={() => {
                    const target = viewingStudent;
                    setViewingStudent(null);
                    handleOpenEditModal(target);
                  }}
                  className="px-4 py-2 rounded-xl bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-300 font-bold text-xs flex items-center gap-1.5"
                >
                  <Edit className="w-3.5 h-3.5" />
                  <span>তথ্য এডিট করুন</span>
                </button>

                <button
                  onClick={() => setViewingStudent(null)}
                  className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs"
                >
                  বন্ধ করুন
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL 3: WHATSAPP DIRECT REMINDER MODAL */}
      {/* ========================================================= */}
      {whatsappModalStudent && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="p-6 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
                  <MessageCircle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900 dark:text-white">
                    WhatsApp রিমাইন্ডার ও যোগাযোগ
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    শিক্ষার্থী: {whatsappModalStudent.name} • {whatsappModalStudent.phone}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setWhatsappModalStudent(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              {(() => {
                const feeStatus = evaluateStudentFeeStatus(whatsappModalStudent, feePayments, paymentSettings);
                const reminderMessage = buildReminderMessage(whatsappModalStudent, feeStatus, paymentSettings, 'bn');

                return (
                  <>
                    <div className="p-3.5 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-2">
                      <span className="font-bold text-slate-800 dark:text-slate-200 block text-xs">
                        Option B বার্তা (ভদ্র অথচ দৃঢ় ফি রিমাইন্ডার):
                      </span>
                      <p className="text-[11px] text-slate-600 dark:text-slate-300 whitespace-pre-line leading-relaxed font-sans max-h-40 overflow-y-auto p-2 bg-white dark:bg-slate-900/80 rounded-xl border border-slate-200 dark:border-slate-700">
                        {reminderMessage}
                      </p>
                    </div>

                    <div className="flex flex-col gap-2.5">
                      <a
                        href={createWhatsAppReminderLink(whatsappModalStudent.phone, reminderMessage)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-center shadow-md flex items-center justify-center gap-2"
                      >
                        <Send className="w-4 h-4" />
                        <span>Option B ফি রিমাইন্ডার পাঠান (WhatsApp)</span>
                      </a>

                      <a
                        href={createWhatsAppReminderLink(whatsappModalStudent.phone, `নমস্কার, ভূগোল দিশারী (নারায়ণ স্যার)-এর পক্ষ থেকে যোগাযোগ করা হচ্ছে...`)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-center flex items-center justify-center gap-2"
                      >
                        <MessageCircle className="w-4 h-4 text-emerald-500" />
                        <span>সরাসরি সাধারণ চ্যাট শুরু করুন</span>
                      </a>
                    </div>
                  </>
                );
              })()}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL 4: DELETE CONFIRMATION MODAL */}
      {/* ========================================================= */}
      {studentToDelete && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-md shadow-2xl p-6 text-center animate-in fade-in zoom-in-95 duration-200">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/15 text-rose-600 dark:text-rose-400 flex items-center justify-center mx-auto mb-3">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="text-base font-black text-slate-900 dark:text-white">
              শিক্ষার্থী অপসারণ নিশ্চিতকরণ
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed">
              আপনি কি নিশ্চিত যে <strong className="text-slate-800 dark:text-slate-200">{studentToDelete.name}</strong> ({studentToDelete.classLevel}, রোল: {studentToDelete.rollNumber})-কে তালিকা থেকে মুছে ফেলতে চান?
            </p>
            <div className="mt-5 flex items-center justify-center gap-3">
              <button
                onClick={() => setStudentToDelete(null)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                বাতিল
              </button>
              <button
                onClick={() => {
                  deleteStudent(studentToDelete.id);
                  setStudentToDelete(null);
                }}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-black text-xs shadow-md shadow-rose-600/20"
              >
                হ্যাঁ, মুছে ফেলুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
