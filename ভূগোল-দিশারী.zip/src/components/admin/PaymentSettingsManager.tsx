import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  QrCode,
  CreditCard,
  Save,
  RotateCcw,
  Upload,
  Copy,
  CheckCircle2,
  ExternalLink,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Info,
  Image as ImageIcon,
  Building,
  User,
  IndianRupee,
  Download,
  Eye,
  BellRing,
} from 'lucide-react';
import { PaymentSettings } from '../../types';

export const PaymentSettingsManager: React.FC = () => {
  const { paymentSettings, updatePaymentSettings, resetPaymentSettings, showToast, triggerSyncPulse } = useApp();

  const [upiId, setUpiId] = useState(paymentSettings.upiId);
  const [payeeName, setPayeeName] = useState(paymentSettings.payeeName);
  const [bankName, setBankName] = useState(paymentSettings.bankName);
  const [qrImageUrl, setQrImageUrl] = useState(paymentSettings.qrImageUrl);
  const [useCustomQrImage, setUseCustomQrImage] = useState(paymentSettings.useCustomQrImage);
  const [instructionsBn, setInstructionsBn] = useState(paymentSettings.instructionsBn);
  const [class9And10Fee, setClass9And10Fee] = useState(paymentSettings.classFeeStructure.class9And10.toString());
  const [class11And12Fee, setClass11And12Fee] = useState(paymentSettings.classFeeStructure.class11And12.toString());
  const [autoReminderEnabled, setAutoReminderEnabled] = useState(paymentSettings.autoReminder?.enabled ?? true);
  const [autoReminderPopupOnLogin, setAutoReminderPopupOnLogin] = useState(paymentSettings.autoReminder?.autoShowPopupOnLogin ?? true);
  const [autoReminderSimulate, setAutoReminderSimulate] = useState(paymentSettings.autoReminder?.simulateDuePeriodForTesting ?? true);
  const [copied, setCopied] = useState(false);
  const [isSavedRecently, setIsSavedRecently] = useState(false);

  // Sync state if context changes externally
  useEffect(() => {
    setUpiId(paymentSettings.upiId);
    setPayeeName(paymentSettings.payeeName);
    setBankName(paymentSettings.bankName);
    setQrImageUrl(paymentSettings.qrImageUrl);
    setUseCustomQrImage(paymentSettings.useCustomQrImage);
    setInstructionsBn(paymentSettings.instructionsBn);
    setClass9And10Fee(paymentSettings.classFeeStructure.class9And10.toString());
    setClass11And12Fee(paymentSettings.classFeeStructure.class11And12.toString());
    setAutoReminderEnabled(paymentSettings.autoReminder?.enabled ?? true);
    setAutoReminderPopupOnLogin(paymentSettings.autoReminder?.autoShowPopupOnLogin ?? true);
    setAutoReminderSimulate(paymentSettings.autoReminder?.simulateDuePeriodForTesting ?? true);
  }, [paymentSettings]);

  // Compute dynamic QR Code URL from UPI ID
  const dynamicUpiUri = `upi://pay?pa=${encodeURIComponent(upiId.trim())}&pn=${encodeURIComponent(payeeName.trim() || 'Narayan Sir')}&cu=INR&tn=${encodeURIComponent('Bhugol Dishari Tuition Fees')}`;
  const generatedQrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=400x400&margin=10&data=${encodeURIComponent(dynamicUpiUri)}`;

  // Currently displayed QR image based on toggle
  const activeDisplayQrUrl = useCustomQrImage && qrImageUrl.trim() ? qrImageUrl.trim() : generatedQrCodeUrl;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();

    if (!upiId.trim() || !upiId.includes('@')) {
      showToast('ভুল UPI আইডি', 'দয়া করে একটি বৈধ UPI আইডি লিখুন (যেমন: narayan@sbi বা 9876543210@paytm)', 'warning');
      return;
    }

    const updatedData: Partial<PaymentSettings> = {
      upiId: upiId.trim(),
      payeeName: payeeName.trim() || 'Narayan Sir (Bhugol Dishari)',
      bankName: bankName.trim() || 'State Bank of India (SBI)',
      qrImageUrl: useCustomQrImage ? qrImageUrl.trim() : generatedQrCodeUrl,
      useCustomQrImage,
      instructionsBn: instructionsBn.trim(),
      classFeeStructure: {
        class9And10: Number(class9And10Fee) || 500,
        class11And12: Number(class11And12Fee) || 600,
      },
      autoReminder: {
        ...paymentSettings.autoReminder,
        enabled: autoReminderEnabled,
        autoShowPopupOnLogin: autoReminderPopupOnLogin,
        simulateDuePeriodForTesting: autoReminderSimulate,
      },
    };

    updatePaymentSettings(updatedData);
    setIsSavedRecently(true);
    showToast('সফলভাবে সংরক্ষিত', 'UPI আইডি ও QR স্ক্যানার ছাত্রছাত্রীদের অ্যাপে লাইভ আপডেট হয়েছে!', 'success');
    setTimeout(() => setIsSavedRecently(false), 3000);
  };

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(upiId.trim());
    setCopied(true);
    showToast('কপি সম্পন্ন', `UPI ID: ${upiId} কপি করা হয়েছে`, 'info');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        showToast('ভুল ফাইল ফরম্যাট', 'দয়া করে একটি ছবি ফাইল (PNG, JPG, WebP) আপলোড করুন', 'warning');
        return;
      }
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        const base64 = uploadEvent.target?.result as string;
        setQrImageUrl(base64);
        setUseCustomQrImage(true);
        showToast('স্ক্যানার ছবি লোড হয়েছে', 'নতুন স্ক্যানার ছবি প্রিভিউতে দেখানো হচ্ছে। সংরক্ষণ করতে "পরিবর্তন সংরক্ষণ করুন" চাপুন।', 'info');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleReset = () => {
    if (window.confirm('আপনি কি নিশ্চিত যে সমস্ত পেমেন্ট সেটিংস ও স্ক্যানার ডিফল্ট মানে ফেরত নিতে চান?')) {
      resetPaymentSettings();
      showToast('রিসেট সম্পন্ন', 'ডিফল্ট UPI আইডি ও স্ক্যানার পুনরায় প্রয়োগ করা হয়েছে।', 'info');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-br from-slate-900 via-sky-950 to-slate-900 text-white border border-sky-500/20 shadow-xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-semibold border border-amber-500/30 mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Admin Payment Gateway Control • ফিস পেমেন্ট গেটওয়ে</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2.5">
              <QrCode className="w-6 h-6 text-amber-400" />
              <span>ফি পেমেন্ট UPI আইডি ও QR স্ক্যানার পরিবর্তন</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
              নারায়ণ স্যার এখান থেকে টিউশন ফি আদায়ের অফিসিয়াল UPI আইডি এবং কিউআর কোড স্ক্যানার পরিবর্তন করতে পারবেন।
              এখানে পরিবর্তন করলে শিক্ষার্থীদের মোবাইল অ্যাপের <strong>"Fees Payment"</strong> ট্যাবে তা স্বয়ংক্রিয়ভাবে রিয়েল-টাইমে আপডেট হয়ে যাবে।
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleReset}
              className="px-3.5 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition-all active:scale-95"
            >
              <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
              <span>ডিফল্ট রিসেট</span>
            </button>
            <button
              onClick={() => triggerSyncPulse('UPI আইডি ও স্ক্যানার মোবাইল ক্লায়েন্টে পাঠানো হয়েছে')}
              className="px-3.5 py-2 rounded-xl bg-sky-600/80 hover:bg-sky-600 text-white text-xs font-semibold flex items-center gap-1.5 transition-all active:scale-95"
            >
              <Smartphone className="w-3.5 h-3.5 text-sky-300" />
              <span>মোবাইল অ্যাপে সিঙ্ক টেস্ট</span>
            </button>
          </div>
        </div>

        {/* Live sync status pill */}
        <div className="mt-4 pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>সর্বশেষ আপডেট: <strong className="text-slate-200">{paymentSettings.updatedAt}</strong></span>
            <span>•</span>
            <span>দ্বারা: <strong className="text-slate-200">{paymentSettings.updatedBy}</strong></span>
          </div>
          <span className="text-sky-300">রিয়েল-টাইম ক্লাউড ফায়ারস্টোর সিঙ্ক সক্রিয়</span>
        </div>
      </div>

      {/* Main 2-Column Grid: Left is Configuration Form, Right is Mobile Student Live Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Form Controls (7 Cols) */}
        <div className="lg:col-span-7 space-y-6">
          <form onSubmit={handleSave} className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-sky-600 dark:text-sky-400" />
                <span>UPI আইডি ও অ্যাকাউন্ট তথ্য</span>
              </h3>
              <span className="text-[11px] text-slate-500">প্রয়োজনীয় সকল ফিল্ড পূরণ করুন</span>
            </div>

            {/* 1. UPI ID Field */}
            <div>
              <label className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center justify-between mb-1.5">
                <span>অফিসিয়াল UPI আইডি (Primary UPI ID) *</span>
                <span className="text-[11px] text-slate-400 font-normal">যেমন: bhugoldishari@sbi</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                  placeholder="যেমন: narayansir.bhugol@upi বা 9876543210@paytm"
                  className="w-full pl-3.5 pr-20 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-mono text-xs sm:text-sm font-bold focus:ring-2 focus:ring-sky-500 focus:outline-hidden transition-all"
                  required
                />
                <button
                  type="button"
                  onClick={handleCopyUpi}
                  className="absolute right-2 top-1/2 -translate-y-1/2 px-2.5 py-1 rounded-lg bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-[11px] font-semibold text-slate-700 dark:text-slate-200 transition-colors flex items-center gap-1"
                >
                  {copied ? <CheckCircle2 className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              {/* Quick Handle Suffix Suggestions */}
              <div className="mt-2 flex flex-wrap items-center gap-1.5 text-[11px]">
                <span className="text-slate-400">দ্রুত হ্যান্ডেল পরিবর্তন:</span>
                {['@sbi', '@okhdfcbank', '@paytm', '@ybl', '@axl', '@upi'].map((handle) => (
                  <button
                    key={handle}
                    type="button"
                    onClick={() => {
                      const prefix = upiId.split('@')[0] || 'narayansir.bhugol';
                      setUpiId(`${prefix}${handle}`);
                    }}
                    className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-sky-100 dark:hover:bg-sky-950 text-slate-600 dark:text-slate-300 hover:text-sky-600 font-mono text-[11px] border border-slate-200 dark:border-slate-700 transition-colors"
                  >
                    {handle}
                  </button>
                ))}
              </div>
            </div>

            {/* 2. Account Payee Name & Bank Name */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1 mb-1.5">
                  <User className="w-3.5 h-3.5 text-slate-400" />
                  <span>প্রাপকের নাম (Payee Name)</span>
                </label>
                <input
                  type="text"
                  value={payeeName}
                  onChange={(e) => setPayeeName(e.target.value)}
                  placeholder="Narayan Sir (Bhugol Dishari)"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white text-xs sm:text-sm focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1 mb-1.5">
                  <Building className="w-3.5 h-3.5 text-slate-400" />
                  <span>ব্যাঙ্ক বা প্ল্যাটফর্ম (Bank / Provider)</span>
                </label>
                <input
                  type="text"
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  placeholder="State Bank of India (SBI)"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white text-xs sm:text-sm focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
                />
              </div>
            </div>

            {/* 3. Scanner (QR Code) Source Selection */}
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                  <QrCode className="w-4 h-4 text-amber-500" />
                  <span>কিউআর কোড স্ক্যানার মোড নির্বাচন করুন</span>
                </label>
              </div>

              {/* Mode Radio Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <label
                  onClick={() => setUseCustomQrImage(false)}
                  className={`p-3 rounded-2xl border-2 cursor-pointer transition-all flex items-start gap-2.5 ${
                    !useCustomQrImage
                      ? 'border-sky-500 bg-sky-50/70 dark:bg-sky-950/40 text-sky-950 dark:text-sky-100 shadow-xs'
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <input
                    type="radio"
                    name="qrMode"
                    checked={!useCustomQrImage}
                    onChange={() => setUseCustomQrImage(false)}
                    className="mt-1 text-sky-600 focus:ring-sky-500"
                  />
                  <div>
                    <span className="font-bold text-xs block">অটো-জেনারেটেড UPI কিউআর</span>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400 leading-tight block mt-0.5">
                      লিখা UPI আইডি ও নাম দিয়ে সরাসরি জেনারেট হবে (PhonePe, GPay, Paytm সামঞ্জস্যপূর্ণ)
                    </span>
                  </div>
                </label>

                <label
                  onClick={() => setUseCustomQrImage(true)}
                  className={`p-3 rounded-2xl border-2 cursor-pointer transition-all flex items-start gap-2.5 ${
                    useCustomQrImage
                      ? 'border-sky-500 bg-sky-50/70 dark:bg-sky-950/40 text-sky-950 dark:text-sky-100 shadow-xs'
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <input
                    type="radio"
                    name="qrMode"
                    checked={useCustomQrImage}
                    onChange={() => setUseCustomQrImage(true)}
                    className="mt-1 text-sky-600 focus:ring-sky-500"
                  />
                  <div>
                    <span className="font-bold text-xs block">কাস্টম স্ক্যানার ছবি আপলোড / URL</span>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400 leading-tight block mt-0.5">
                      আপনার দোকান বা অ্যাকাউন্টের অফিশিয়াল কিউআর কার্ডের ছবি আপলোড করুন
                    </span>
                  </div>
                </label>
              </div>

              {/* Custom Image Upload / URL Input (when custom mode is selected) */}
              {useCustomQrImage && (
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3 animate-in fade-in">
                  <div>
                    <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                      কাস্টম কিউআর ইমেজ URL:
                    </label>
                    <input
                      type="url"
                      value={qrImageUrl}
                      onChange={(e) => setQrImageUrl(e.target.value)}
                      placeholder="https://example.com/my-scanner.jpg"
                      className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-xs font-mono text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-sky-500"
                    />
                  </div>

                  <div className="flex items-center gap-3">
                    <label className="cursor-pointer px-3.5 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5 transition-colors shadow-xs">
                      <Upload className="w-3.5 h-3.5 text-sky-600" />
                      <span>কম্পিউটার থেকে ছবি আপলোড করুন</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </label>
                    <span className="text-[11px] text-slate-400">PNG, JPG, WebP সমর্থিত</span>
                  </div>
                </div>
              )}
            </div>

            {/* 4. Monthly Fees Structure Configuration */}
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-3">
              <label className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                <IndianRupee className="w-3.5 h-3.5 text-emerald-500" />
                <span>শ্রেণিভিত্তিক মাসিক টিউশন ফি (Monthly Tuition Fees)</span>
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 block mb-1">
                    নবম ও দশম শ্রেণি (Class 9 & 10):
                  </span>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 font-bold text-xs text-slate-400">₹</span>
                    <input
                      type="number"
                      value={class9And10Fee}
                      onChange={(e) => setClass9And10Fee(e.target.value)}
                      className="w-full pl-7 pr-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-bold text-xs sm:text-sm"
                      required
                    />
                  </div>
                </div>

                <div>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 block mb-1">
                    একাদশ ও দ্বাদশ শ্রেণি (Class 11 & 12):
                  </span>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 font-bold text-xs text-slate-400">₹</span>
                    <input
                      type="number"
                      value={class11And12Fee}
                      onChange={(e) => setClass11And12Fee(e.target.value)}
                      className="w-full pl-7 pr-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-bold text-xs sm:text-sm"
                      required
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* 5. Instruction text for student */}
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
              <label className="text-xs font-bold text-slate-800 dark:text-slate-200 block mb-1.5">
                শিক্ষার্থীদের জন্য পেমেন্ট নির্দেশিকা (বাংলায়):
              </label>
              <textarea
                value={instructionsBn}
                onChange={(e) => setInstructionsBn(e.target.value)}
                rows={2}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white text-xs leading-relaxed focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
              />
            </div>

            {/* 6. In-App Automatic Fee Reminder Settings */}
            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                  <BellRing className="w-4 h-4 text-amber-500" />
                  <span>ইন-অ্যাপ স্বয়ংক্রিয় ফি রিমাইন্ডার (১লা ও ২রা তারিখ)</span>
                </label>
                <span className="text-[10px] font-black uppercase bg-amber-500/15 text-amber-700 dark:text-amber-300 px-2 py-0.5 rounded-full">
                  Automatic Routine
                </span>
              </div>

              <div className="p-3.5 rounded-2xl bg-amber-50/70 dark:bg-amber-950/25 border border-amber-200 dark:border-amber-800/50 space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-bold text-slate-800 dark:text-slate-200 block">
                      স্বয়ংক্রিয় ইন-অ্যাপ রিমাইন্ডার সচল রাখুন:
                    </span>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400">
                      ১লা ও ২রা তারিখ ছাত্রছাত্রীদের অ্যাপে স্বয়ংক্রিয় পপ-আপ ও সতর্কতা ব্যানার দেখাবে
                    </span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={autoReminderEnabled}
                      onChange={(e) => setAutoReminderEnabled(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-500"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-amber-200/60 dark:border-amber-900/50">
                  <div>
                    <span className="font-bold text-slate-800 dark:text-slate-200 block">
                      সিমুলেশন / টেস্ট মোড (১লা-২রা তারিখ সর্বদা টেস্ট করুন):
                    </span>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400">
                      সক্রিয় থাকলে যেকোনো দিনই ১লা তারিখ হিসেবে বিবেচিত হবে এবং পপ-আপ টেস্ট করা যাবে
                    </span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={autoReminderSimulate}
                      onChange={(e) => setAutoReminderSimulate(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
                  </label>
                </div>
              </div>
            </div>

            {/* Form Action Buttons */}
            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                {isSavedRecently && (
                  <span className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-600 dark:text-emerald-400 animate-in fade-in">
                    <CheckCircle2 className="w-4 h-4" /> সংরক্ষিত ও সিঙ্কড!
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-500 hover:to-blue-500 text-white font-bold text-xs shadow-md hover:shadow-lg transition-all flex items-center gap-2 active:scale-95 cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>পরিবর্তন সংরক্ষণ করুন (Save & Sync)</span>
                </button>
              </div>
            </div>
          </form>
        </div>

        {/* Right Column: Live Interactive Mobile Preview (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-4 rounded-3xl bg-slate-100 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800 shadow-sm">
            <div className="flex items-center justify-between mb-3 px-1">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-slate-300">
                <Eye className="w-4 h-4 text-sky-500" />
                <span>মোবাইল অ্যাপে যেভাবে প্রদর্শিত হবে (Live Preview)</span>
              </div>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-600 dark:text-emerald-400">
                Real-time
              </span>
            </div>

            {/* Mobile Card Simulated Container */}
            <div className="rounded-2xl bg-white dark:bg-slate-950 p-4 border border-slate-200 dark:border-slate-800 shadow-md">
              {/* Header card replica */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-sky-600 to-blue-700 text-white shadow-sm relative overflow-hidden">
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-wider text-sky-200">
                      Bhugol Dishari Tuition Fees
                    </span>
                    <h4 className="font-extrabold text-sm tracking-tight mt-0.5">
                      মাসিক টিউশন ফি পেমেন্ট
                    </h4>
                    <p className="text-[11px] text-sky-100/90 mt-0.5">
                      শিক্ষক: {payeeName || 'Narayan Sir'}
                    </p>
                  </div>
                  <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center backdrop-blur-xs">
                    <QrCode className="w-5 h-5 text-white" />
                  </div>
                </div>

                {/* Simulated UPI ID Pill */}
                <div className="mt-3 p-2.5 rounded-xl bg-slate-900/50 border border-white/20 flex items-center justify-between text-xs">
                  <div>
                    <span className="text-[10px] text-sky-200 block">অফিসিয়াল UPI আইডি:</span>
                    <span className="font-mono font-bold text-white text-xs truncate max-w-[170px] block">
                      {upiId || 'narayansir.bhugol@upi'}
                    </span>
                  </div>
                  <span className="px-2 py-0.5 rounded-lg bg-white/20 text-white text-[10px] font-semibold">
                    Copy
                  </span>
                </div>

                <div className="mt-2.5 pt-2 border-t border-white/20 flex items-center justify-between text-[11px] text-sky-100">
                  <span>৯ম/১০ম: ₹{class9And10Fee} • ১১শ/১২শ: ₹{class11And12Fee}</span>
                </div>
              </div>

              {/* Prominent QR Code Scanner Card in Student View */}
              <div className="mt-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center flex flex-col items-center">
                <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300 text-[10px] font-bold mb-2.5">
                  <QrCode className="w-3 h-3" />
                  <span>স্ক্যান করে পেমেন্ট করুন (Scan & Pay)</span>
                </div>

                {/* QR Scanner Display */}
                <div className="relative p-3 bg-white rounded-2xl border border-slate-200 shadow-sm max-w-[210px] w-full aspect-square flex items-center justify-center overflow-hidden group">
                  <img
                    src={activeDisplayQrUrl}
                    alt="Bhugol Dishari Fees QR Code"
                    className="w-full h-full object-contain rounded-lg"
                    onError={(e) => {
                      // Fallback to generated QR
                      (e.target as HTMLImageElement).src = generatedQrCodeUrl;
                    }}
                  />
                  {/* Subtle scan line decoration */}
                  <div className="absolute inset-x-3 h-0.5 bg-sky-500/80 top-1/2 -translate-y-1/2 blur-[1px] opacity-40"></div>
                </div>

                {/* Payee Details */}
                <div className="mt-3 text-center">
                  <h5 className="font-bold text-xs text-slate-900 dark:text-white">
                    {payeeName || 'Narayan Sir'}
                  </h5>
                  <p className="font-mono text-[11px] text-slate-600 dark:text-slate-400 mt-0.5 font-bold">
                    {upiId}
                  </p>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                    ব্যাঙ্ক: {bankName}
                  </p>
                </div>

                {/* Supported Payment App Icons */}
                <div className="mt-3 pt-2.5 border-t border-slate-200 dark:border-slate-800 w-full flex items-center justify-center gap-2 text-[10px] text-slate-500 font-semibold">
                  <span className="px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-800">PhonePe</span>
                  <span className="px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-800">Google Pay</span>
                  <span className="px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-800">Paytm</span>
                  <span className="px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-800">BHIM</span>
                </div>

                {/* Action Buttons */}
                <div className="mt-3 flex items-center gap-2 w-full">
                  <a
                    href={activeDisplayQrUrl}
                    download="Bhugol_Dishari_Fees_QR.png"
                    target="_blank"
                    rel="noreferrer"
                    className="flex-1 py-1.5 px-2 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-semibold text-[11px] transition-colors flex items-center justify-center gap-1"
                  >
                    <Download className="w-3 h-3" />
                    <span>QR ডাউনলোড</span>
                  </a>
                  <a
                    href={dynamicUpiUri}
                    className="flex-1 py-1.5 px-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-[11px] transition-colors flex items-center justify-center gap-1 shadow-xs"
                  >
                    <ExternalLink className="w-3 h-3" />
                    <span>UPI টেস্ট লিংক</span>
                  </a>
                </div>
              </div>

              <div className="mt-3 p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/60 text-[11px] text-amber-800 dark:text-amber-300">
                <div className="flex items-start gap-1.5">
                  <Info className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                  <span>
                    পেমেন্ট করার পর শিক্ষার্থীরা ১২ ডিজিটের UTR রেফারেন্স নম্বর সাবমিট করলে তা অ্যাডমিনের "ফি ভেরিফিকেশন কিউ"-তে চলে আসবে।
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
