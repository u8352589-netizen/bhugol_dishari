import React from 'react';
import { Home, BookOpen, CreditCard, User } from 'lucide-react';

export type StudentNavTab = 'HOME' | 'COURSE' | 'FEES' | 'PROFILE';

interface StudentBottomNavProps {
  activeTab: StudentNavTab;
  onChangeTab: (tab: StudentNavTab) => void;
  isDark?: boolean;
  hasDueFeeBadge?: boolean;
}

export const StudentBottomNav: React.FC<StudentBottomNavProps> = ({
  activeTab,
  onChangeTab,
  isDark = false,
  hasDueFeeBadge = false,
}) => {
  const tabs = [
    { id: 'HOME' as StudentNavTab, label: 'Home', icon: Home },
    { id: 'COURSE' as StudentNavTab, label: 'Course', icon: BookOpen },
    { id: 'FEES' as StudentNavTab, label: 'Fees Payment', icon: CreditCard, hasBadge: hasDueFeeBadge },
    { id: 'PROFILE' as StudentNavTab, label: 'Profile', icon: User },
  ];

  return (
    <div
      className={`h-14 px-2 flex items-center justify-around border-t select-none transition-colors ${
        isDark
          ? 'bg-slate-900 border-slate-800 text-slate-400'
          : 'bg-white border-slate-200 text-slate-500 shadow-lg'
      }`}
    >
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;

        return (
          <button
            key={tab.id}
            id={`nav-${tab.id.toLowerCase()}-btn`}
            onClick={() => onChangeTab(tab.id)}
            className={`flex-1 flex flex-col items-center justify-center py-1 relative transition-all duration-200 ${
              isActive
                ? 'text-sky-600 dark:text-sky-400 font-bold scale-105'
                : 'hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <div className="relative">
              <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5px]' : 'stroke-2'}`} />
              {tab.hasBadge && (
                <span className="absolute -top-1.5 -right-2 flex h-3.5 w-3.5 items-center justify-center">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500 border border-white dark:border-slate-900"></span>
                </span>
              )}
              {isActive && (
                <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-sky-600 dark:bg-sky-400" />
              )}
            </div>
            <span className="text-[10px] tracking-tight mt-1 whitespace-nowrap">
              {tab.label}
            </span>
          </button>
        );
      })}
    </div>
  );
};
