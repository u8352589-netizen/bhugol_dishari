import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { ChevronLeft, ChevronRight, Tag } from 'lucide-react';

interface BannerCarouselProps {
  onSelectBanner?: (targetCourseId?: string) => void;
}

export const BannerCarousel: React.FC<BannerCarouselProps> = ({ onSelectBanner }) => {
  const { banners } = useApp();
  const activeBanners = banners.filter((b) => b.active).slice(0, 5);
  const [currentIndex, setCurrentIndex] = useState(0);

  // Auto-slide effect every 4.2 seconds
  useEffect(() => {
    if (activeBanners.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % activeBanners.length);
    }, 4200);
    return () => clearInterval(interval);
  }, [activeBanners.length]);

  if (activeBanners.length === 0) {
    return (
      <div className="p-4 bg-sky-950/20 text-center rounded-xl mx-3 my-2 border border-sky-500/20">
        <p className="text-xs text-slate-500">কোনো সক্রিয় ব্যানার নেই (অ্যাডমিন প্যানেল থেকে ব্যানার যুক্ত করুন)</p>
      </div>
    );
  }

  const currentBanner = activeBanners[currentIndex] || activeBanners[0];

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentIndex((prev) => (prev - 1 + activeBanners.length) % activeBanners.length);
  };

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentIndex((prev) => (prev + 1) % activeBanners.length);
  };

  return (
    <div className="relative mx-3 my-2.5 overflow-hidden rounded-2xl shadow-md group">
      {/* Banner Card */}
      <div
        onClick={() => onSelectBanner?.(currentBanner.targetCourseId)}
        className="relative h-44 sm:h-48 w-full cursor-pointer bg-slate-900 overflow-hidden"
      >
        <img
          src={currentBanner.imageUrl}
          alt={currentBanner.title}
          className="w-full h-full object-cover opacity-85 group-hover:scale-105 transition-transform duration-700"
          referrerPolicy="no-referrer"
        />

        {/* Gradient Overlay for high contrast Bengali readability */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/60 to-transparent flex flex-col justify-end p-4">
          {currentBanner.discountBadge && (
            <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-amber-400 text-slate-950 font-bold text-[11px] shadow-sm mb-1.5 w-fit">
              <Tag className="w-3 h-3" />
              <span>{currentBanner.discountBadge}</span>
            </div>
          )}

          <h3 className="font-extrabold text-sm sm:text-base text-white tracking-tight drop-shadow-sm line-clamp-1">
            {currentBanner.title}
          </h3>

          {currentBanner.subtitle && (
            <p className="text-xs text-sky-200/90 font-medium line-clamp-1 drop-shadow-xs mt-0.5">
              {currentBanner.subtitle}
            </p>
          )}

          <div className="mt-2 flex items-center justify-between">
            <span className="text-[10px] text-amber-300 font-semibold bg-slate-900/80 px-2 py-0.5 rounded border border-amber-400/30">
              মহালয়া ও দুর্গাপূজা স্পেশাল অফার
            </span>
            <span className="text-[11px] font-bold text-sky-300 group-hover:underline">
              বিস্তারিত দেখুন →
            </span>
          </div>
        </div>
      </div>

      {/* Navigation Arrows */}
      {activeBanners.length > 1 && (
        <>
          <button
            onClick={handlePrev}
            className="absolute left-2 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-black/40 text-white flex items-center justify-center backdrop-blur-xs opacity-75 hover:opacity-100 transition-opacity"
            aria-label="Previous Banner"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <button
            onClick={handleNext}
            className="absolute right-2 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-black/40 text-white flex items-center justify-center backdrop-blur-xs opacity-75 hover:opacity-100 transition-opacity"
            aria-label="Next Banner"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </>
      )}

      {/* Pagination Dots */}
      <div className="absolute bottom-1.5 left-0 right-0 flex justify-center space-x-1.5">
        {activeBanners.map((_, idx) => (
          <button
            key={idx}
            onClick={(e) => {
              e.stopPropagation();
              setCurrentIndex(idx);
            }}
            className={`h-1.5 rounded-full transition-all duration-300 ${
              idx === currentIndex ? 'w-5 bg-amber-400' : 'w-1.5 bg-white/50'
            }`}
            aria-label={`Go to slide ${idx + 1}`}
          />
        ))}
      </div>
    </div>
  );
};
