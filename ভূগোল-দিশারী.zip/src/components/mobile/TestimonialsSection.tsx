import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Quote, Plus, Instagram, Youtube, Send } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const TestimonialsSection: React.FC = () => {
  const { showToast } = useApp();
  const [currentIndex, setCurrentIndex] = useState(0);

  const testimonials = [
    {
      id: 1,
      quote: 'নারায়ণ স্যারের ভূগোল ক্লাসের পর ভূগোল নিয়ে আর কোনো ভয় নেই। ম্যাপ পয়েন্টিং ও অধ্যায়ভিত্তিক ৩টি সামেটিভ পরীক্ষার পুরো সিলেবাস এত সহজভাবে আর কোথাও বোঝানো হয় না!',
      name: 'Ankush Bhuin',
      initial: 'A',
      bgColor: 'bg-rose-100 text-rose-600 dark:bg-rose-950/50 dark:text-rose-400',
      badge: 'Madhyamik Geography 99/100',
    },
    {
      id: 2,
      quote: 'ভূগোল দিশারী অ্যাপের Notes (PDF) সেকশন আর ৪ ডিজিট কোড লক ফিচারটা অসাধারণ। সরাসরি গুগল ড্রাইভ লিঙ্ক থেকে প্রিন্ট নেওয়ার সুবিধা দারুণ কার্যকর।',
      name: 'Sayak Mukhopadhyay',
      initial: 'S',
      bgColor: 'bg-sky-100 text-sky-600 dark:bg-sky-950/50 dark:text-sky-400',
      badge: 'WBCHSE Class 12 Sem 4',
    },
    {
      id: 3,
      quote: 'Recording Class সেকশন থেকে লাইভ ক্লাসের সমস্ত রেকর্ডিং বারবার রিভিশন দিতে পারি। নারায়ণ স্যারের চিত্রসহ ভৌগোলিক ভূমিরূপের অ্যানিমেশন অতুলনীয়।',
      name: 'Sneha Chakraborty',
      initial: 'S',
      bgColor: 'bg-amber-100 text-amber-600 dark:bg-amber-950/50 dark:text-amber-400',
      badge: 'Class 11 Topper',
    },
  ];

  const current = testimonials[currentIndex];

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <div className="px-3.5 py-3 border-t border-slate-200/60 dark:border-slate-800">
      {/* Testimonials Header matching Screenshot 1 */}
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-xs font-bold text-slate-800 dark:text-slate-200">
          What our students have to say
        </h3>
        <button
          onClick={() => showToast('মতামত জানান', 'আপনার প্রতিক্রিয়া নারায়ণ স্যারের কাছে পাঠানো হয়েছে। ধন্যবাদ!', 'success')}
          className="text-xs font-semibold text-sky-600 dark:text-sky-400 flex items-center gap-0.5 hover:underline"
        >
          <Plus className="w-3 h-3" /> Add
        </button>
      </div>

      {/* Testimonial Card matching Screenshot 1 */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/80 shadow-xs relative">
        <Quote className="w-8 h-8 text-rose-300/80 dark:text-rose-500/40 mb-2 transform -scale-x-100" />

        <p className="text-xs text-slate-700 dark:text-slate-200 leading-relaxed font-normal italic">
          "{current.quote}"
        </p>

        <div className="mt-3 flex items-center space-x-3">
          <div className={`w-9 h-9 rounded-full ${current.bgColor} flex items-center justify-center font-bold text-sm shadow-xs`}>
            {current.initial}
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-900 dark:text-white leading-tight">
              {current.name}
            </h4>
            <span className="text-[10px] text-slate-400 dark:text-slate-500 font-medium">
              {current.badge}
            </span>
          </div>
        </div>

        {/* Carousel controls matching Screenshot 1 */}
        <div className="mt-3 flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-700/50">
          <button
            onClick={handlePrev}
            className="w-7 h-7 rounded-full border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-500 hover:text-slate-900 dark:hover:text-white"
            aria-label="Previous Testimonial"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <div className="flex space-x-1.5">
            {testimonials.map((_, i) => (
              <span
                key={i}
                className={`w-1.5 h-1.5 rounded-full transition-all ${
                  i === currentIndex ? 'w-4 bg-sky-600 dark:bg-sky-400' : 'bg-slate-300 dark:bg-slate-600'
                }`}
              />
            ))}
          </div>

          <button
            onClick={handleNext}
            className="w-7 h-7 rounded-full border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-500 hover:text-slate-900 dark:hover:text-white"
            aria-label="Next Testimonial"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Connect With Us matching Screenshot 1 */}
      <div className="mt-5 mb-2">
        <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 mb-2.5">
          Connect With Us
        </h4>
        <div className="flex items-center space-x-3">
          <a
            href="https://instagram.com"
            target="_blank"
            rel="noreferrer"
            className="flex flex-col items-center space-y-1 p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-xs hover:border-pink-500 transition-colors w-20"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-pink-500 to-purple-600 p-0.5 flex items-center justify-center shadow-xs">
              <div className="w-full h-full bg-white dark:bg-slate-900 rounded-[10px] flex items-center justify-center">
                <Instagram className="w-5 h-5 text-pink-600" />
              </div>
            </div>
            <span className="text-[10px] font-medium text-slate-600 dark:text-slate-400">Instagram</span>
          </a>

          <a
            href="https://youtube.com"
            target="_blank"
            rel="noreferrer"
            className="flex flex-col items-center space-y-1 p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-xs hover:border-red-500 transition-colors w-20"
          >
            <div className="w-10 h-10 rounded-xl bg-red-600 flex items-center justify-center text-white shadow-xs">
              <Youtube className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-medium text-slate-600 dark:text-slate-400">YouTube</span>
          </a>

          <a
            href="https://telegram.org"
            target="_blank"
            rel="noreferrer"
            className="flex flex-col items-center space-y-1 p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-xs hover:border-sky-500 transition-colors w-20"
          >
            <div className="w-10 h-10 rounded-xl bg-sky-500 flex items-center justify-center text-white shadow-xs">
              <Send className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-medium text-slate-600 dark:text-slate-400">Telegram</span>
          </a>
        </div>
      </div>
    </div>
  );
};
