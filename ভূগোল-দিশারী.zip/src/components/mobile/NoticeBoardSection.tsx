import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Bell, AlertTriangle, Calendar, Award, ChevronRight, X } from 'lucide-react';
import { NoticeItem } from '../../types';

export const NoticeBoardSection: React.FC = () => {
  const { notices } = useApp();
  const [selectedNotice, setSelectedNotice] = useState<NoticeItem | null>(null);

  const getPriorityBadge = (priority: NoticeItem['priority']) => {
    switch (priority) {
      case 'URGENT':
        return (
          <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-rose-500/15 text-rose-600 dark:text-rose-400 border border-rose-500/30 flex items-center gap-1">
            <AlertTriangle className="w-2.5 h-2.5" /> জরুরি
          </span>
        );
      case 'EXAM':
        return (
          <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30 flex items-center gap-1">
            <Award className="w-2.5 h-2.5" /> পরীক্ষা নোটিস
          </span>
        );
      case 'HOLIDAY':
        return (
          <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
            <Calendar className="w-2.5 h-2.5" /> ছুটির বিজ্ঞপ্তি
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 text-[10px] font-semibold rounded-full bg-sky-500/15 text-sky-600 dark:text-sky-400 border border-sky-500/30">
            সাধারণ
          </span>
        );
    }
  };

  return (
    <div className="px-3.5 py-3">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center space-x-1.5">
          <Bell className="w-4 h-4 text-sky-600 dark:text-sky-400" />
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200">
            Notice Board (লাইভ নোটিশ বোর্ড)
          </h3>
        </div>
        <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
          {notices.length} টি সক্রিয়
        </span>
      </div>

      <div className="space-y-2">
        {notices.slice(0, 3).map((notice) => (
          <div
            key={notice.id}
            onClick={() => setSelectedNotice(notice)}
            className="p-3 rounded-xl bg-white dark:bg-slate-800/90 border border-slate-200/80 dark:border-slate-700/80 shadow-xs hover:shadow-sm cursor-pointer transition-all hover:border-sky-400"
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2">
                {getPriorityBadge(notice.priority)}
                <span className="text-[10px] text-slate-400 dark:text-slate-500">{notice.date}</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
            </div>

            <h4 className="font-semibold text-xs text-slate-900 dark:text-slate-100 mt-1.5 line-clamp-1">
              {notice.title}
            </h4>
            <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-0.5 line-clamp-2 leading-relaxed">
              {notice.message}
            </p>
          </div>
        ))}
      </div>

      {/* Notice Detail Dialog */}
      {selectedNotice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-sm w-full p-5 border border-slate-200 dark:border-slate-800 shadow-2xl animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                {getPriorityBadge(selectedNotice.priority)}
                <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                  {selectedNotice.author}
                </span>
              </div>
              <button
                onClick={() => setSelectedNotice(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <h3 className="font-bold text-sm text-slate-900 dark:text-white mt-3 leading-snug">
              {selectedNotice.title}
            </h3>

            <p className="text-xs text-slate-600 dark:text-slate-300 mt-2.5 leading-relaxed bg-slate-50 dark:bg-slate-800/50 p-3 rounded-xl border border-slate-100 dark:border-slate-700/60 whitespace-pre-line">
              {selectedNotice.message}
            </p>

            <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-500">
              <span>প্রকাশের সময়: {selectedNotice.date}</span>
              <button
                onClick={() => setSelectedNotice(null)}
                className="px-3 py-1.5 rounded-lg bg-sky-600 text-white font-medium text-xs hover:bg-sky-700"
              >
                ঠিক আছে
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
