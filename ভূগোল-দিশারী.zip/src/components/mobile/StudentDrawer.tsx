import React from 'react';
import {
  X,
  User,
  Download,
  FolderOpen,
  MessageSquareQuote,
  UserCheck,
  Settings,
  HelpCircle,
  ShieldCheck,
  Share2,
  LogOut,
  Edit2,
  BookOpen,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface StudentDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenNotesPdf: () => void;
  onOpenRecordings: () => void;
  onOpenProfile: () => void;
  onOpenAuth: () => void;
}

export const StudentDrawer: React.FC<StudentDrawerProps> = ({
  isOpen,
  onClose,
  onOpenNotesPdf,
  onOpenRecordings,
  onOpenProfile,
  onOpenAuth,
}) => {
  const { currentStudent, isDarkMode, showToast } = useApp();

  if (!isOpen) return null;

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'ভূগোল দিশারী (Bhugol Dishari) - নারায়ণ স্যার',
        text: 'পশ্চিমবঙ্গের সেরা ভূগোল অনলাইন ও অফলাইন প্রস্তুতি অ্যাপ।',
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      showToast('লিঙ্ক কপি হয়েছে', 'ভূগোল দিশারী অ্যাপের লিঙ্ক ক্লিপবোর্ডে কপি করা হয়েছে।', 'info');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-xs transition-opacity duration-300"
        onClick={onClose}
      />

      {/* Drawer Panel */}
      <div
        className={`absolute inset-y-0 left-0 max-w-[290px] w-full shadow-2xl flex flex-col z-10 transform transition-transform duration-300 ease-in-out ${
          isDarkMode ? 'bg-slate-900 text-slate-100' : 'bg-white text-slate-800'
        }`}
      >
        {/* Profile Header matching Screenshot 6 */}
        <div className={`p-5 border-b relative ${isDarkMode ? 'bg-slate-800/80 border-slate-700' : 'bg-slate-50 border-slate-100'}`}>
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="relative inline-block mb-3">
            <div className="w-16 h-16 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center overflow-hidden border-2 border-sky-500/50 shadow-inner">
              {currentStudent.avatarUrl ? (
                <img
                  src={currentStudent.avatarUrl}
                  alt={currentStudent.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <User className="w-8 h-8 text-slate-500" />
              )}
            </div>
            <button
              onClick={() => {
                onClose();
                onOpenProfile();
              }}
              className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-sky-500 text-white flex items-center justify-center shadow-md hover:bg-sky-600 transition-colors"
              title="Edit Profile"
            >
              <Edit2 className="w-3.5 h-3.5" />
            </button>
          </div>

          <h3 className="font-bold text-base tracking-tight text-slate-900 dark:text-white">
            {currentStudent.name}
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Organization Code <span className="font-semibold text-sky-600 dark:text-sky-400">{currentStudent.organizationCode}</span>
          </p>
          <span className="inline-block mt-2 px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
            {currentStudent.classLevel} • Roll: {currentStudent.rollNumber}
          </span>
        </div>

        {/* Drawer Menu Items */}
        <div className="flex-1 overflow-y-auto py-2 divide-y divide-slate-100 dark:divide-slate-800 text-sm">
          <div className="py-2 space-y-0.5 px-3">
            <button
              onClick={() => {
                onClose();
                onOpenNotesPdf();
              }}
              className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-sky-50 dark:hover:bg-slate-800/80 text-left transition-colors font-medium text-sky-600 dark:text-sky-400"
            >
              <div className="flex items-center space-x-3">
                <BookOpen className="w-5 h-5" />
                <span>Notes (PDF) Lock Module</span>
              </div>
              <span className="px-2 py-0.5 text-[10px] font-bold uppercase rounded-full bg-amber-500 text-white shadow-xs">
                PIN 🔐
              </span>
            </button>

            <button
              onClick={() => {
                onClose();
                onOpenRecordings();
              }}
              className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-left transition-colors text-slate-700 dark:text-slate-200"
            >
              <div className="flex items-center space-x-3">
                <Download className="w-5 h-5 text-slate-500" />
                <span>Offline Downloads</span>
              </div>
              <span className="px-1.5 py-0.5 text-[9px] font-bold tracking-wider uppercase rounded bg-sky-500 text-white">
                NEW
              </span>
            </button>

            <button
              onClick={() => {
                onClose();
                onOpenNotesPdf();
              }}
              className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-left transition-colors text-slate-700 dark:text-slate-200"
            >
              <FolderOpen className="w-5 h-5 text-slate-500" />
              <span>Free Study Material</span>
            </button>

            <button
              onClick={() => {
                onClose();
                showToast('ছাত্র মতামত', 'নারায়ণ স্যারের ক্লাসে মাধ্যমিক পরীক্ষায় ১০০/১০০ পেয়েছে বহু ছাত্র।', 'info');
              }}
              className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-left transition-colors text-slate-700 dark:text-slate-200"
            >
              <div className="flex items-center space-x-3">
                <MessageSquareQuote className="w-5 h-5 text-slate-500" />
                <span>Students Testimonial</span>
              </div>
              <span className="px-1.5 py-0.5 text-[9px] font-bold tracking-wider uppercase rounded bg-sky-500 text-white">
                NEW
              </span>
            </button>
          </div>

          <div className="py-2 space-y-0.5 px-3">
            <button
              onClick={() => {
                onClose();
                onOpenProfile();
              }}
              className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-left transition-colors text-slate-700 dark:text-slate-200"
            >
              <UserCheck className="w-5 h-5 text-slate-500" />
              <span>Edit Profile</span>
            </button>

            <button
              onClick={() => {
                onClose();
                showToast('সেটিংস', 'অ্যাপ সংস্করণ ২.৪.০ (ভূগোল দিশারী প্রডাকশন)', 'info');
              }}
              className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-left transition-colors text-slate-700 dark:text-slate-200"
            >
              <Settings className="w-5 h-5 text-slate-500" />
              <span>Settings</span>
            </button>

            <button
              onClick={() => {
                onClose();
                showToast('অ্যাপ নির্দেশিকা', '১. রেকর্ডিং ক্লাস দেখুন ২. ৪ ডিজিট পিন দিয়ে নোটস আনলক করুন ৩. ফি পেমেন্ট রিসিট জমা দিন।', 'info');
              }}
              className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-left transition-colors text-slate-700 dark:text-slate-200"
            >
              <div className="flex items-center space-x-3">
                <HelpCircle className="w-5 h-5 text-slate-500" />
                <span>How to use the App</span>
              </div>
              <span className="px-1.5 py-0.5 text-[9px] font-bold tracking-wider uppercase rounded bg-sky-500 text-white">
                NEW
              </span>
            </button>

            <button
              onClick={() => {
                onClose();
                showToast('গোপনীয়তা নীতি', 'ভূগোল দিশারী ছাত্রছাত্রীদের সমস্ত ব্যক্তিগত ডেটা Firebase দ্বারা সুরক্ষিত রাখে।', 'info');
              }}
              className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-left transition-colors text-slate-700 dark:text-slate-200"
            >
              <ShieldCheck className="w-5 h-5 text-slate-500" />
              <span>Privacy Policy</span>
            </button>
          </div>
        </div>

        {/* Footer & Share CTA matching Screenshot 6 */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 space-y-2.5">
          <button
            onClick={handleShare}
            className="w-full py-2.5 px-4 rounded-xl bg-[#1877F2] hover:bg-[#166fe5] text-white font-semibold text-xs flex items-center justify-center space-x-2 shadow-sm transition-colors"
          >
            <Share2 className="w-4 h-4" />
            <span>Share on facebook</span>
          </button>

          <button
            onClick={() => {
              onClose();
              onOpenAuth();
            }}
            className="w-full py-2 px-3 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-medium flex items-center justify-center space-x-2 transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Change Student / Switch Login</span>
          </button>
        </div>
      </div>
    </div>
  );
};
