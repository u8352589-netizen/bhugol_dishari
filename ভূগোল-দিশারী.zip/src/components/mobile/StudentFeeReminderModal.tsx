import React, { useState } from 'react';
import {
  BellRing,
  AlertCircle,
  QrCode,
  Copy,
  CheckCircle2,
  X,
  ArrowRight,
  MessageCircle,
  Calendar,
  CreditCard,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { StudentFeeStatus, buildReminderMessage, createWhatsAppReminderLink } from '../../utils/feeReminderUtils';

interface StudentFeeReminderModalProps {
  isOpen: boolean;
  onClose: () => void;
  feeStatus: StudentFeeStatus;
  onNavigateToFeesTab: () => void;
}

export const StudentFeeReminderModal: React.FC<StudentFeeReminderModalProps> = ({
  isOpen,
  onClose,
  feeStatus,
  onNavigateToFeesTab,
}) => {
  const { paymentSettings, showToast, isDarkMode } = useApp();
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const { student, monthInfo, amountDue } = feeStatus;
  const whatsappMsg = buildReminderMessage(student, feeStatus, paymentSettings, 'bn');
  const whatsappUrl = createWhatsAppReminderLink('919907735503', whatsappMsg);

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(paymentSettings.upiId);
    setCopied(true);
    showToast('UPI ID কপি হয়েছে', paymentSettings.upiId, 'info');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className={`w-full max-w-sm rounded-3xl overflow-hidden shadow-2xl border transition-colors ${
          isDarkMode
            ? 'bg-slate-900 border-amber-500/30 text-white'
            : 'bg-white border-amber-500/20 text-slate-900'
        }`}
      >
        {/* Urgent Header Banner */}
        <div className="relative bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 p-4 text-slate-950">
          <button
            onClick={onClose}
            className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/15 hover:bg-black/25 flex items-center justify-center transition-colors"
            title="বন্ধ করুন"
          >
            <X className="w-4 h-4 text-slate-950 font-bold" />
          </button>

          <div className="flex items-center space-x-2.5">
            <div className="w-10 h-10 rounded-2xl bg-white/30 backdrop-blur-xs flex items-center justify-center shadow-xs">
              <BellRing className="w-5 h-5 text-slate-950 animate-bounce" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-black tracking-wider bg-slate-950/15 px-2 py-0.5 rounded-full inline-block">
                অটোমেটিক ফি স্মরণপত্র
              </span>
              <h3 className="text-base font-black tracking-tight leading-tight mt-0.5">
                মাসিক টিউশন ফি রিমাইন্ডার
              </h3>
            </div>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-4 space-y-3.5 text-xs">
          {/* Rule Highlight Pill */}
          <div className="p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 flex items-start gap-2.5">
            <Calendar className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-amber-900 dark:text-amber-300 text-[11px] leading-relaxed">
                পদ্ধতি নিয়ম: পূর্ববর্তী মাস (<strong className="underline">{monthInfo.previousMonthBn}</strong>)-এর টিউশন ফি চলতি মাসের <strong>১লা ও ২রা তারিখ</strong>-এর মধ্যে পরিশোধ করতে হবে।
              </p>
            </div>
          </div>

          {/* Student & Due Summary Table */}
          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80 space-y-2">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-700">
              <span className="text-slate-500 dark:text-slate-400">শিক্ষার্থী:</span>
              <span className="font-bold text-slate-800 dark:text-slate-100">
                {student.name} ({student.rollNumber})
              </span>
            </div>

            <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-700">
              <span className="text-slate-500 dark:text-slate-400">শ্রেণি:</span>
              <span className="font-semibold text-slate-700 dark:text-slate-300">
                {student.classLevel}
              </span>
            </div>

            <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-700">
              <span className="text-slate-500 dark:text-slate-400">ফি-এর মাস:</span>
              <span className="font-bold text-sky-600 dark:text-sky-400">
                {monthInfo.previousMonthBn}
              </span>
            </div>

            <div className="flex items-center justify-between pt-0.5">
              <span className="font-bold text-slate-700 dark:text-slate-300">বকেয়া পরিমাণ:</span>
              <span className="font-black text-base text-rose-600 dark:text-rose-400">
                ₹{amountDue}
              </span>
            </div>
          </div>

          {/* UPI Quick Pay Box */}
          <div className="p-2.5 rounded-2xl bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800/50 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-sky-500 text-white flex items-center justify-center font-bold">
                <QrCode className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[10px] text-sky-600 dark:text-sky-400 font-semibold block">
                  অফিসিয়াল UPI ID:
                </span>
                <span className="font-mono font-bold text-slate-800 dark:text-slate-100 text-xs">
                  {paymentSettings.upiId}
                </span>
              </div>
            </div>
            <button
              onClick={handleCopyUpi}
              className="px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-sky-300 dark:border-sky-700 text-sky-600 dark:text-sky-300 hover:bg-sky-100 dark:hover:bg-slate-700 font-bold text-[10px] flex items-center gap-1 active:scale-95 transition-all shadow-xs"
            >
              {copied ? (
                <>
                  <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                  <span>কপি হয়েছে</span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" />
                  <span>Copy</span>
                </>
              )}
            </button>
          </div>

          {/* Action Buttons */}
          <div className="space-y-2 pt-1">
            <button
              onClick={() => {
                onClose();
                onNavigateToFeesTab();
              }}
              className="w-full py-2.5 px-4 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs shadow-md flex items-center justify-center gap-2 transition-transform active:scale-95"
            >
              <CreditCard className="w-4 h-4" />
              <span>এখনই ফি প্রদান করুন (Pay Fees)</span>
              <ArrowRight className="w-3.5 h-3.5 ml-auto" />
            </button>

            <div className="flex items-center gap-2">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noreferrer"
                className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] flex items-center justify-center gap-1.5 transition-colors shadow-xs"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>WhatsApp-এ জানান</span>
              </a>

              <button
                onClick={onClose}
                className="flex-1 py-2 px-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 font-semibold text-[11px] transition-colors"
              >
                <span>পরে মনে করান</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
