import React from 'react';
import { Play, BookMarked, FileText, Video, Lock, ArrowRight, Sparkles } from 'lucide-react';

interface ActionCardsGridProps {
  onOpenRecordings: () => void;
  onOpenNotesPdf: () => void;
  onNavigateToCourses: () => void;
  onOpenLiveSchedule: () => void;
  onOpenTestSeries: () => void;
  isDark?: boolean;
}

export const ActionCardsGrid: React.FC<ActionCardsGridProps> = ({
  onOpenRecordings,
  onOpenNotesPdf,
  onNavigateToCourses,
  onOpenLiveSchedule,
  onOpenTestSeries,
  isDark = false,
}) => {
  return (
    <div className="px-3.5 py-2">
      <div className="flex items-center justify-between mb-2.5">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
          Filter Courses
        </h3>
        <span className="text-[11px] text-sky-600 dark:text-sky-400 font-semibold">
          নারায়ণ স্যারের স্পেশাল
        </span>
      </div>

      {/* 2x2 Grid Matching Screenshot 1 */}
      <div className="grid grid-cols-2 gap-2.5">
        {/* Card 1: Live Courses (Rose gradient) */}
        <button
          onClick={onNavigateToCourses}
          className="relative overflow-hidden rounded-2xl p-3.5 h-24 bg-gradient-to-br from-rose-500 to-rose-600 text-white shadow-sm hover:shadow-md transition-all active:scale-[0.98] text-left flex flex-col justify-between group"
        >
          <div className="z-10">
            <h4 className="font-extrabold text-sm leading-tight drop-shadow-xs">
              Live<br />Courses
            </h4>
          </div>

          <div className="z-10 flex items-center justify-between">
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-xs">
              <Play className="w-4 h-4 fill-current ml-0.5" />
            </div>
          </div>

          {/* Decorative watermark */}
          <div className="absolute -right-3 -bottom-3 w-16 h-16 rounded-full bg-white/10 pointer-events-none" />
        </button>

        {/* Card 2: Live Schedule (Warm Brown/Amber gradient) */}
        <button
          onClick={onOpenLiveSchedule}
          className="relative overflow-hidden rounded-2xl p-3.5 h-24 bg-gradient-to-br from-[#8d5b4c] to-[#6d4034] text-white shadow-sm hover:shadow-md transition-all active:scale-[0.98] text-left flex flex-col justify-between group"
        >
          <div className="z-10">
            <h4 className="font-extrabold text-sm leading-tight drop-shadow-xs">
              Live<br />Schedule
            </h4>
          </div>

          <div className="z-10 flex items-center justify-between">
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-xs">
              <BookMarked className="w-4 h-4" />
            </div>
          </div>

          <div className="absolute -right-3 -bottom-3 w-16 h-16 rounded-full bg-white/10 pointer-events-none" />
        </button>

        {/* Card 3: Test Series (Blue grid style) */}
        <button
          onClick={onOpenTestSeries}
          className="relative overflow-hidden rounded-2xl p-3.5 h-24 bg-gradient-to-br from-blue-600 to-indigo-700 text-white shadow-sm hover:shadow-md transition-all active:scale-[0.98] text-left flex flex-col justify-between group"
        >
          <div className="z-10">
            <h4 className="font-extrabold text-sm leading-tight drop-shadow-xs">
              Test<br />Series
            </h4>
          </div>

          <div className="z-10 flex items-center justify-between">
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-xs">
              <FileText className="w-4 h-4" />
            </div>
          </div>

          <div className="absolute -right-3 -bottom-3 w-16 h-16 rounded-full bg-white/10 pointer-events-none" />
        </button>

        {/* Card 4: Recording Class (Emerald Green - replaces standard Recorded Courses as explicitly requested) */}
        <button
          onClick={onOpenRecordings}
          className="relative overflow-hidden rounded-2xl p-3.5 h-24 bg-gradient-to-br from-emerald-500 to-teal-700 text-white shadow-sm hover:shadow-md transition-all active:scale-[0.98] text-left flex flex-col justify-between group border-2 border-emerald-300/40"
        >
          <div className="z-10">
            <div className="inline-flex items-center gap-1 text-[9px] font-bold uppercase tracking-wider bg-white/20 px-1.5 py-0.5 rounded-full mb-0.5">
              <Sparkles className="w-2.5 h-2.5 text-amber-300" />
              <span>Full Video Access</span>
            </div>
            <h4 className="font-extrabold text-sm leading-tight drop-shadow-xs">
              Recording<br />Class
            </h4>
          </div>

          <div className="z-10 flex items-center justify-between">
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-xs animate-pulse">
              <Video className="w-4 h-4" />
            </div>
          </div>

          <div className="absolute -right-3 -bottom-3 w-16 h-16 rounded-full bg-white/10 pointer-events-none" />
        </button>
      </div>

      {/* Special Highlights Banner: Notes (PDF) Section with 4-digit code */}
      <div className="mt-3">
        <button
          onClick={onOpenNotesPdf}
          className="w-full relative overflow-hidden rounded-2xl p-3.5 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-white shadow-md hover:shadow-lg transition-all active:scale-[0.99] flex items-center justify-between group border border-amber-300/40"
        >
          <div className="flex items-center space-x-3 text-left">
            <div className="w-11 h-11 rounded-xl bg-white/20 flex items-center justify-center backdrop-blur-xs shadow-inner">
              <Lock className="w-5 h-5 text-amber-100" />
            </div>
            <div>
              <div className="inline-flex items-center gap-1 text-[10px] font-extrabold bg-slate-900/30 px-2 py-0.5 rounded-full text-amber-100">
                <span>Class 9, 10, 11, 12</span>
                <span>•</span>
                <span>৪ ডিজিটের সিকিউরিটি কোড লক</span>
              </div>
              <h4 className="font-bold text-sm text-white drop-shadow-xs mt-0.5">
                Notes (PDF) স্পেশাল মডিউল
              </h4>
              <p className="text-[11px] text-amber-100/90 line-clamp-1">
                অধ্যায়ভিত্তিক হ্যান্ডরিটেন রঙিন পিডিএফ ও গুগল ড্রাইভ লিঙ্ক
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1 font-bold text-xs bg-white text-orange-600 px-3 py-1.5 rounded-xl shadow-xs group-hover:bg-amber-50 transition-colors whitespace-nowrap">
            <span>আনলক করুন</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </div>
        </button>
      </div>
    </div>
  );
};
