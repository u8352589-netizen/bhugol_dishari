import React from 'react';
import { Menu, Bell } from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface MobileTopAppBarProps {
  onOpenDrawer: () => void;
  onOpenNotices: () => void;
  isDark?: boolean;
}

export const MobileTopAppBar: React.FC<MobileTopAppBarProps> = ({
  onOpenDrawer,
  onOpenNotices,
  isDark = false,
}) => {
  const { notices } = useApp();
  const unreadCount = notices.filter((n) => !n.read).length;

  return (
    <div
      className={`px-3.5 py-3 flex items-center justify-between shadow-sm select-none transition-colors ${
        isDark ? 'bg-slate-800 text-white border-b border-slate-700' : 'bg-sky-600 text-white'
      }`}
    >
      <div className="flex items-center space-x-3">
        <button
          id="mobile-drawer-btn"
          onClick={onOpenDrawer}
          className="p-1 rounded-md hover:bg-white/10 active:bg-white/20 transition-colors"
          aria-label="Open Navigation Drawer"
        >
          <Menu className="w-5 h-5 text-white" />
        </button>
        <div>
          <h2 className="text-sm font-bold tracking-tight text-white leading-tight">
            ভূগোল দিশারী <span className="text-sky-200 text-xs font-normal">(নারায়ণ স্যার)</span>
          </h2>
          <p className="text-[10px] text-sky-100/90 font-medium">ভূগোল মানেই নারায়ণ স্যার</p>
        </div>
      </div>

      <div className="flex items-center space-x-1">
        <button
          id="mobile-notices-btn"
          onClick={onOpenNotices}
          className="p-1.5 rounded-full hover:bg-white/10 active:bg-white/20 transition-colors relative"
          aria-label="View Notices"
        >
          <Bell className="w-5 h-5 text-white" />
          {unreadCount > 0 && (
            <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-amber-400 border-2 border-sky-600 rounded-full"></span>
          )}
        </button>
      </div>
    </div>
  );
};
