import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Play,
  Video,
  Clock,
  Eye,
  FileText,
  Search,
  CheckCircle,
  Share2,
  BookOpen,
} from 'lucide-react';
import { RecordingClass } from '../../types';

interface RecordingClassModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenNotesPdf?: () => void;
}

export const RecordingClassModal: React.FC<RecordingClassModalProps> = ({
  isOpen,
  onClose,
  onOpenNotesPdf,
}) => {
  const { recordings, isDarkMode, showToast } = useApp();
  const [selectedClassLevel, setSelectedClassLevel] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeLecture, setActiveLecture] = useState<RecordingClass>(recordings[0]);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  if (!isOpen) return null;

  const filteredLectures = recordings.filter((rec) => {
    const matchesLevel = selectedClassLevel === 'All' || rec.classLevel === selectedClassLevel;
    const matchesSearch =
      rec.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.topic.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesLevel && matchesSearch;
  });

  const handleSelectLecture = (lec: RecordingClass) => {
    setActiveLecture(lec);
    setIsPlaying(true);
    showToast('ক্লাস চালু হচ্ছে...', lec.title, 'info');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-xs">
      <div
        className={`w-full max-w-lg h-[92vh] max-h-[760px] rounded-3xl shadow-2xl flex flex-col overflow-hidden border transition-colors ${
          isDarkMode ? 'bg-slate-900 text-slate-100 border-slate-800' : 'bg-white text-slate-900 border-slate-200'
        }`}
      >
        {/* Top Header */}
        <div className="bg-emerald-600 text-white p-3.5 flex items-center justify-between shadow-md">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center backdrop-blur-xs">
              <Video className="w-4 h-4 text-white" />
            </div>
            <div>
              <h2 className="text-sm font-bold tracking-tight">Recording Class (রেকর্ডিং ক্লাস)</h2>
              <p className="text-[10px] text-emerald-100 font-medium">
                নারায়ণ স্যারের স্পেশাল ভিডিও লেকচার ও রিভিশন
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video Player Section */}
        <div className="bg-black relative aspect-video w-full flex items-center justify-center overflow-hidden group">
          {isPlaying ? (
            <div className="w-full h-full relative bg-slate-950 flex flex-col items-center justify-center p-4">
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/40 pointer-events-none" />
              {/* Simulated high-quality video canvas */}
              <img
                src={activeLecture.thumbnailUrl}
                alt={activeLecture.title}
                className="w-full h-full object-cover opacity-40 blur-xs absolute inset-0"
              />
              <div className="relative z-10 text-center p-4 max-w-md">
                <span className="inline-block px-2 py-0.5 rounded-full bg-emerald-500 text-white text-[10px] font-bold mb-2">
                  ▶ STREAMING HD (1080p)
                </span>
                <h4 className="text-sm sm:text-base font-bold text-white leading-snug drop-shadow-md">
                  {activeLecture.title}
                </h4>
                <p className="text-xs text-emerald-300 mt-1">{activeLecture.instructor}</p>

                <div className="mt-4 flex items-center justify-center space-x-3">
                  <button
                    onClick={() => setIsPlaying(false)}
                    className="px-4 py-1.5 rounded-xl bg-white text-slate-900 font-bold text-xs hover:bg-slate-200 transition-colors shadow-lg"
                  >
                    Pause Video
                  </button>
                  {activeLecture.pdfNotesUrl && (
                    <button
                      onClick={() => {
                        window.open(activeLecture.pdfNotesUrl, '_blank');
                      }}
                      className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs flex items-center gap-1 shadow-lg"
                    >
                      <FileText className="w-3.5 h-3.5" /> লেকচার PDF
                    </button>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="relative w-full h-full flex items-center justify-center cursor-pointer" onClick={() => setIsPlaying(true)}>
              <img
                src={activeLecture.thumbnailUrl}
                alt={activeLecture.title}
                className="w-full h-full object-cover opacity-80"
              />
              <div className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center">
                <div className="w-14 h-14 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-xl group-hover:scale-110 transition-transform">
                  <Play className="w-6 h-6 fill-current ml-1" />
                </div>
                <span className="text-xs font-bold text-white mt-2 drop-shadow-md">
                  ভিডিও দেখতে ক্লিক করুন
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Lecture Meta Details */}
        <div className="p-3 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700/80">
          <div className="flex items-center justify-between gap-2">
            <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
              {activeLecture.classLevel}
            </span>
            <div className="flex items-center gap-3 text-[11px] text-slate-500 dark:text-slate-400">
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3" /> {activeLecture.duration}
              </span>
              <span className="flex items-center gap-1">
                <Eye className="w-3 h-3" /> {activeLecture.viewsCount} ভিউজ
              </span>
            </div>
          </div>
          <h3 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white mt-1 leading-snug">
            {activeLecture.title}
          </h3>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
            টপিক: {activeLecture.topic} • শিক্ষক: {activeLecture.instructor}
          </p>
        </div>

        {/* Search & Class Level Filter */}
        <div className="p-3 border-b border-slate-200 dark:border-slate-800 space-y-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="লেকচার বা অধ্যায় খুঁজুন..."
              className="w-full pl-8 pr-3 py-1.5 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-1 focus:ring-emerald-500 text-slate-900 dark:text-white"
            />
          </div>

          <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 text-xs">
            {['All', 'Class 9', 'Class 10', 'Class 11', 'Class 12'].map((cls) => (
              <button
                key={cls}
                onClick={() => setSelectedClassLevel(cls)}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                  selectedClassLevel === cls
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                {cls === 'All' ? 'সকল ক্লাস' : cls}
              </button>
            ))}
          </div>
        </div>

        {/* Playlist of Lectures */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {filteredLectures.map((lec) => {
            const isSelected = activeLecture.id === lec.id;
            return (
              <div
                key={lec.id}
                onClick={() => handleSelectLecture(lec)}
                className={`p-2.5 rounded-xl border flex items-center gap-3 cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-700 dark:text-emerald-300 ring-1 ring-emerald-400/30'
                    : 'bg-white dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 hover:border-emerald-300'
                }`}
              >
                <div className="w-16 h-12 rounded-lg overflow-hidden bg-slate-200 relative shrink-0">
                  <img
                    src={lec.thumbnailUrl}
                    alt={lec.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                    <Play className="w-3.5 h-3.5 fill-white text-white" />
                  </div>
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400">
                      {lec.classLevel}
                    </span>
                    <span className="text-[10px] text-slate-400">• {lec.duration}</span>
                  </div>
                  <h5 className="font-semibold text-xs text-slate-900 dark:text-white truncate mt-0.5">
                    {lec.title}
                  </h5>
                  <p className="text-[10px] text-slate-500 truncate">{lec.topic}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Modal Footer */}
        <div className="p-3 bg-slate-100 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between">
          <button
            onClick={() => {
              onClose();
              onOpenNotesPdf?.();
            }}
            className="text-xs text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1 hover:underline"
          >
            <BookOpen className="w-3.5 h-3.5" /> Notes (PDF) দেখতে চান? ৪ ডিজিট কোড লক মডিউলে যান →
          </button>
        </div>
      </div>
    </div>
  );
};
