import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { MobileStatusBar } from './MobileStatusBar';
import { MobileTopAppBar } from './MobileTopAppBar';
import { StudentDrawer } from './StudentDrawer';
import { BannerCarousel } from './BannerCarousel';
import { ActionCardsGrid } from './ActionCardsGrid';
import { NoticeBoardSection } from './NoticeBoardSection';
import { TestimonialsSection } from './TestimonialsSection';
import { NotesPdfModal } from './NotesPdfModal';
import { RecordingClassModal } from './RecordingClassModal';
import { CourseTab } from './CourseTab';
import { FeesPaymentTab } from './FeesPaymentTab';
import { ProfileTab } from './ProfileTab';
import { StudentBottomNav, StudentNavTab } from './StudentBottomNav';
import { StudentAuthModal } from './StudentAuthModal';
import { StudentFeeReminderModal } from './StudentFeeReminderModal';
import { StudentFeeAlertBanner } from './StudentFeeAlertBanner';
import { evaluateStudentFeeStatus } from '../../utils/feeReminderUtils';
import { BellRing, Calendar } from 'lucide-react';

export const StudentAppSimulator: React.FC<{ isSplitView?: boolean }> = ({ isSplitView = false }) => {
  const { isDarkMode, showToast, currentStudent, feePayments, paymentSettings, updatePaymentSettings, studentRoster, setCurrentStudent } = useApp();
  const [activeTab, setActiveTab] = useState<StudentNavTab>('HOME');
  const [isDrawerOpen, setIsDrawerOpen] = useState<boolean>(false);
  const [isNotesPdfOpen, setIsNotesPdfOpen] = useState<boolean>(false);
  const [isRecordingsOpen, setIsRecordingsOpen] = useState<boolean>(false);
  const [isAuthOpen, setIsAuthOpen] = useState<boolean>(false);
  const [isReminderOpen, setIsReminderOpen] = useState<boolean>(false);
  const [hasDismissedReminder, setHasDismissedReminder] = useState<boolean>(false);

  // Evaluate fee status for the current active student
  const feeStatus = evaluateStudentFeeStatus(currentStudent, feePayments, paymentSettings);

  // Automatically trigger the reminder popup if reminder is active and hasn't been dismissed in this session
  useEffect(() => {
    if (feeStatus.isReminderActive && !hasDismissedReminder) {
      const timer = setTimeout(() => {
        setIsReminderOpen(true);
      }, 700);
      return () => clearTimeout(timer);
    }
  }, [currentStudent.id, feeStatus.isReminderActive, hasDismissedReminder]);

  return (
    <div className={`flex flex-col items-center justify-center p-2 sm:p-4 w-full ${isSplitView ? 'max-w-md' : 'max-w-lg'} mx-auto`}>
      {/* Device Frame */}
      <div
        className={`w-full max-w-[420px] rounded-[40px] shadow-2xl overflow-hidden border-8 border-slate-800 ring-1 ring-slate-700/60 flex flex-col h-[850px] relative transition-colors ${
          isDarkMode ? 'bg-slate-900 text-slate-100' : 'bg-white text-slate-900'
        }`}
      >
        {/* Hardware Notch / Speaker Ear-piece */}
        <div className="absolute top-2 left-1/2 -translate-x-1/2 w-28 h-4 bg-slate-800 rounded-b-xl z-40 flex items-center justify-center">
          <div className="w-10 h-1 bg-slate-600 rounded-full" />
          <div className="w-2.5 h-2.5 rounded-full bg-slate-700 ml-3" />
        </div>

        {/* Mobile Top Status Bar */}
        <MobileStatusBar isDark={isDarkMode} />

        {/* App Bar (Shown on Home and Courses) */}
        <MobileTopAppBar
          onOpenDrawer={() => setIsDrawerOpen(true)}
          onOpenNotices={() => {
            showToast('নোটিশ বোর্ড', 'সমস্ত সাম্প্রতিক বিজ্ঞপ্তি নিচে প্রদর্শিত হচ্ছে', 'info');
          }}
          isDark={isDarkMode}
        />

        {/* Dynamic Screen Body based on Tab */}
        <div className="flex-1 overflow-y-auto flex flex-col relative">
          {activeTab === 'HOME' && (
            <div className="flex-1 flex flex-col pb-4">
              {/* Automatic Fee Due Alert Banner (Active during 1st-2nd or test mode) */}
              <StudentFeeAlertBanner
                feeStatus={feeStatus}
                onOpenReminderModal={() => setIsReminderOpen(true)}
                onNavigateToFees={() => setActiveTab('FEES')}
                isDark={isDarkMode}
              />

              {/* Promotional Auto-Sliding Banner Carousel */}
              <BannerCarousel
                onSelectBanner={(courseId) => {
                  if (courseId) {
                    setActiveTab('COURSE');
                  } else {
                    setIsRecordingsOpen(true);
                  }
                }}
              />

              {/* 4 Action Cards Matching Screenshot 1 */}
              <ActionCardsGrid
                onOpenRecordings={() => setIsRecordingsOpen(true)}
                onOpenNotesPdf={() => setIsNotesPdfOpen(true)}
                onNavigateToCourses={() => setActiveTab('COURSE')}
                onOpenLiveSchedule={() => {
                  showToast(
                    'লাইভ ক্লাস সময়সূচী',
                    'সোম ও বুধ: মাধ্যমিক রাত ৮টা | মঙ্গল ও বৃহস্পতি: উচ্চমাধ্যমিক রাত ৮:৩০',
                    'info'
                  );
                }}
                onOpenTestSeries={() => {
                  showToast(
                    'মক টেস্ট সিরিজ',
                    'আগামী রবিবার সকাল ১০টায় সম্পূর্ণ সিলেবাসের ওপর ৫০ নম্বরের স্পেশাল টেস্ট।',
                    'info'
                  );
                }}
                isDark={isDarkMode}
              />

              {/* Live Real-time Notice Board from Firestore */}
              <NoticeBoardSection />

              {/* Testimonials & Connect with us */}
              <TestimonialsSection />
            </div>
          )}

          {activeTab === 'COURSE' && (
            <CourseTab
              onOpenRecordings={() => setIsRecordingsOpen(true)}
              onOpenNotesPdf={() => setIsNotesPdfOpen(true)}
            />
          )}

          {activeTab === 'FEES' && <FeesPaymentTab />}

          {activeTab === 'PROFILE' && <ProfileTab />}
        </div>

        {/* 4-Tab Bottom Navigation matching screenshot strictly */}
        <StudentBottomNav
          activeTab={activeTab}
          onChangeTab={setActiveTab}
          isDark={isDarkMode}
          hasDueFeeBadge={feeStatus.isReminderActive}
        />
      </div>

      {/* Floating Action Trigger for Demo Testing */}
      <div className="mt-3 flex flex-wrap items-center justify-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
        <button
          onClick={() => {
            setHasDismissedReminder(false);
            setIsReminderOpen(true);
          }}
          className="px-2.5 py-1 rounded-lg bg-amber-500/15 text-amber-700 dark:text-amber-300 border border-amber-500/30 font-bold hover:bg-amber-500/25 transition-colors flex items-center gap-1 shadow-2xs"
          title="ফি রিমাইন্ডার পপ-আপ টেস্ট"
        >
          <BellRing className="w-3.5 h-3.5 text-amber-500" />
          <span>🔔 অটো রিমাইন্ডার পপ-আপ</span>
        </button>

        <button
          onClick={() => {
            const isSimulated = paymentSettings.autoReminder?.simulateDuePeriodForTesting ?? true;
            updatePaymentSettings({
              autoReminder: {
                ...paymentSettings.autoReminder,
                simulateDuePeriodForTesting: !isSimulated,
              },
            });
            showToast(
              'রিমাইন্ডার টেস্ট মোড',
              !isSimulated ? '১লা-২রা তারিখের ডিউ পিরিয়ড সিমুলেশন সক্রিয়' : 'লাইভ ক্যালেন্ডার মোড সক্রিয়',
              'info'
            );
          }}
          className={`px-2.5 py-1 rounded-lg border font-semibold text-[11px] flex items-center gap-1 transition-all ${
            paymentSettings.autoReminder?.simulateDuePeriodForTesting
              ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-300 dark:border-slate-700'
          }`}
        >
          <Calendar className="w-3 h-3" />
          <span>{paymentSettings.autoReminder?.simulateDuePeriodForTesting ? '📅 ১লা-২রা তারিখ টেস্ট: অন' : '📅 ১লা-২রা তারিখ টেস্ট: অফ'}</span>
        </button>

        <button
          onClick={() => setIsNotesPdfOpen(true)}
          className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700 font-medium hover:bg-slate-200 transition-colors"
        >
          <span>🔐 Notes Lock</span>
        </button>
        <button
          onClick={() => setIsAuthOpen(true)}
          className="px-2.5 py-1 rounded-lg bg-sky-500/10 text-sky-600 dark:text-sky-400 border border-sky-500/20 font-medium hover:bg-sky-500/20 transition-colors"
        >
          <span>স্বিচ শিক্ষার্থী/অ্যাডমিন</span>
        </button>
      </div>

      {/* Modals & Dialogs */}
      <StudentFeeReminderModal
        isOpen={isReminderOpen}
        onClose={() => {
          setIsReminderOpen(false);
          setHasDismissedReminder(true);
        }}
        feeStatus={feeStatus}
        onNavigateToFeesTab={() => setActiveTab('FEES')}
      />

      <StudentDrawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        onOpenNotesPdf={() => setIsNotesPdfOpen(true)}
        onOpenRecordings={() => setIsRecordingsOpen(true)}
        onOpenProfile={() => setActiveTab('PROFILE')}
        onOpenAuth={() => setIsAuthOpen(true)}
      />

      <NotesPdfModal
        isOpen={isNotesPdfOpen}
        onClose={() => setIsNotesPdfOpen(false)}
      />

      <RecordingClassModal
        isOpen={isRecordingsOpen}
        onClose={() => setIsRecordingsOpen(false)}
        onOpenNotesPdf={() => setIsNotesPdfOpen(true)}
      />

      <StudentAuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
      />
    </div>
  );
};
