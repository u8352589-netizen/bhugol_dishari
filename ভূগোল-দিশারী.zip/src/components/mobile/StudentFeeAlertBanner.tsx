import React from 'react';
import { BellRing, ArrowRight, AlertTriangle, Calendar } from 'lucide-react';
import { StudentFeeStatus } from '../../utils/feeReminderUtils';

interface StudentFeeAlertBannerProps {
  feeStatus: StudentFeeStatus;
  onOpenReminderModal: () => void;
  onNavigateToFees: () => void;
  isDark?: boolean;
}

export const StudentFeeAlertBanner: React.FC<StudentFeeAlertBannerProps> = ({
  feeStatus,
  onOpenReminderModal,
  onNavigateToFees,
  isDark = false,
}) => {
  if (!feeStatus.isReminderActive) return null;

  const { monthInfo, amountDue } = feeStatus;

  return (
    <div className="mx-3 my-2.5 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 p-[1px] shadow-sm animate-pulse-slow">
      <div
        className={`px-3 py-2 rounded-[15px] flex items-center justify-between gap-2 transition-colors ${
          isDark ? 'bg-slate-900/95 text-white' : 'bg-amber-50 text-slate-900'
        }`}
      >
        <div className="flex items-center gap-2 min-w-0 flex-1">
          <div className="w-7 h-7 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center shrink-0 shadow-xs">
            <BellRing className="w-3.5 h-3.5 animate-bounce" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[10px] font-black uppercase text-amber-600 dark:text-amber-400 bg-amber-500/15 px-1.5 py-0.2 rounded">
                ফি রিমাইন্ডার (১লা–২রা তারিখ)
              </span>
              <span className="text-xs font-bold truncate">
                {monthInfo.previousMonthBn}-এর ফি বাকি
              </span>
            </div>
            <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
              বকেয়া: <strong className="text-rose-600 dark:text-rose-400 font-black">₹{amountDue}</strong> • নির্ধারিত সময়সীমার মধ্যে পরিশোধ করুন
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={onOpenReminderModal}
            className="px-2 py-1 rounded-lg text-[10px] font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-200/50 dark:hover:bg-slate-800 transition-colors"
          >
            বিস্তারিত
          </button>
          <button
            onClick={onNavigateToFees}
            className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-[10px] font-black flex items-center gap-1 shadow-xs transition-transform active:scale-95"
          >
            <span>পরিশোধ</span>
            <ArrowRight className="w-2.5 h-2.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
