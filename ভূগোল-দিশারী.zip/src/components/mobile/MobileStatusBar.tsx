import React from 'react';
import { Wifi, Signal, BatteryCharging } from 'lucide-react';

export const MobileStatusBar: React.FC<{ isDark?: boolean }> = ({ isDark = false }) => {
  return (
    <div
      className={`px-4 pt-1.5 pb-1 flex items-center justify-between text-xs font-semibold select-none transition-colors ${
        isDark ? 'bg-slate-900 text-slate-200' : 'bg-sky-600 text-white'
      }`}
    >
      <span className="tracking-tight text-[11px] font-bold">7:41</span>
      <div className="flex items-center space-x-2 text-[10px]">
        <span className="text-[9px] font-medium opacity-90">0.19 KB/S</span>
        <span className="text-[9px] font-bold tracking-tighter opacity-90">5G⁺</span>
        <Signal className="w-3 h-3 inline-block opacity-90" />
        <Wifi className="w-3 h-3 inline-block opacity-90" />
        <span className="text-[9px] font-bold">28%</span>
        <div className="w-4 h-2 border border-current rounded-xs p-0.5 flex items-center">
          <div className="h-full bg-current w-1/3 rounded-xs"></div>
        </div>
      </div>
    </div>
  );
};
