import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  CreditCard,
  QrCode,
  CheckCircle2,
  Clock,
  AlertCircle,
  FileCheck,
  Upload,
  Receipt,
  ArrowRight,
  ShieldCheck,
  Copy,
  ExternalLink,
  Download,
  X,
  Smartphone,
} from 'lucide-react';

export const FeesPaymentTab: React.FC = () => {
  const { currentStudent, feePayments, submitFeePayment, isDarkMode, showToast, paymentSettings } = useApp();
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [showQrModal, setShowQrModal] = useState(false);
  const [month, setMonth] = useState('September 2026');
  const [amount, setAmount] = useState('500');
  const [utrNumber, setUtrNumber] = useState('');
  const [method, setMethod] = useState<'UPI' | 'Bank Transfer'>('UPI');
  const [copied, setCopied] = useState(false);

  // Compute active QR code
  const dynamicUpiUri = `upi://pay?pa=${encodeURIComponent(paymentSettings.upiId)}&pn=${encodeURIComponent(paymentSettings.payeeName)}&cu=INR&tn=${encodeURIComponent('Bhugol Dishari Tuition Fees')}`;
  const generatedQrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=350x350&margin=10&data=${encodeURIComponent(dynamicUpiUri)}`;
  const activeQrUrl = paymentSettings.useCustomQrImage && paymentSettings.qrImageUrl.trim()
    ? paymentSettings.qrImageUrl.trim()
    : generatedQrUrl;

  // Filter for this student's records
  const myPayments = feePayments.filter(
    (p) => p.studentId === currentStudent.id || p.studentName === currentStudent.name
  );

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(paymentSettings.upiId);
    setCopied(true);
    showToast('কপি সম্পন্ন', `UPI ID: ${paymentSettings.upiId} কপি করা হয়েছে`, 'info');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSubmitPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!utrNumber || utrNumber.trim().length < 8) {
      showToast('সতর্কতা', 'সঠিক ১২ বা ১০ ডিজিটের UPI UTR রেফারেন্স নম্বর লিখুন', 'warning');
      return;
    }

    submitFeePayment({
      studentId: currentStudent.id,
      studentName: currentStudent.name,
      studentPhone: currentStudent.phone,
      studentRoll: currentStudent.rollNumber,
      classLevel: currentStudent.classLevel,
      month,
      amount: Number(amount) || 500,
      utrNumber: utrNumber.trim(),
      paymentMethod: method,
      screenshotUrl: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?auto=format&fit=crop&w=600&q=80',
    });

    setShowSubmitModal(false);
    setUtrNumber('');
    showToast('পেমেন্ট সফলভাবে জমা হয়েছে', 'অ্যাডমিন প্যানেল থেকে নারায়ণ স্যার যাচাই করবেন।', 'success');
  };

  return (
    <div className="flex-1 overflow-y-auto p-3.5 pb-8 space-y-4">
      {/* Fees Header & UPI Instructions */}
      <div className="p-4 rounded-2xl bg-gradient-to-br from-sky-600 via-blue-700 to-indigo-800 text-white shadow-md relative overflow-hidden">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-extrabold tracking-wider text-sky-200">
              Bhugol Dishari Tuition Fees
            </span>
            <h3 className="font-extrabold text-base tracking-tight mt-0.5">
              মাসিক টিউশন ফি পেমেন্ট
            </h3>
            <p className="text-xs text-sky-100/90 mt-0.5">
              শিক্ষক: {paymentSettings.payeeName} ({paymentSettings.bankName})
            </p>
          </div>
          <button
            onClick={() => setShowQrModal(true)}
            className="w-12 h-12 rounded-xl bg-white/20 hover:bg-white/30 flex items-center justify-center backdrop-blur-xs transition-transform active:scale-95 border border-white/30 group"
            title="QR স্ক্যানার দেখুন"
          >
            <QrCode className="w-7 h-7 text-white group-hover:scale-105 transition-transform" />
          </button>
        </div>

        {/* UPI ID display */}
        <div className="mt-3 p-2.5 rounded-xl bg-slate-900/50 border border-white/20 flex items-center justify-between text-xs backdrop-blur-xs">
          <div>
            <span className="text-[10px] text-sky-200 block">অফিসিয়াল UPI আইডি:</span>
            <span className="font-mono font-bold text-white text-xs select-all">
              {paymentSettings.upiId}
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={handleCopyUpi}
              className="px-2.5 py-1 rounded-lg bg-white/20 hover:bg-white/30 text-white text-[11px] font-semibold transition-colors flex items-center gap-1 active:scale-95"
            >
              <Copy className="w-3 h-3" />
              <span>{copied ? 'কপি হয়েছে' : 'Copy'}</span>
            </button>
            <button
              onClick={() => setShowQrModal(true)}
              className="px-2.5 py-1 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 text-[11px] font-bold transition-colors flex items-center gap-1 active:scale-95"
            >
              <QrCode className="w-3 h-3" />
              <span>স্ক্যানার</span>
            </button>
          </div>
        </div>

        <div className="mt-3 flex items-center justify-between pt-2 border-t border-white/20 text-xs">
          <span className="text-sky-100 text-[11px]">
            ৯ম/১০ম: ₹{paymentSettings.classFeeStructure.class9And10} • ১১শ/১২শ: ₹{paymentSettings.classFeeStructure.class11And12}
          </span>
          <button
            onClick={() => setShowSubmitModal(true)}
            className="px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-500 text-slate-950 font-bold text-xs shadow-sm transition-all flex items-center gap-1 active:scale-95"
          >
            <Receipt className="w-3.5 h-3.5" /> ফি জমা দিন (UTR)
          </button>
        </div>
      </div>

      {/* Transaction Records matching Screenshot 5 */}
      <div>
        <div className="flex items-center justify-between mb-2 px-0.5">
          <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">
            Payment History (পেমেন্ট রেকর্ড)
          </h4>
          <span className="text-[11px] text-slate-500 dark:text-slate-400">
            {myPayments.length} টি লেনদেন
          </span>
        </div>

        {myPayments.length === 0 ? (
          /* Empty State matching Screenshot 5 exactly */
          <div className="py-12 px-4 flex flex-col items-center justify-center text-center">
            <div className="w-20 h-20 rounded-full bg-sky-50 dark:bg-slate-800 flex items-center justify-center mb-3">
              <div className="w-12 h-14 border-2 border-sky-500 rounded-lg flex flex-col items-center justify-center p-1 bg-white dark:bg-slate-900 shadow-sm">
                <div className="w-8 h-1 bg-sky-500 rounded-full mb-1"></div>
                <div className="w-6 h-1 bg-slate-300 rounded-full mb-1"></div>
                <div className="text-sky-600 font-bold text-xs">$</div>
                <div className="w-8 border-t border-dashed border-slate-300 mt-1"></div>
              </div>
            </div>
            <h5 className="font-bold text-sm text-slate-800 dark:text-slate-200">
              You don't have any transactions to show
            </h5>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs">
              আপনি যখন কোনো ফি পেমেন্টের UTR জমা দেবেন, তার ভেরিফিকেশন স্ট্যাটাস এখানে দেখা যাবে।
            </p>
            <button
              onClick={() => setShowSubmitModal(true)}
              className="mt-4 px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs shadow-sm transition-colors"
            >
              এখনই ফি জমা দিন
            </button>
          </div>
        ) : (
          <div className="space-y-2.5">
            {myPayments.map((pay) => (
              <div
                key={pay.id}
                className="p-3.5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 shadow-xs hover:shadow-sm transition-all"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-slate-900 dark:text-white">
                        ₹ {pay.amount}
                      </span>
                      <span className="text-[11px] text-slate-500 font-medium">• {pay.month}</span>
                    </div>
                    <p className="text-[11px] font-mono text-slate-500 dark:text-slate-400 mt-0.5">
                      UTR: <span className="font-bold text-slate-700 dark:text-slate-200">{pay.utrNumber}</span>
                    </p>
                  </div>

                  {/* Status Badges */}
                  <div>
                    {pay.status === 'APPROVED' && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> অনুমোদিত (Paid)
                      </span>
                    )}
                    {pay.status === 'PENDING' && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30 flex items-center gap-1">
                        <Clock className="w-3 h-3" /> যাচাই অপেক্ষমাণ
                      </span>
                    )}
                    {pay.status === 'REJECTED' && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/15 text-rose-600 dark:text-rose-400 border border-rose-500/30 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> বাতিল হয়েছে
                      </span>
                    )}
                  </div>
                </div>

                <div className="mt-2.5 pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-[10px] text-slate-400">
                  <span>জমা: {pay.submittedAt}</span>
                  {pay.verifiedBy && (
                    <span className="text-emerald-600 dark:text-emerald-400 font-medium">
                      ✓ যাচাইকারী: {pay.verifiedBy}
                    </span>
                  )}
                </div>

                {pay.rejectionReason && (
                  <div className="mt-1.5 p-2 rounded-lg bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800 text-[11px] text-rose-600 dark:text-rose-400">
                    বাতিলের কারণ: {pay.rejectionReason}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Submit Fee Modal */}
      {showSubmitModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/70 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-sm w-full p-5 border border-slate-200 dark:border-slate-800 shadow-2xl">
            <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">
              ফি পেমেন্ট রসিদ জমা দিন
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Google Pay, PhonePe বা Paytm এ টাকা পাঠিয়ে ১২ ডিজিট UTR লিখুন।
            </p>

            <form onSubmit={handleSubmitPayment} className="mt-4 space-y-3">
              <div>
                <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  কোন মাসের ফি?
                </label>
                <select
                  value={month}
                  onChange={(e) => setMonth(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                >
                  <option value="September 2026">September 2026 (চলতি মাস)</option>
                  <option value="October 2026">October 2026</option>
                  <option value="November 2026">November 2026</option>
                  <option value="December 2026">December 2026</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  পেমেন্টের পরিমাণ (₹)
                </label>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
                  placeholder="500"
                  required
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  UPI UTR / রেফারেন্স নম্বর (১২ সংখ্যা)
                </label>
                <input
                  type="text"
                  value={utrNumber}
                  onChange={(e) => setUtrNumber(e.target.value)}
                  placeholder="যেমন: 626104899201"
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono"
                  required
                />
              </div>

              <div className="p-2.5 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 text-center bg-slate-50 dark:bg-slate-800/40">
                <Upload className="w-5 h-5 mx-auto text-slate-400 mb-1" />
                <span className="text-[11px] text-slate-500 font-medium block">
                  পেমেন্ট স্ক্রিনশট অ্যাটাচড (নমুনা সংযুক্ত)
                </span>
              </div>

              <div className="pt-2 flex items-center justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowSubmitModal(false)}
                  className="px-3 py-2 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold shadow-sm"
                >
                  Submit Payment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* QR Scanner Display Modal */}
      {showQrModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="w-full max-w-sm rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden p-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-xl bg-amber-500/15 text-amber-600 dark:text-amber-400 flex items-center justify-center">
                  <QrCode className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                    অফিসিয়াল UPI QR স্ক্যানার
                  </h4>
                  <p className="text-[10px] text-slate-500">স্ক্যান করে পেমেন্ট করুন</p>
                </div>
              </div>
              <button
                onClick={() => setShowQrModal(false)}
                className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* QR Code Container */}
            <div className="my-4 p-4 rounded-2xl bg-white border border-slate-200 shadow-inner flex flex-col items-center justify-center">
              <img
                src={activeQrUrl}
                alt="UPI Scanner QR Code"
                className="w-52 h-52 object-contain rounded-xl"
                onError={(e) => {
                  // Fallback to generated QR
                  (e.target as HTMLImageElement).src = generatedQrUrl;
                }}
              />
              <span className="mt-2 text-[10px] font-semibold text-slate-500 text-center">
                GPay / PhonePe / Paytm / BHIM দিয়ে স্ক্যান করুন
              </span>
            </div>

            {/* Payee Details */}
            <div className="space-y-2 text-xs">
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/60">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 text-[11px]">UPI ID:</span>
                  <button
                    onClick={handleCopyUpi}
                    className="font-mono font-bold text-sky-600 dark:text-sky-400 flex items-center gap-1 hover:underline"
                  >
                    <span>{paymentSettings.upiId}</span>
                    <Copy className="w-3 h-3" />
                  </button>
                </div>
                <div className="flex items-center justify-between mt-1 text-[11px]">
                  <span className="text-slate-500">প্রাপক:</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-200">{paymentSettings.payeeName}</span>
                </div>
                <div className="flex items-center justify-between mt-1 text-[11px]">
                  <span className="text-slate-500">ব্যাঙ্ক:</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-200">{paymentSettings.bankName}</span>
                </div>
              </div>

              {paymentSettings.instructionsBn && (
                <p className="text-[11px] text-slate-500 dark:text-slate-400 bg-amber-50 dark:bg-amber-950/30 p-2.5 rounded-xl border border-amber-500/20">
                  ⚠️ {paymentSettings.instructionsBn}
                </p>
              )}
            </div>

            {/* Action Buttons */}
            <div className="mt-4 flex items-center gap-2">
              <a
                href={dynamicUpiUri}
                className="flex-1 py-2.5 px-3 rounded-xl bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-700 hover:to-blue-700 text-white font-bold text-xs text-center flex items-center justify-center gap-1.5 shadow-sm active:scale-95"
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>UPI অ্যাপ খুলুন</span>
              </a>
              <button
                onClick={() => {
                  setShowQrModal(false);
                  setShowSubmitModal(true);
                }}
                className="flex-1 py-2.5 px-3 rounded-xl bg-amber-400 hover:bg-amber-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm active:scale-95"
              >
                <Receipt className="w-3.5 h-3.5" />
                <span>UTR জমা দিন</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
