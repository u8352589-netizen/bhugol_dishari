import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Smartphone,
  Shield,
  KeyRound,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  ArrowRight,
  UserPlus,
} from 'lucide-react';

interface StudentAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const StudentAuthModal: React.FC<StudentAuthModalProps> = ({ isOpen, onClose }) => {
  const { adminLogin, studentLoginPhone, isDarkMode, showToast, setCurrentStudent } = useApp();
  const [authRole, setAuthRole] = useState<'STUDENT' | 'ADMIN'>('STUDENT');

  // Student OTP flow
  const [phoneNumber, setPhoneNumber] = useState('9907735503');
  const [otpSent, setOtpSent] = useState(false);
  const [otpValue, setOtpValue] = useState('123456');
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [regName, setRegName] = useState('');
  const [regClass, setRegClass] = useState('Class 10');
  const [regDistrict, setRegDistrict] = useState('Bankura');

  // Admin flow
  const [adminId, setAdminId] = useState('narayan');
  const [adminPass, setAdminPass] = useState('narayan123');
  const [showForgotPass, setShowForgotPass] = useState(false);

  if (!isOpen) return null;

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (phoneNumber.trim().length < 10) {
      showToast('ভুল ফোন নম্বর', '১০ ডিজিটের বৈধ মোবাইল নম্বর লিখুন', 'warning');
      return;
    }
    setOtpSent(true);
    showToast('Firebase Auth OTP প্রেরিত', `OTP পাঠানো হয়েছে +91 ${phoneNumber} নম্বরে (ডেমো OTP: 123456)`, 'info');
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (otpValue === '123456' || otpValue.length === 6) {
      if (isRegisterMode) {
        setCurrentStudent({
          id: `stu-${Date.now()}`,
          name: regName || 'New Student',
          phone: `+91 ${phoneNumber}`,
          email: `${phoneNumber}@dishari.edu`,
          classLevel: regClass,
          rollNumber: `BD-2026-${Math.floor(1000 + Math.random() * 9000)}`,
          schoolName: `${regDistrict} উচ্চ বিদ্যালয়`,
          district: regDistrict || 'Bankura',
          joinDate: new Date().toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' }),
          dateOfJoining: new Date().toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' }),
          avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
          organizationCode: 'WZKHLU',
          about: `${regDistrict} জেলার ভূগোল শিক্ষার্থী`,
          attendancePercentage: 92,
          enrolledCourseIds: ['course-10-dhamaka'],
        });
      }
      studentLoginPhone(phoneNumber);
      onClose();
    } else {
      showToast('ভুল OTP', 'সঠিক ৬ ডিজিটের ওটিপি লিখুন (ডেমো: 123456)', 'error');
    }
  };

  const handleAdminSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const ok = adminLogin(adminId, adminPass);
    if (ok) {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/75 backdrop-blur-xs animate-in fade-in">
      <div
        className={`w-full max-w-sm rounded-3xl shadow-2xl overflow-hidden border ${
          isDarkMode ? 'bg-slate-900 text-slate-100 border-slate-800' : 'bg-white text-slate-900 border-slate-200'
        }`}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-sky-600 to-blue-700 text-white p-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center font-bold">
              ভূ
            </div>
            <div>
              <h3 className="font-bold text-sm">ভূগোল দিশারী লগইন</h3>
              <p className="text-[10px] text-sky-100">Dual Authentication Interface</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-white/20 text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Dual Role Selector Tab */}
        <div className="p-3 bg-slate-100 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700">
          <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-slate-200/80 dark:bg-slate-900 text-xs font-bold">
            <button
              onClick={() => {
                setAuthRole('STUDENT');
                setShowForgotPass(false);
              }}
              className={`py-2 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
                authRole === 'STUDENT'
                  ? 'bg-white dark:bg-slate-700 text-sky-600 dark:text-sky-300 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Student Login</span>
            </button>
            <button
              onClick={() => {
                setAuthRole('ADMIN');
                setShowForgotPass(false);
              }}
              className={`py-2 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
                authRole === 'ADMIN'
                  ? 'bg-white dark:bg-slate-700 text-sky-600 dark:text-sky-300 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Admin Login</span>
            </button>
          </div>
        </div>

        {/* Form Body */}
        <div className="p-5">
          {authRole === 'STUDENT' ? (
            /* STUDENT FLOW */
            <div>
              {!otpSent ? (
                <form onSubmit={handleSendOtp} className="space-y-3.5">
                  <div className="text-center mb-2">
                    <h4 className="font-bold text-sm text-slate-800 dark:text-slate-200">
                      {isRegisterMode ? 'নতুন ছাত্র রেজিস্ট্রেশন' : 'ছাত্র লগইন (মোবাইল OTP)'}
                    </h4>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Firebase Authentication এর মাধ্যমে সরাসরি ওটিপি আসবে
                    </p>
                  </div>

                  {isRegisterMode && (
                    <>
                      <div>
                        <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 block mb-1">
                          ছাত্র/ছাত্রীর পুরো নাম
                        </label>
                        <input
                          type="text"
                          value={regName}
                          onChange={(e) => setRegName(e.target.value)}
                          placeholder="যেমন: অনির্বাণ চক্রবর্তী"
                          className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                          required
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 block mb-1">
                            শ্রেণি
                          </label>
                          <select
                            value={regClass}
                            onChange={(e) => setRegClass(e.target.value)}
                            className="w-full px-2 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                          >
                            <option value="Class 9">Class 9</option>
                            <option value="Class 10">Class 10 (Madhyamik)</option>
                            <option value="Class 11">Class 11 (HS)</option>
                            <option value="Class 12">Class 12 (HS)</option>
                          </select>
                        </div>
                        <div>
                          <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 block mb-1">
                            জেলা
                          </label>
                          <input
                            type="text"
                            value={regDistrict}
                            onChange={(e) => setRegDistrict(e.target.value)}
                            placeholder="যেমন: বাঁকুড়া"
                            className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                          />
                        </div>
                      </div>
                    </>
                  )}

                  <div>
                    <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 block mb-1">
                      মোবাইল নম্বর (১০ সংখ্যা)
                    </label>
                    <div className="flex">
                      <span className="px-3 py-2 text-xs bg-slate-200 dark:bg-slate-700 rounded-l-xl font-bold text-slate-700 dark:text-slate-300 border border-r-0 border-slate-300 dark:border-slate-600 flex items-center">
                        +91
                      </span>
                      <input
                        type="tel"
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value)}
                        placeholder="9876543210"
                        className="flex-1 px-3 py-2 text-xs rounded-r-xl bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white font-mono"
                        required
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs shadow-md transition-colors flex items-center justify-center gap-1.5"
                  >
                    <span>Get OTP</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <div className="text-center pt-2">
                    <button
                      type="button"
                      onClick={() => setIsRegisterMode((prev) => !prev)}
                      className="text-xs text-sky-600 dark:text-sky-400 font-semibold hover:underline"
                    >
                      {isRegisterMode
                        ? 'ইতিমধ্যেই অ্যাকাউন্ট আছে? সাইন ইন করুন'
                        : 'নতুন শিক্ষার্থী? নতুন অ্যাকাউন্ট খুলুন'}
                    </button>
                  </div>
                </form>
              ) : (
                <form onSubmit={handleVerifyOtp} className="space-y-3.5">
                  <div className="text-center mb-2">
                    <span className="inline-flex p-2 rounded-full bg-emerald-500/10 text-emerald-600 mb-1">
                      <CheckCircle2 className="w-5 h-5" />
                    </span>
                    <h4 className="font-bold text-sm text-slate-800 dark:text-slate-200">
                      OTP কোড লিখুন
                    </h4>
                    <p className="text-xs text-slate-500">
                      +91 {phoneNumber} নম্বরে পাঠানো ৬ ডিজিট OTP দিন
                    </p>
                  </div>

                  <div>
                    <input
                      type="text"
                      value={otpValue}
                      onChange={(e) => setOtpValue(e.target.value)}
                      maxLength={6}
                      className="w-full tracking-widest text-center text-lg font-mono font-bold py-2 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white"
                      placeholder="123456"
                      required
                    />
                    <p className="text-[10px] text-center text-slate-400 mt-1">
                      (ডেমো টেস্টিং ওটিপি: 123456)
                    </p>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition-colors"
                  >
                    যাচাই ও প্রবেশ করুন
                  </button>

                  <button
                    type="button"
                    onClick={() => setOtpSent(false)}
                    className="w-full text-center text-xs text-slate-500 hover:underline"
                  >
                    নম্বর পরিবর্তন করুন
                  </button>
                </form>
              )}
            </div>
          ) : (
            /* ADMIN FLOW */
            <div>
              {!showForgotPass ? (
                <form onSubmit={handleAdminSubmit} className="space-y-3.5">
                  <div className="text-center mb-2">
                    <h4 className="font-bold text-sm text-slate-800 dark:text-slate-200">
                      অ্যাডমিন প্যানেল লগইন
                    </h4>
                    <p className="text-xs text-slate-500 mt-0.5">
                      নারায়ণ স্যার (Narayan Sir) বা ম্যানেজমেন্ট অ্যাকাউন্ট
                    </p>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 block mb-1">
                      Admin ID / ইউজারনেম
                    </label>
                    <input
                      type="text"
                      value={adminId}
                      onChange={(e) => setAdminId(e.target.value)}
                      placeholder="narayan"
                      className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 block mb-1">
                      পাসওয়ার্ড
                    </label>
                    <input
                      type="password"
                      value={adminPass}
                      onChange={(e) => setAdminPass(e.target.value)}
                      placeholder="••••••••"
                      className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white"
                      required
                    />
                  </div>

                  <div className="flex items-center justify-between text-xs">
                    <span className="text-[11px] text-slate-400">(ডেমো: narayan / admin)</span>
                    <button
                      type="button"
                      onClick={() => setShowForgotPass(true)}
                      className="text-sky-600 dark:text-sky-400 hover:underline text-[11px] font-semibold"
                    >
                      Forgot Password?
                    </button>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs shadow-md transition-colors flex items-center justify-center gap-1.5"
                  >
                    <KeyRound className="w-3.5 h-3.5" />
                    <span>Admin Dashboard Access</span>
                  </button>
                </form>
              ) : (
                <div className="space-y-3 text-center">
                  <HelpCircle className="w-10 h-10 text-sky-500 mx-auto" />
                  <h4 className="font-bold text-sm text-slate-800 dark:text-slate-200">
                    পাসওয়ার্ড পুনরুদ্ধার
                  </h4>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    অ্যাডমিন সিকিউরিটি রিকভারি ইমেইল <span className="font-bold text-sky-600">narayansir.bhugol@gmail.com</span> এ পাসওয়ার্ড রিসেট লিঙ্ক পাঠানো যাবে।
                  </p>
                  <button
                    onClick={() => {
                      showToast('রিকভারি লিঙ্ক প্রেরিত', 'ইমেইলে পাসওয়ার্ড রিসেট নির্দেশিকা পাঠানো হয়েছে।', 'info');
                      setShowForgotPass(false);
                    }}
                    className="w-full py-2 rounded-xl bg-sky-600 text-white font-bold text-xs"
                  >
                    রিসেট লিঙ্ক পাঠান
                  </button>
                  <button
                    onClick={() => setShowForgotPass(false)}
                    className="text-xs text-slate-400 hover:underline"
                  >
                    লগইনে ফিরে যান
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
