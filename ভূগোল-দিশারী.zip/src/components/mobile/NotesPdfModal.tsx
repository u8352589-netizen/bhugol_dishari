import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Lock,
  Unlock,
  FileText,
  ExternalLink,
  Download,
  AlertCircle,
  CheckCircle2,
  KeyRound,
  Eye,
  Layers,
  ArrowLeft,
} from 'lucide-react';
import { ClassNotesSection, ChapterNote } from '../../types';

interface NotesPdfModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NotesPdfModal: React.FC<NotesPdfModalProps> = ({ isOpen, onClose }) => {
  const { classNotes, isDarkMode, showToast } = useApp();
  const [selectedClassId, setSelectedClassId] = useState<string>(classNotes[1]?.id || 'sec-class10'); // Default to Class 10
  const [unlockedClasses, setUnlockedClasses] = useState<Record<string, boolean>>({});
  const [pinInput, setPinInput] = useState<string>('');
  const [pinError, setPinError] = useState<string | null>(null);
  const [selectedChapterPreview, setSelectedChapterPreview] = useState<ChapterNote | null>(null);

  if (!isOpen) return null;

  const currentSection = classNotes.find((sec) => sec.id === selectedClassId) || classNotes[0];
  const isClassUnlocked = !!unlockedClasses[selectedClassId];

  const handleSelectClass = (classId: string) => {
    setSelectedClassId(classId);
    setPinInput('');
    setPinError(null);
    setSelectedChapterPreview(null);
  };

  const handleKeyPress = (num: string) => {
    if (pinInput.length < 4) {
      const nextPin = pinInput + num;
      setPinInput(nextPin);
      setPinError(null);

      // Auto-validate once 4 digits entered
      if (nextPin.length === 4) {
        verifyPin(nextPin);
      }
    }
  };

  const handleBackspace = () => {
    setPinInput((prev) => prev.slice(0, -1));
    setPinError(null);
  };

  const handleClear = () => {
    setPinInput('');
    setPinError(null);
  };

  const verifyPin = (codeToTest: string) => {
    if (codeToTest === currentSection.securityCode) {
      setUnlockedClasses((prev) => ({ ...prev, [selectedClassId]: true }));
      setPinInput('');
      setPinError(null);
      showToast(
        'আনলক সম্পন্ন!',
        `${currentSection.classLevel} এর সমস্ত অধ্যায়ের হ্যান্ডরিটেন নোটস আনলক হয়েছে।`,
        'success'
      );
    } else {
      setPinError(`ভুল সিকিউরিটি কোড! নারায়ণ স্যারের দেওয়া সঠিক ৪ ডিজিটের কোড লিখুন।`);
      setPinInput('');
    }
  };

  const handleLockClass = (classId: string) => {
    setUnlockedClasses((prev) => {
      const copy = { ...prev };
      delete copy[classId];
      return copy;
    });
    setPinInput('');
    showToast('লক করা হয়েছে', `${currentSection.classLevel} আবার লক করা হলো।`, 'info');
  };

  const openDriveLink = (url: string, chapterTitle: string) => {
    showToast('গুগল ড্রাইভ লিঙ্ক খোলা হচ্ছে...', chapterTitle, 'info');
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/75 backdrop-blur-xs">
      <div
        className={`w-full max-w-md h-[92vh] max-h-[720px] rounded-3xl shadow-2xl flex flex-col overflow-hidden border transition-colors ${
          isDarkMode ? 'bg-slate-900 text-slate-100 border-slate-800' : 'bg-slate-50 text-slate-900 border-slate-200'
        }`}
      >
        {/* Modal Top Header */}
        <div className="bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 text-white p-4 flex items-center justify-between shadow-md">
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center backdrop-blur-xs shadow-inner">
              <Lock className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-sm font-bold tracking-tight">Notes (PDF) মাস্টার মডিউল</h2>
              <p className="text-[11px] text-amber-100/90 font-medium">
                ৪ ডিজিট সিকিউরিটি লক ও গুগল ড্রাইভ
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 text-white transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sequential Class Hierarchy Bar (Class 9, Class 10, Class 11, Class 12) */}
        <div className="p-2.5 bg-slate-100 dark:bg-slate-800/90 border-b border-slate-200 dark:border-slate-700/80">
          <div className="flex items-center justify-between text-[11px] font-bold text-slate-500 dark:text-slate-400 mb-1.5 px-1">
            <span className="flex items-center gap-1">
              <Layers className="w-3.5 h-3.5" /> ক্লাস সিলেক্ট করুন (Hierarchy)
            </span>
            <span>{classNotes.length} টি শ্রেণি</span>
          </div>

          <div className="grid grid-cols-4 gap-1.5">
            {classNotes.map((sec) => {
              const isSelected = sec.id === selectedClassId;
              const isUnlocked = !!unlockedClasses[sec.id];

              return (
                <button
                  key={sec.id}
                  onClick={() => handleSelectClass(sec.id)}
                  className={`py-2 px-1 rounded-xl text-xs font-bold transition-all flex flex-col items-center justify-center relative ${
                    isSelected
                      ? 'bg-amber-500 text-white shadow-sm ring-2 ring-amber-400/50'
                      : isDarkMode
                      ? 'bg-slate-800 text-slate-300 hover:bg-slate-700/80'
                      : 'bg-white text-slate-700 hover:bg-amber-50 border border-slate-200/80'
                  }`}
                >
                  <span className="text-[11px]">{sec.classLevel}</span>
                  <div className="flex items-center gap-0.5 text-[9px] mt-0.5 opacity-90">
                    {isUnlocked ? (
                      <span className="text-emerald-300 font-bold flex items-center">
                        <Unlock className="w-2.5 h-2.5 inline" /> Open
                      </span>
                    ) : (
                      <span className="opacity-75 flex items-center">
                        <Lock className="w-2.5 h-2.5 inline" /> Lock
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Content Area: Either Locked PIN Keypad OR Unlocked Chapter Boxes */}
        <div className="flex-1 overflow-y-auto p-4">
          {!isClassUnlocked ? (
            /* 4-DIGIT SECURITY CODE LOCK PROMPT */
            <div className="flex flex-col items-center justify-center min-h-full py-4 text-center animate-in fade-in zoom-in-95 duration-200">
              <div className="w-16 h-16 rounded-2xl bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 flex items-center justify-center mb-3 shadow-inner">
                <KeyRound className="w-8 h-8 animate-bounce" style={{ animationDuration: '2s' }} />
              </div>

              <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                {currentSection.classLevel} সিকিউরিটি কোড লক
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs">
                এই শ্রেণির হ্যান্ডরিটেন নোটস দেখতে নারায়ণ স্যারের দেওয়া নির্দিষ্ট ৪ ডিজিট কোডটি দিন।
              </p>

              {/* PIN Display Boxes */}
              <div className="flex items-center justify-center gap-3 my-4">
                {[0, 1, 2, 3].map((index) => {
                  const digit = pinInput[index];
                  return (
                    <div
                      key={index}
                      className={`w-12 h-14 rounded-2xl flex items-center justify-center text-xl font-black border-2 transition-all shadow-sm ${
                        digit
                          ? 'border-amber-500 bg-amber-500/10 text-amber-600 dark:text-amber-400 scale-105'
                          : 'border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-400'
                      }`}
                    >
                      {digit ? '•' : ''}
                    </div>
                  );
                })}
              </div>

              {pinError && (
                <div className="mb-3 px-3 py-1.5 rounded-lg bg-rose-500/15 text-rose-600 dark:text-rose-400 text-xs font-semibold flex items-center gap-1.5 animate-shake">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{pinError}</span>
                </div>
              )}

              {/* Developer / Demo Hint */}
              <div className="mb-3 px-3 py-1.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-[11px] text-amber-800 dark:text-amber-300">
                <span>বর্তমান সেট করা পিন কোড: </span>
                <span className="font-mono font-bold text-xs bg-amber-200 dark:bg-amber-900 px-1.5 py-0.5 rounded text-amber-950 dark:text-amber-100">
                  {currentSection.securityCode}
                </span>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  (অ্যাডমিন প্যানেল থেকে যেকোনো সময় কোড পরিবর্তন করা যায়)
                </p>
              </div>

              {/* 3x4 Numeric Keypad */}
              <div className="grid grid-cols-3 gap-2.5 w-full max-w-[260px]">
                {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
                  <button
                    key={num}
                    onClick={() => handleKeyPress(num)}
                    className="h-12 rounded-xl bg-white dark:bg-slate-800 hover:bg-amber-50 dark:hover:bg-slate-700 text-slate-800 dark:text-white font-bold text-lg shadow-xs active:scale-95 transition-all border border-slate-200/80 dark:border-slate-700"
                  >
                    {num}
                  </button>
                ))}
                <button
                  onClick={handleClear}
                  className="h-12 rounded-xl bg-slate-200/80 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-bold active:scale-95 transition-all"
                >
                  Clear
                </button>
                <button
                  onClick={() => handleKeyPress('0')}
                  className="h-12 rounded-xl bg-white dark:bg-slate-800 hover:bg-amber-50 dark:hover:bg-slate-700 text-slate-800 dark:text-white font-bold text-lg shadow-xs active:scale-95 transition-all border border-slate-200/80 dark:border-slate-700"
                >
                  0
                </button>
                <button
                  onClick={handleBackspace}
                  className="h-12 rounded-xl bg-slate-200/80 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-bold active:scale-95 transition-all flex items-center justify-center"
                >
                  ⌫
                </button>
              </div>
            </div>
          ) : (
            /* UNLOCKED CHAPTER BOXES */
            <div className="space-y-3">
              {/* Unlocked banner */}
              <div className="flex items-center justify-between p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-700 dark:text-emerald-300">
                <div className="flex items-center space-x-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                  <div>
                    <h4 className="font-bold text-xs">
                      {currentSection.classLevel} - আনলক সফল!
                    </h4>
                    <p className="text-[10px] opacity-90">{currentSection.banglaTitle}</p>
                  </div>
                </div>
                <button
                  onClick={() => handleLockClass(selectedClassId)}
                  className="text-xs px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-medium hover:bg-emerald-700 flex items-center gap-1"
                >
                  <Lock className="w-3 h-3" /> পুনরায় লক করুন
                </button>
              </div>

              {/* Individual Chapter Boxes */}
              <div className="space-y-2.5">
                {currentSection.chapters.map((chapter) => (
                  <div
                    key={chapter.id}
                    className="p-3.5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 shadow-xs hover:shadow-md transition-all group"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-start space-x-2.5">
                        <div className="w-8 h-8 rounded-xl bg-amber-500/15 text-amber-600 dark:text-amber-400 font-extrabold text-xs flex items-center justify-center shrink-0 border border-amber-500/20">
                          {chapter.chapterNumber}
                        </div>
                        <div>
                          <h5 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white leading-tight group-hover:text-amber-600 dark:group-hover:text-amber-400 transition-colors">
                            {chapter.chapterName}
                          </h5>
                          {chapter.description && (
                            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                              {chapter.description}
                            </p>
                          )}
                          <div className="flex items-center gap-3 text-[10px] text-slate-400 dark:text-slate-500 mt-2">
                            <span>📄 {chapter.totalPages} পৃষ্ঠা</span>
                            <span>💾 {chapter.fileSize}</span>
                            <span>📅 {chapter.dateUploaded}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Action buttons: Google Drive PDF Link & Offline Download */}
                    <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between gap-2">
                      <button
                        onClick={() => openDriveLink(chapter.drivePdfUrl, chapter.chapterName)}
                        className="flex-1 py-1.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs transition-colors"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>গুগল ড্রাইভ PDF খুলুন</span>
                      </button>

                      <button
                        onClick={() => {
                          showToast(
                            'ডাউনলোড শুরু হয়েছে',
                            `"${chapter.chapterName}" অফলাইন রিডিংয়ের জন্য ডাউনলোড হচ্ছে...`,
                            'info'
                          );
                        }}
                        className="py-1.5 px-3 rounded-xl bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 text-xs font-medium flex items-center gap-1 transition-colors"
                        title="Download for offline study"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">অফলাইন</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-3 bg-slate-100 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-700/80 flex items-center justify-between text-[11px] text-slate-500">
          <span>প্রশিক্ষক: নারায়ণ স্যার (ভূগোল দিশারী)</span>
          <span className="font-semibold text-amber-600 dark:text-amber-400">
            {isClassUnlocked ? '🔓 আনলকড স্ট্যাটাস' : '🔒 লকড স্ট্যাটাস'}
          </span>
        </div>
      </div>
    </div>
  );
};
