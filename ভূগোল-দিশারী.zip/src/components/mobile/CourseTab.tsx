import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Search, ChevronRight, Play, CheckCircle, Sparkles } from 'lucide-react';
import { CourseItem } from '../../types';

interface CourseTabProps {
  onOpenRecordings: () => void;
  onOpenNotesPdf: () => void;
}

export const CourseTab: React.FC<CourseTabProps> = ({ onOpenRecordings, onOpenNotesPdf }) => {
  const { courses, enrollInCourse, isDarkMode, showToast } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSubcat, setSelectedSubcat] = useState('ALL');

  const subcategories = [
    { id: 'ALL', label: 'ALL COURSES' },
    { id: 'Class 10', label: 'MADHYAMIK (CLASS 10)' },
    { id: 'Class 12', label: 'WBCHSE (CLASS 12)' },
    { id: 'Class 11', label: 'WBCHSE (CLASS 11)' },
    { id: 'Class 9', label: 'FOUNDATION (CLASS 9)' },
  ];

  const purchasedCourses = courses.filter((c) => c.isEnrolled);

  const filteredCourses = courses.filter((c) => {
    const matchesCat = selectedSubcat === 'ALL' || c.classLevel === selectedSubcat;
    const matchesSearch =
      c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.subtitle.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="flex-1 overflow-y-auto pb-6">
      {/* Search Header matching Screenshot 2 */}
      <div className="p-3.5 pb-2 sticky top-0 z-10 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xs border-b border-slate-100 dark:border-slate-800">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search for courses..."
            className="w-full pl-10 pr-4 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-sky-500"
          />
        </div>
      </div>

      {/* Purchased Courses Card matching Screenshot 2 */}
      {purchasedCourses.length > 0 && (
        <div className="px-3.5 py-2.5">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-xs font-bold text-slate-900 dark:text-white">
              Purchased Courses
            </h3>
            <button
              onClick={onOpenRecordings}
              className="text-xs font-semibold text-sky-600 dark:text-sky-400 flex items-center gap-0.5 hover:underline"
            >
              View All <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="p-3 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-800 to-sky-950 text-white shadow-md border border-slate-700/60 flex items-center gap-3">
            <div className="w-20 h-16 rounded-xl overflow-hidden bg-slate-800 shrink-0 border border-slate-700">
              <img
                src={purchasedCourses[0].thumbnailUrl}
                alt={purchasedCourses[0].title}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="font-bold text-xs text-white leading-tight truncate">
                {purchasedCourses[0].title}
              </h4>
              <p className="text-[10px] text-amber-300 mt-0.5 truncate">
                ভৌতবিজ্ঞান ও ভূগোল নিশ্চিত ১০০/১০০
              </p>
              <div className="mt-2 flex items-center gap-2">
                <button
                  onClick={onOpenRecordings}
                  className="px-3 py-1 rounded-lg bg-sky-500 hover:bg-sky-600 text-white text-[11px] font-bold shadow-xs transition-colors"
                >
                  Start Learning
                </button>
                <button
                  onClick={onOpenNotesPdf}
                  className="px-2 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-sky-200 text-[11px] font-medium transition-colors"
                >
                  Notes (PDF) 🔐
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Subcategories Pills matching Screenshot 2 */}
      <div className="px-3.5 py-2">
        <h4 className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
          Subcategories
        </h4>
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          {subcategories.map((sub) => (
            <button
              key={sub.id}
              onClick={() => setSelectedSubcat(sub.id)}
              className={`px-3 py-1.5 rounded-full text-[11px] font-bold whitespace-nowrap transition-all border ${
                selectedSubcat === sub.id
                  ? 'bg-sky-600 text-white border-sky-600 shadow-xs'
                  : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-slate-300'
              }`}
            >
              {sub.label}
            </button>
          ))}
        </div>
      </div>

      {/* Courses List matching Screenshot 2 */}
      <div className="px-3.5 py-2 space-y-3">
        <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">
          Courses ({filteredCourses.length})
        </h4>

        {filteredCourses.map((course) => (
          <div
            key={course.id}
            className="p-3 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200/80 dark:border-slate-700/80 shadow-xs hover:shadow-md transition-all flex flex-col sm:flex-row gap-3"
          >
            <div className="w-full sm:w-28 h-28 rounded-xl overflow-hidden bg-amber-500/20 shrink-0 relative border border-slate-200/60 dark:border-slate-700">
              <img
                src={course.thumbnailUrl}
                alt={course.title}
                className="w-full h-full object-cover"
              />
              <span className="absolute bottom-1 right-1 px-1.5 py-0.5 rounded bg-black/60 text-white text-[9px] font-bold backdrop-blur-xs">
                {course.classLevel}
              </span>
            </div>

            <div className="flex-1 flex flex-col justify-between">
              <div>
                {/* Badges matching Screenshot 2: LIVE CLASS | FREE CONTENT | TESTS */}
                <div className="flex items-center gap-1.5 flex-wrap">
                  {course.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-1.5 py-0.5 text-[9px] font-bold uppercase rounded bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                <h5 className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white mt-1.5 leading-snug">
                  {course.title}
                </h5>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-1">
                  {course.subtitle}
                </p>
              </div>

              {/* Price & Action */}
              <div className="mt-2.5 pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between">
                <div className="flex items-baseline space-x-2">
                  <span className="text-sm font-black text-slate-900 dark:text-white">
                    ₹ {course.price}
                  </span>
                  <span className="text-xs text-slate-400 line-through">
                    ₹ {course.originalPrice}
                  </span>
                  <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400">
                    {course.discountPercentage}% OFF
                  </span>
                </div>

                {course.isEnrolled ? (
                  <button
                    onClick={onOpenRecordings}
                    className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs flex items-center gap-1"
                  >
                    <CheckCircle className="w-3.5 h-3.5" /> Enrolled
                  </button>
                ) : (
                  <button
                    onClick={() => enrollInCourse(course.id)}
                    className="px-3 py-1 rounded-lg bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold shadow-xs transition-colors"
                  >
                    Enroll Now
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
