import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  User,
  Phone,
  Mail,
  Calendar,
  Award,
  Hash,
  BookOpen,
  TrendingUp,
  CreditCard,
  Edit3,
  Check,
  Building2,
} from 'lucide-react';

export const ProfileTab: React.FC = () => {
  const { currentStudent, setCurrentStudent, courses, feePayments, isDarkMode, showToast } = useApp();
  const [activeSubtab, setActiveSubtab] = useState<'INFO' | 'COURSES' | 'PERFORMANCE' | 'PAYMENTS'>('INFO');
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(currentStudent.name);
  const [editEmail, setEditEmail] = useState(currentStudent.email);
  const [editAbout, setEditAbout] = useState(currentStudent.about || '');

  const myCourses = courses.filter((c) => currentStudent.enrolledCourseIds.includes(c.id));
  const myPayments = feePayments.filter(
    (p) => p.studentId === currentStudent.id || p.studentName === currentStudent.name
  );

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentStudent((prev) => ({
      ...prev,
      name: editName.trim() || prev.name,
      email: editEmail.trim() || prev.email,
      about: (editAbout || '').trim() || prev.about,
    }));
    setIsEditing(false);
    showToast('প্রোফাইল আপডেট হয়েছে', 'আপনার তথ্য সফলভাবে সংরক্ষিত হয়েছে।', 'success');
  };

  return (
    <div className="flex-1 overflow-y-auto pb-8">
      {/* Profile Header matching Screenshot 4 */}
      <div className="p-5 text-center bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
        <div className="relative inline-block">
          <div className="w-20 h-20 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center overflow-hidden border-2 border-sky-500 shadow-md mx-auto">
            {currentStudent.avatarUrl ? (
              <img
                src={currentStudent.avatarUrl}
                alt={currentStudent.name}
                className="w-full h-full object-cover"
              />
            ) : (
              <User className="w-10 h-10 text-slate-400" />
            )}
          </div>
          <button
            onClick={() => setIsEditing(true)}
            className="absolute bottom-0 right-0 w-6 h-6 rounded-full bg-sky-600 text-white flex items-center justify-center shadow-md hover:bg-sky-700 transition-colors"
            title="Edit Profile"
          >
            <Edit3 className="w-3 h-3" />
          </button>
        </div>

        <h3 className="font-extrabold text-base text-slate-900 dark:text-white mt-2">
          {currentStudent.name}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          {currentStudent.classLevel} • রোল নম্বর: <span className="font-mono font-bold text-sky-600 dark:text-sky-400">{currentStudent.rollNumber}</span>
        </p>

        {/* 4 Tabs matching Screenshot 4: INFO, COURSES, PERFORMANCE, PAYMENTS */}
        <div className="grid grid-cols-4 gap-1 mt-4 p-1 rounded-xl bg-slate-200/80 dark:bg-slate-800 text-xs font-bold">
          {(['INFO', 'COURSES', 'PERFORMANCE', 'PAYMENTS'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveSubtab(tab)}
              className={`py-1.5 rounded-lg transition-all ${
                activeSubtab === tab
                  ? 'bg-white dark:bg-slate-700 text-sky-600 dark:text-sky-300 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Subtab 1: INFO matching Screenshot 4 */}
      {activeSubtab === 'INFO' && (
        <div className="p-4 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Basic Information
            </h4>
            <button
              onClick={() => setIsEditing(true)}
              className="text-xs font-semibold text-sky-600 dark:text-sky-400 hover:underline"
            >
              Edit Details
            </button>
          </div>

          <div className="rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 shadow-xs divide-y divide-slate-100 dark:divide-slate-700/60 text-xs">
            <div className="p-3 flex items-center justify-between">
              <span className="text-slate-500 dark:text-slate-400 flex items-center gap-2">
                <User className="w-4 h-4 text-sky-500" /> Full Name
              </span>
              <span className="font-semibold text-slate-800 dark:text-slate-200">
                {currentStudent.name}
              </span>
            </div>

            <div className="p-3 flex items-center justify-between">
              <span className="text-slate-500 dark:text-slate-400 flex items-center gap-2">
                <Phone className="w-4 h-4 text-emerald-500" /> Mobile Number
              </span>
              <span className="font-mono font-semibold text-slate-800 dark:text-slate-200">
                {currentStudent.phone}
              </span>
            </div>

            <div className="p-3 flex items-center justify-between">
              <span className="text-slate-500 dark:text-slate-400 flex items-center gap-2">
                <Mail className="w-4 h-4 text-rose-500" /> Email
              </span>
              <span className="font-semibold text-slate-800 dark:text-slate-200 truncate max-w-[180px]">
                {currentStudent.email}
              </span>
            </div>

            <div className="p-3 flex items-center justify-between">
              <span className="text-slate-500 dark:text-slate-400 flex items-center gap-2">
                <Building2 className="w-4 h-4 text-amber-500" /> Organization Code
              </span>
              <span className="font-mono font-bold text-sky-600 dark:text-sky-400">
                {currentStudent.organizationCode}
              </span>
            </div>

            <div className="p-3 flex items-center justify-between">
              <span className="text-slate-500 dark:text-slate-400 flex items-center gap-2">
                <Hash className="w-4 h-4 text-indigo-500" /> Roll Number
              </span>
              <span className="font-mono font-bold text-slate-800 dark:text-slate-200">
                {currentStudent.rollNumber}
              </span>
            </div>

            <div className="p-3 flex items-center justify-between">
              <span className="text-slate-500 dark:text-slate-400 flex items-center gap-2">
                <Calendar className="w-4 h-4 text-purple-500" /> Date of Joining
              </span>
              <span className="font-semibold text-slate-800 dark:text-slate-200">
                {currentStudent.dateOfJoining}
              </span>
            </div>

            <div className="p-3">
              <span className="text-slate-500 dark:text-slate-400 block mb-1">About Student</span>
              <p className="font-medium text-slate-700 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-900/50 p-2.5 rounded-xl">
                {currentStudent.about}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Subtab 2: COURSES */}
      {activeSubtab === 'COURSES' && (
        <div className="p-4 space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
            Enrolled Batches ({myCourses.length})
          </h4>
          {myCourses.map((c) => (
            <div
              key={c.id}
              className="p-3 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center gap-3 shadow-xs"
            >
              <div className="w-12 h-12 rounded-xl bg-slate-100 dark:bg-slate-700 overflow-hidden shrink-0">
                <img src={c.thumbnailUrl} alt={c.title} className="w-full h-full object-cover" />
              </div>
              <div className="flex-1 min-w-0">
                <h5 className="font-bold text-xs text-slate-900 dark:text-white truncate">
                  {c.title}
                </h5>
                <span className="text-[10px] text-emerald-600 font-bold">✓ Active Subscription</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Subtab 3: PERFORMANCE */}
      {activeSubtab === 'PERFORMANCE' && (
        <div className="p-4 space-y-3">
          <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-700 text-white shadow-sm">
            <span className="text-[10px] uppercase font-bold text-emerald-200">Academic Scorecard</span>
            <div className="mt-1 flex items-baseline justify-between">
              <div>
                <h5 className="text-2xl font-black">94.5%</h5>
                <p className="text-xs text-emerald-100">উপস্থিতির গড় (Attendance)</p>
              </div>
              <Award className="w-8 h-8 text-emerald-200" />
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-2 text-xs">
            <h5 className="font-bold text-slate-800 dark:text-slate-200">সাম্প্রতিক টেস্ট ফলাফল</h5>
            <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-700">
              <span>ভূমিরূপ গঠনকারী প্রক্রিয়া (বহির্জাত)</span>
              <span className="font-bold text-emerald-600">৪৯/৫০ (A+)</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-700">
              <span>ভারতের ভূপ্রকৃতি ও জলবায়ু</span>
              <span className="font-bold text-emerald-600">৪৭/৫০ (A+)</span>
            </div>
            <div className="flex justify-between py-1">
              <span>পশ্চিমবঙ্গের ভূগোল ও মানচিত্র</span>
              <span className="font-bold text-emerald-600">৫০/৫০ (100%)</span>
            </div>
          </div>
        </div>
      )}

      {/* Subtab 4: PAYMENTS */}
      {activeSubtab === 'PAYMENTS' && (
        <div className="p-4 space-y-2">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
            Payment History ({myPayments.length})
          </h4>
          {myPayments.map((p) => (
            <div
              key={p.id}
              className="p-3 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs"
            >
              <div>
                <span className="font-bold text-slate-900 dark:text-white">₹ {p.amount}</span>
                <span className="text-slate-500 text-[11px] block">{p.month}</span>
              </div>
              <span
                className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                  p.status === 'APPROVED'
                    ? 'bg-emerald-500/15 text-emerald-600'
                    : p.status === 'PENDING'
                    ? 'bg-amber-500/15 text-amber-600'
                    : 'bg-rose-500/15 text-rose-600'
                }`}
              >
                {p.status}
              </span>
            </div>
          ))}
        </div>
      )}

      {/* Edit Profile Modal */}
      {isEditing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-sm w-full p-5 border border-slate-200 dark:border-slate-800 shadow-2xl">
            <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">
              প্রোফাইল তথ্য পরিবর্তন
            </h3>

            <form onSubmit={handleSaveProfile} className="mt-4 space-y-3">
              <div>
                <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  পুরো নাম (Full Name)
                </label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  required
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  ইমেইল (Email)
                </label>
                <input
                  type="email"
                  value={editEmail}
                  onChange={(e) => setEditEmail(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  required
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  নিজের সম্পর্কে (About)
                </label>
                <textarea
                  value={editAbout}
                  onChange={(e) => setEditAbout(e.target.value)}
                  rows={3}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white resize-none"
                />
              </div>

              <div className="pt-2 flex items-center justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-3 py-2 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-100 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold shadow-sm"
                >
                  Save Profile
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
