import React from 'react';
import { useApp } from '../../context/AppContext';
import { Smartphone, LayoutDashboard, Columns, Code2, Moon, Sun, RefreshCw, Sparkles } from 'lucide-react';

export const Header: React.FC = () => {
  const { activeViewMode, setActiveViewMode, isDarkMode, setIsDarkMode, lastSyncTimestamp } = useApp();

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-50 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand & Identity */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-600 via-blue-500 to-amber-400 p-0.5 shadow-lg flex items-center justify-center">
            <div className="w-full h-full bg-slate-900 rounded-[10px] flex items-center justify-center">
              <span className="text-sky-400 font-bold text-lg">ভূ</span>
            </div>
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="font-bold text-base sm:text-lg tracking-tight text-white flex items-center gap-1.5">
                ভূগোল দিশারী <span className="text-sky-400 text-xs sm:text-sm font-medium">(Bhugol Dishari)</span>
              </h1>
              <span className="hidden md:inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-sky-500/20 text-sky-300 border border-sky-500/30">
                Flutter + Firebase
              </span>
            </div>
            <p className="text-xs text-amber-300/90 font-medium">
              ভূগোল মানেই নারায়ণ স্যার • <span className="text-slate-400">Narayan Sir</span>
            </p>
          </div>
        </div>

        {/* View Mode Switcher */}
        <div className="flex items-center space-x-1 sm:space-x-2 bg-slate-800/80 p-1 rounded-xl border border-slate-700/60 text-xs font-medium">
          <button
            id="view-mode-split-btn"
            onClick={() => setActiveViewMode('split')}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg transition-all ${
              activeViewMode === 'split'
                ? 'bg-sky-600 text-white shadow-sm font-semibold'
                : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
            }`}
            title="Side-by-side Real-time Sync View"
          >
            <Columns className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Split Live Sync</span>
          </button>

          <button
            id="view-mode-student-btn"
            onClick={() => setActiveViewMode('student')}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg transition-all ${
              activeViewMode === 'student'
                ? 'bg-sky-600 text-white shadow-sm font-semibold'
                : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
            }`}
            title="Android Student App View"
          >
            <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
            <span>Student App</span>
          </button>

          <button
            id="view-mode-admin-btn"
            onClick={() => setActiveViewMode('admin')}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg transition-all ${
              activeViewMode === 'admin'
                ? 'bg-sky-600 text-white shadow-sm font-semibold'
                : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
            }`}
            title="Web Admin Management Panel"
          >
            <LayoutDashboard className="w-3.5 h-3.5 text-amber-400" />
            <span>Admin Panel</span>
          </button>

          <button
            id="view-mode-code-btn"
            onClick={() => setActiveViewMode('code')}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg transition-all ${
              activeViewMode === 'code'
                ? 'bg-sky-600 text-white shadow-sm font-semibold'
                : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
            }`}
            title="Flutter & Firebase Production Code Hub"
          >
            <Code2 className="w-3.5 h-3.5 text-indigo-400" />
            <span className="hidden sm:inline">Flutter Code</span>
          </button>
        </div>

        {/* Right Controls: Sync Pulse & Dark Mode */}
        <div className="flex items-center space-x-2.5">
          <div
            className="hidden lg:flex items-center space-x-1.5 px-2.5 py-1 rounded-full bg-slate-800/90 border border-slate-700/70 text-[11px]"
            title={`Last synchronized at: ${new Date(lastSyncTimestamp).toLocaleTimeString()}`}
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="text-slate-300">Firestore Live</span>
            <RefreshCw className="w-3 h-3 text-slate-400 ml-1 animate-spin" style={{ animationDuration: '6s' }} />
          </div>

          <button
            id="theme-toggle-btn"
            onClick={() => setIsDarkMode((prev) => !prev)}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors border border-slate-700/60"
            title={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            aria-label="Toggle theme"
          >
            {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-sky-300" />}
          </button>
        </div>
      </div>
    </header>
  );
};
