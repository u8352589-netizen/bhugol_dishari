export interface BannerItem {
  id: string;
  title: string;
  subtitle?: string;
  imageUrl: string;
  targetCourseId?: string;
  actionUrl?: string;
  discountBadge?: string;
  active: boolean;
  order: number;
}

export interface RecordingClass {
  id: string;
  title: string;
  topic: string;
  duration: string;
  classLevel: string; // "Class 9", "Class 10", "Class 11", "Class 12"
  videoUrl: string; // YouTube, Cloudflare, or Drive video
  thumbnailUrl: string;
  instructor: string;
  dateAdded: string;
  viewsCount: number;
  pdfNotesUrl?: string;
}

export interface ChapterNote {
  id: string;
  chapterNumber: number;
  chapterName: string;
  totalPages: number;
  fileSize: string;
  drivePdfUrl: string;
  dateUploaded: string;
  description?: string;
}

export interface ClassNotesSection {
  id: string;
  classLevel: string; // "Class 9", "Class 10", "Class 11", "Class 12"
  title: string;
  banglaTitle: string;
  securityCode: string; // 4-digit code e.g. "1009", "2010", "3011", "4012"
  instructor: string;
  chapters: ChapterNote[];
  totalNotes: number;
  academicYear: string;
}

export interface NoticeItem {
  id: string;
  title: string;
  message: string;
  date: string;
  priority: 'URGENT' | 'GENERAL' | 'EXAM' | 'HOLIDAY';
  author: string;
  targetBatch?: string;
  link?: string;
  read?: boolean;
}

export interface CourseItem {
  id: string;
  title: string;
  subtitle: string;
  classLevel: string;
  price: number;
  originalPrice: number;
  discountPercentage: number;
  thumbnailUrl: string;
  tags: string[];
  features: string[];
  totalLiveClasses: number;
  totalTests: number;
  isEnrolled?: boolean;
}

export interface FeePaymentRecord {
  id: string;
  studentId: string;
  studentName: string;
  studentPhone: string;
  studentRoll: string;
  classLevel: string;
  month: string;
  amount: number;
  utrNumber: string;
  paymentMethod: 'UPI' | 'Bank Transfer' | 'Cash';
  screenshotUrl?: string;
  submittedAt: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  rejectionReason?: string;
  verifiedBy?: string;
  verifiedAt?: string;
}

export interface StudentAttendance {
  id: string;
  studentId: string;
  studentName: string;
  studentRoll: string;
  classLevel: string;
  date: string;
  status: 'PRESENT' | 'ABSENT' | 'LATE';
  remarks?: string;
}

export interface StudentUser {
  id: string;
  name: string;
  phone: string;
  email: string;
  rollNumber: string;
  classLevel: string; // e.g. "Class 9", "Class 10", "Class 11", "Class 12"
  schoolName: string;
  district: string;
  joinDate: string;
  dateOfJoining?: string;
  admissionDate?: string;
  fatherName?: string;
  paidMonths?: string[]; // e.g. ['January 2026', 'February 2026', ...]
  status?: 'ACTIVE' | 'ARCHIVED';
  avatarUrl: string;
  organizationCode: string;
  attendancePercentage: number;
  enrolledCourseIds: string[];
  about?: string;
  notes?: string;
}

export interface AdminUser {
  adminId: string;
  name: string;
  email: string;
  role: 'SUPER_ADMIN' | 'CO-INSTRUCTOR';
  token: string;
}

export interface AutoReminderSettings {
  enabled: boolean;
  dueStartDay: number; // default 1
  dueEndDay: number; // default 2
  gracePeriodEndDay: number; // default 7
  autoShowPopupOnLogin: boolean;
  simulateDuePeriodForTesting: boolean;
  customMessageTemplateBn?: string;
  customMessageTemplateEn?: string;
}

export interface PaymentSettings {
  upiId: string;
  payeeName: string;
  bankName: string;
  qrImageUrl: string;
  useCustomQrImage: boolean;
  instructionsBn: string;
  classFeeStructure: {
    class9And10: number;
    class11And12: number;
  };
  autoReminder: AutoReminderSettings;
  updatedAt: string;
  updatedBy: string;
}
