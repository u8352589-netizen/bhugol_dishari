import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/common/Header';
import { Toaster } from './components/common/Toaster';
import { StudentAppSimulator } from './components/mobile/StudentAppSimulator';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { CodeExportHub } from './components/codehub/CodeExportHub';
import { Smartphone, LayoutDashboard, Sparkles, RefreshCw } from 'lucide-react';

const AppContent: React.FC = () => {
  const { activeViewMode, isDarkMode } = useApp();

  return (
    <div className={`min-h-screen flex flex-col font-sans transition-colors ${isDarkMode ? 'dark bg-slate-950 text-slate-100' : 'bg-slate-100 text-slate-900'}`}>
      {/* Top Header */}
      <Header />

      {/* Main Workspace Area */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Split Live Sync View (Mobile App + Admin Dashboard side-by-side) */}
        {activeViewMode === 'split' && (
          <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
            {/* Left Column: Student Mobile Chassis */}
            <div className="w-full lg:w-[480px] xl:w-[500px] border-b lg:border-b-0 lg:border-r border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-950 p-2 sm:p-4 overflow-y-auto flex flex-col items-center justify-start shrink-0">
              <div className="w-full max-w-[420px] mb-2 flex items-center justify-between text-xs font-bold text-slate-600 dark:text-slate-400 px-2">
                <span className="flex items-center gap-1.5 text-sky-600 dark:text-sky-400">
                  <Smartphone className="w-4 h-4" />
                  <span>ছাত্র অ্যান্ড্রয়েড অ্যাপ (Flutter)</span>
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 font-semibold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span>Real-time Live Sync</span>
                </span>
              </div>
              <StudentAppSimulator isSplitView={true} />
            </div>

            {/* Right Column: Web Admin Dashboard */}
            <div className="flex-1 flex flex-col overflow-y-auto bg-slate-100 dark:bg-slate-950">
              <AdminDashboard isSplitView={true} />
            </div>
          </div>
        )}

        {/* Student Mobile App Simulator Alone */}
        {activeViewMode === 'student' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-8 flex flex-col items-center justify-center bg-slate-200/60 dark:bg-slate-950">
            <StudentAppSimulator isSplitView={false} />
          </div>
        )}

        {/* Admin Dashboard Alone */}
        {activeViewMode === 'admin' && (
          <div className="flex-1 flex flex-col overflow-hidden">
            <AdminDashboard isSplitView={false} />
          </div>
        )}

        {/* Flutter & Firebase Production Code Hub */}
        {activeViewMode === 'code' && (
          <div className="flex-1 flex flex-col overflow-hidden">
            <CodeExportHub />
          </div>
        )}
      </main>

      {/* Global Toast Notifications */}
      <Toaster />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
