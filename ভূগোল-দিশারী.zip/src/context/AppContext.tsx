import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  BannerItem,
  RecordingClass,
  ClassNotesSection,
  ChapterNote,
  NoticeItem,
  CourseItem,
  FeePaymentRecord,
  StudentUser,
  StudentAttendance,
  AdminUser,
  PaymentSettings,
} from '../types';
import {
  INITIAL_BANNERS,
  INITIAL_RECORDINGS,
  INITIAL_CLASS_NOTES,
  INITIAL_NOTICES,
  INITIAL_COURSES,
  INITIAL_STUDENT_USER,
  INITIAL_STUDENT_ROSTER,
  INITIAL_FEE_PAYMENTS,
  INITIAL_ATTENDANCE,
  INITIAL_PAYMENT_SETTINGS,
} from '../data/initialData';

interface ToastData {
  id: string;
  title: string;
  body: string;
  type: 'info' | 'success' | 'warning' | 'error';
}

interface AppContextType {
  // Mode & Theme
  activeViewMode: 'student' | 'admin' | 'split' | 'code';
  setActiveViewMode: (mode: 'student' | 'admin' | 'split' | 'code') => void;
  isDarkMode: boolean;
  setIsDarkMode: (val: boolean | ((prev: boolean) => boolean)) => void;

  // Real-time synchronization indicator
  lastSyncTimestamp: number;
  triggerSyncPulse: (actionDescription?: string) => void;

  // Toast / In-app notification
  toasts: ToastData[];
  showToast: (title: string, body: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
  dismissToast: (id: string) => void;

  // Users & Auth
  currentStudent: StudentUser;
  setCurrentStudent: React.Dispatch<React.SetStateAction<StudentUser>>;
  studentRoster: StudentUser[];
  addStudent: (student: Omit<StudentUser, 'id'>) => StudentUser;
  updateStudent: (studentId: string, updates: Partial<StudentUser>) => void;
  deleteStudent: (studentId: string) => void;
  archiveStudent: (studentId: string) => void;
  restoreStudent: (studentId: string) => void;
  toggleStudentPaidMonth: (studentId: string, month: string) => void;
  adminUser: AdminUser | null;
  adminLogin: (adminId: string, pass: string) => boolean;
  adminLogout: () => void;
  studentLogout: () => void;
  studentLoginPhone: (phone: string) => boolean;

  // Banners
  banners: BannerItem[];
  addBanner: (banner: Omit<BannerItem, 'id' | 'order'>) => void;
  updateBanner: (id: string, updates: Partial<BannerItem>) => void;
  deleteBanner: (id: string) => void;

  // Recording Classes
  recordings: RecordingClass[];
  addRecording: (rec: Omit<RecordingClass, 'id' | 'viewsCount' | 'dateAdded'>) => void;
  updateRecording: (id: string, updates: Partial<RecordingClass>) => void;
  deleteRecording: (id: string) => void;

  // Notes (PDF) & Security 4-Digit Codes
  classNotes: ClassNotesSection[];
  updateSecurityCode: (classId: string, newCode: string) => void;
  addChapterNote: (classId: string, note: Omit<ChapterNote, 'id' | 'dateUploaded'>) => void;
  updateChapterNote: (classId: string, noteId: string, updates: Partial<ChapterNote>) => void;
  deleteChapterNote: (classId: string, noteId: string) => void;

  // Notices
  notices: NoticeItem[];
  addNotice: (notice: Omit<NoticeItem, 'id' | 'date' | 'read'>) => void;
  deleteNotice: (id: string) => void;

  // Courses
  courses: CourseItem[];
  enrollInCourse: (courseId: string) => void;

  // Fee Payments & Settings
  feePayments: FeePaymentRecord[];
  submitFeePayment: (record: Omit<FeePaymentRecord, 'id' | 'submittedAt' | 'status'>) => void;
  approvePayment: (paymentId: string, reviewerName?: string) => void;
  rejectPayment: (paymentId: string, reason: string) => void;
  paymentSettings: PaymentSettings;
  updatePaymentSettings: (settings: Partial<PaymentSettings>) => void;
  resetPaymentSettings: () => void;

  // Attendance
  attendance: StudentAttendance[];
  setStudentAttendance: (studentId: string, status: 'PRESENT' | 'ABSENT' | 'LATE', remarks?: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeViewMode, setActiveViewMode] = useState<'student' | 'admin' | 'split' | 'code'>('split');
  const [isDarkMode, setIsDarkMode] = useState<boolean>(false);
  const [lastSyncTimestamp, setLastSyncTimestamp] = useState<number>(Date.now());
  const [toasts, setToasts] = useState<ToastData[]>([]);

  // State slices loaded from localStorage or initial
  const [currentStudent, setCurrentStudent] = useState<StudentUser>(() => {
    const saved = localStorage.getItem('bd_student_user');
    return saved ? JSON.parse(saved) : INITIAL_STUDENT_USER;
  });

  const [studentRoster, setStudentRoster] = useState<StudentUser[]>(() => {
    const saved = localStorage.getItem('bd_student_roster');
    return saved ? JSON.parse(saved) : INITIAL_STUDENT_ROSTER;
  });

  const [adminUser, setAdminUser] = useState<AdminUser | null>(() => {
    const saved = localStorage.getItem('bd_admin_user');
    return saved ? JSON.parse(saved) : {
      adminId: 'narayan_sir',
      name: 'Narayan Sir (নারায়ণ স্যার)',
      email: 'narayansir.bhugol@gmail.com',
      role: 'SUPER_ADMIN',
      token: 'admin_session_auth_token_live',
    };
  });

  const [banners, setBanners] = useState<BannerItem[]>(() => {
    const saved = localStorage.getItem('bd_banners');
    return saved ? JSON.parse(saved) : INITIAL_BANNERS;
  });

  const [recordings, setRecordings] = useState<RecordingClass[]>(() => {
    const saved = localStorage.getItem('bd_recordings');
    return saved ? JSON.parse(saved) : INITIAL_RECORDINGS;
  });

  const [classNotes, setClassNotes] = useState<ClassNotesSection[]>(() => {
    const saved = localStorage.getItem('bd_class_notes');
    return saved ? JSON.parse(saved) : INITIAL_CLASS_NOTES;
  });

  const [notices, setNotices] = useState<NoticeItem[]>(() => {
    const saved = localStorage.getItem('bd_notices');
    return saved ? JSON.parse(saved) : INITIAL_NOTICES;
  });

  const [courses, setCourses] = useState<CourseItem[]>(() => {
    const saved = localStorage.getItem('bd_courses');
    return saved ? JSON.parse(saved) : INITIAL_COURSES;
  });

  const [feePayments, setFeePayments] = useState<FeePaymentRecord[]>(() => {
    const saved = localStorage.getItem('bd_fee_payments');
    return saved ? JSON.parse(saved) : INITIAL_FEE_PAYMENTS;
  });

  const [attendance, setAttendance] = useState<StudentAttendance[]>(() => {
    const saved = localStorage.getItem('bd_attendance');
    return saved ? JSON.parse(saved) : INITIAL_ATTENDANCE;
  });

  const [paymentSettings, setPaymentSettings] = useState<PaymentSettings>(() => {
    const saved = localStorage.getItem('bd_payment_settings');
    if (!saved) return INITIAL_PAYMENT_SETTINGS;
    try {
      const parsed = JSON.parse(saved);
      return {
        ...INITIAL_PAYMENT_SETTINGS,
        ...parsed,
        autoReminder: {
          ...INITIAL_PAYMENT_SETTINGS.autoReminder,
          ...(parsed.autoReminder || {}),
        },
      };
    } catch {
      return INITIAL_PAYMENT_SETTINGS;
    }
  });

  // Local storage persistence
  useEffect(() => {
    localStorage.setItem('bd_banners', JSON.stringify(banners));
  }, [banners]);

  useEffect(() => {
    localStorage.setItem('bd_recordings', JSON.stringify(recordings));
  }, [recordings]);

  useEffect(() => {
    localStorage.setItem('bd_class_notes', JSON.stringify(classNotes));
  }, [classNotes]);

  useEffect(() => {
    localStorage.setItem('bd_notices', JSON.stringify(notices));
  }, [notices]);

  useEffect(() => {
    localStorage.setItem('bd_fee_payments', JSON.stringify(feePayments));
  }, [feePayments]);

  useEffect(() => {
    localStorage.setItem('bd_attendance', JSON.stringify(attendance));
  }, [attendance]);

  useEffect(() => {
    localStorage.setItem('bd_student_user', JSON.stringify(currentStudent));
  }, [currentStudent]);

  useEffect(() => {
    localStorage.setItem('bd_payment_settings', JSON.stringify(paymentSettings));
  }, [paymentSettings]);

  useEffect(() => {
    localStorage.setItem('bd_student_roster', JSON.stringify(studentRoster));
  }, [studentRoster]);

  const showToast = (title: string, body: string, type: 'info' | 'success' | 'warning' | 'error' = 'info') => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    setToasts((prev) => [...prev, { id, title, body, type }]);
    setTimeout(() => {
      dismissToast(id);
    }, 4500);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const triggerSyncPulse = (actionDescription?: string) => {
    setLastSyncTimestamp(Date.now());
    if (actionDescription) {
      showToast('Firebase Firestore Sync', actionDescription, 'success');
    }
  };

  // Auth operations
  const adminLogin = (adminId: string, pass: string): boolean => {
    if (adminId.trim().toLowerCase() === 'narayan' || adminId.trim().toLowerCase() === 'admin') {
      const user: AdminUser = {
        adminId: 'narayan_sir',
        name: 'Narayan Sir (নারায়ণ স্যার)',
        email: 'narayansir.bhugol@gmail.com',
        role: 'SUPER_ADMIN',
        token: `auth_${Date.now()}`,
      };
      setAdminUser(user);
      localStorage.setItem('bd_admin_user', JSON.stringify(user));
      showToast('লগইন সফল', 'অ্যাডমিন ড্যাশবোর্ডে স্বাগতম নারায়ণ স্যার!', 'success');
      return true;
    }
    showToast('লগইন ত্রুটি', 'সঠিক অ্যাডমিন আইডি ও পাসওয়ার্ড লিখুন (ডেমো: admin / narayan)', 'error');
    return false;
  };

  const adminLogout = () => {
    setAdminUser(null);
    localStorage.removeItem('bd_admin_user');
    showToast('লগআউট', 'অ্যাডমিন অ্যাকাউন্ট লগআউট হয়েছে', 'info');
  };

  const studentLogout = () => {
    showToast('লগআউট', 'ছাত্র অ্যাকাউন্ট লগআউট হয়েছে', 'info');
  };

  const studentLoginPhone = (phone: string): boolean => {
    if (phone.length >= 10) {
      showToast('ওটিপি যাচাই সম্পন্ন', 'ভূগোল দিশারী ছাত্র অ্যাপে স্বাগতম!', 'success');
      return true;
    }
    showToast('ভুল ফোন নম্বর', '১০ ডিজিটের বৈধ মোবাইল নম্বর লিখুন', 'warning');
    return false;
  };

  // Banner CRUD
  const addBanner = (banner: Omit<BannerItem, 'id' | 'order'>) => {
    const newBanner: BannerItem = {
      ...banner,
      id: `banner-${Date.now()}`,
      order: banners.length + 1,
    };
    setBanners((prev) => [...prev.slice(0, 4), newBanner]); // Keep up to 5
    triggerSyncPulse('নতুন ব্যানার ছাত্র অ্যাপে সিঙ্ক হয়েছে');
  };

  const updateBanner = (id: string, updates: Partial<BannerItem>) => {
    setBanners((prev) => prev.map((b) => (b.id === id ? { ...b, ...updates } : b)));
    triggerSyncPulse('ব্যানার সফলভাবে আপডেট হয়েছে');
  };

  const deleteBanner = (id: string) => {
    setBanners((prev) => prev.filter((b) => b.id !== id));
    triggerSyncPulse('ব্যানার মুছে ফেলা হয়েছে');
  };

  // Recording Class CRUD
  const addRecording = (rec: Omit<RecordingClass, 'id' | 'viewsCount' | 'dateAdded'>) => {
    const newRec: RecordingClass = {
      ...rec,
      id: `rec-${Date.now()}`,
      viewsCount: 0,
      dateAdded: new Date().toISOString().split('T')[0],
    };
    setRecordings((prev) => [newRec, ...prev]);
    triggerSyncPulse(`রেকর্ডিং ক্লাস "${rec.title.slice(0, 24)}..." যুক্ত হয়েছে`);
  };

  const updateRecording = (id: string, updates: Partial<RecordingClass>) => {
    setRecordings((prev) => prev.map((r) => (r.id === id ? { ...r, ...updates } : r)));
    triggerSyncPulse('রেকর্ডিং ক্লাস আপডেট হয়েছে');
  };

  const deleteRecording = (id: string) => {
    setRecordings((prev) => prev.filter((r) => r.id !== id));
    triggerSyncPulse('রেকর্ডিং ক্লাস ডিলিট করা হয়েছে');
  };

  // Notes & 4-Digit Security Code
  const updateSecurityCode = (classId: string, newCode: string) => {
    setClassNotes((prev) =>
      prev.map((section) =>
        section.id === classId || section.classLevel === classId
          ? { ...section, securityCode: newCode }
          : section
      )
    );
    triggerSyncPulse(`${classId} এর জন্য নতুন ৪ ডিজিটের নিরাপত্তা কোড সেট হয়েছে: ${newCode}`);
  };

  const addChapterNote = (classId: string, note: any) => {
    const newNote = {
      ...note,
      id: `ch-${Date.now()}`,
      dateUploaded: new Date().toISOString().split('T')[0],
    };
    setClassNotes((prev) =>
      prev.map((sec) =>
        sec.id === classId || sec.classLevel === classId
          ? { ...sec, chapters: [...sec.chapters, newNote], totalNotes: sec.chapters.length + 1 }
          : sec
      )
    );
    triggerSyncPulse(`অধ্যায় "${note.chapterName.slice(0, 20)}..." নোটস যুক্ত হয়েছে`);
  };

  const updateChapterNote = (classId: string, noteId: string, updates: any) => {
    setClassNotes((prev) =>
      prev.map((sec) => {
        if (sec.id === classId || sec.classLevel === classId) {
          return {
            ...sec,
            chapters: sec.chapters.map((ch) => (ch.id === noteId ? { ...ch, ...updates } : ch)),
          };
        }
        return sec;
      })
    );
    triggerSyncPulse('নোটস ও গুগল ড্রাইভ লিঙ্ক আপডেট হয়েছে');
  };

  const deleteChapterNote = (classId: string, noteId: string) => {
    setClassNotes((prev) =>
      prev.map((sec) => {
        if (sec.id === classId || sec.classLevel === classId) {
          const filtered = sec.chapters.filter((ch) => ch.id !== noteId);
          return {
            ...sec,
            chapters: filtered,
            totalNotes: filtered.length,
          };
        }
        return sec;
      })
    );
    triggerSyncPulse('নোটস মুছে ফেলা হয়েছে');
  };

  // Notices
  const addNotice = (notice: Omit<NoticeItem, 'id' | 'date' | 'read'>) => {
    const now = new Date();
    const formattedDate = `${now.getDate()} ${now.toLocaleString('en-US', { month: 'short' })} ${now.getFullYear()}, ${now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}`;
    const newNotice: NoticeItem = {
      ...notice,
      id: `notice-${Date.now()}`,
      date: formattedDate,
      read: false,
    };
    setNotices((prev) => [newNotice, ...prev]);
    triggerSyncPulse('নতুন বিজ্ঞপ্তি পুশ করা হয়েছে (FCM Alert)');
  };

  const deleteNotice = (id: string) => {
    setNotices((prev) => prev.filter((n) => n.id !== id));
    triggerSyncPulse('বিজ্ঞপ্তি মুছে ফেলা হয়েছে');
  };

  // Courses
  const enrollInCourse = (courseId: string) => {
    setCourses((prev) =>
      prev.map((c) => (c.id === courseId ? { ...c, isEnrolled: true } : c))
    );
    setCurrentStudent((prev) => ({
      ...prev,
      enrolledCourseIds: [...new Set([...prev.enrolledCourseIds, courseId])],
    }));
    showToast('কোর্স সফলভাবে রেজিস্টার হয়েছে', 'আপনি এখন সমস্ত লাইভ ও রেকর্ডিং দেখতে পারবেন', 'success');
  };

  // Fee payments
  const submitFeePayment = (record: Omit<FeePaymentRecord, 'id' | 'submittedAt' | 'status'>) => {
    const now = new Date();
    const formattedDate = `${now.toISOString().split('T')[0]} ${now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}`;
    const newRecord: FeePaymentRecord = {
      ...record,
      id: `pay-${Date.now()}`,
      submittedAt: formattedDate,
      status: 'PENDING',
    };
    setFeePayments((prev) => [newRecord, ...prev]);
    triggerSyncPulse('ফি পেমেন্ট UTR জমা পড়েছে - অ্যাডমিন ভেরিফিকেশন অপেক্ষমাণ');
  };

  const approvePayment = (paymentId: string, reviewerName = 'Narayan Sir (Admin)') => {
    const now = new Date();
    const formattedTime = `${now.toISOString().split('T')[0]} ${now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}`;
    setFeePayments((prev) =>
      prev.map((p) =>
        p.id === paymentId
          ? {
              ...p,
              status: 'APPROVED',
              verifiedBy: reviewerName,
              verifiedAt: formattedTime,
            }
          : p
      )
    );
    triggerSyncPulse(`পেমেন্ট অনুমোদিত হয়েছে (UTR: ${paymentId})`);
  };

  const rejectPayment = (paymentId: string, reason: string) => {
    const now = new Date();
    const formattedTime = `${now.toISOString().split('T')[0]} ${now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}`;
    setFeePayments((prev) =>
      prev.map((p) =>
        p.id === paymentId
          ? {
              ...p,
              status: 'REJECTED',
              rejectionReason: reason || 'UTR বা স্ক্রিনশট মেলেনি',
              verifiedBy: 'Narayan Sir (Admin)',
              verifiedAt: formattedTime,
            }
          : p
      )
    );
    triggerSyncPulse(`পেমেন্ট বাতিল করা হয়েছে`);
  };

  // Attendance
  const setStudentAttendance = (studentId: string, status: 'PRESENT' | 'ABSENT' | 'LATE', remarks?: string) => {
    const today = new Date().toISOString().split('T')[0];
    setAttendance((prev) => {
      const existingIdx = prev.findIndex((a) => a.studentId === studentId && a.date === today);
      if (existingIdx >= 0) {
        const copy = [...prev];
        copy[existingIdx] = { ...copy[existingIdx], status, remarks };
        return copy;
      }
      const rosterStudent = studentRoster.find((s) => s.id === studentId);
      const newAtt: StudentAttendance = {
        id: `att-${Date.now()}`,
        studentId,
        studentName: rosterStudent?.name || 'Student',
        studentRoll: rosterStudent?.rollNumber || 'BD-000',
        classLevel: rosterStudent?.classLevel || 'Class 10',
        date: today,
        status,
        remarks,
      };
      return [...prev, newAtt];
    });
    triggerSyncPulse('উপস্থিতির তথ্য আপডেট হয়েছে');
  };

  // Payment UPI & Scanner Settings methods
  const updatePaymentSettings = (updates: Partial<PaymentSettings>) => {
    setPaymentSettings((prev) => {
      const updated: PaymentSettings = {
        ...prev,
        ...updates,
        updatedAt: new Date().toLocaleString('en-US', {
          day: 'numeric',
          month: 'short',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
          hour12: true,
        }),
        updatedBy: adminUser?.name || 'Narayan Sir (Super Admin)',
      };
      return updated;
    });
    triggerSyncPulse('ফি পেমেন্ট UPI আইডি ও স্ক্যানার সফলভাবে আপডেট করা হয়েছে');
  };

  const resetPaymentSettings = () => {
    setPaymentSettings(INITIAL_PAYMENT_SETTINGS);
    triggerSyncPulse('UPI আইডি ও স্ক্যানার ডিফল্ট মানে রিসেট করা হয়েছে');
  };

  // Student Management Operations
  const addStudent = (studentData: Omit<StudentUser, 'id'>): StudentUser => {
    const newId = `std-${Date.now()}`;
    const newStudent: StudentUser = {
      ...studentData,
      id: newId,
      status: studentData.status || 'ACTIVE',
      paidMonths: studentData.paidMonths || [],
      attendancePercentage: studentData.attendancePercentage ?? 95,
      avatarUrl:
        studentData.avatarUrl ||
        `https://images.unsplash.com/photo-${1535713875002 + Math.floor(Math.random() * 1000)}?auto=format&fit=crop&w=300&q=80`,
      organizationCode: studentData.organizationCode || 'WZKHLU',
      enrolledCourseIds: studentData.enrolledCourseIds || ['c-madhyamik'],
      joinDate:
        studentData.joinDate ||
        new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }),
      admissionDate: studentData.admissionDate || new Date().toISOString().split('T')[0],
    };

    setStudentRoster((prev) => [newStudent, ...prev]);
    triggerSyncPulse(`নতুন শিক্ষার্থী "${newStudent.name}" (${newStudent.classLevel}) যুক্ত করা হয়েছে`);
    return newStudent;
  };

  const updateStudent = (studentId: string, updates: Partial<StudentUser>) => {
    setStudentRoster((prev) =>
      prev.map((s) => {
        if (s.id === studentId) {
          const updated = { ...s, ...updates };
          // If editing currently active student in mobile preview, also sync currentStudent
          if (currentStudent.id === studentId) {
            setCurrentStudent(updated);
          }
          return updated;
        }
        return s;
      })
    );
    triggerSyncPulse(`শিক্ষার্থীর তথ্য সফলভাবে আপডেট করা হয়েছে`);
  };

  const deleteStudent = (studentId: string) => {
    setStudentRoster((prev) => {
      const target = prev.find((s) => s.id === studentId);
      const filtered = prev.filter((s) => s.id !== studentId);
      triggerSyncPulse(`শিক্ষার্থী "${target?.name || ''}" তালিকা থেকে অপসারণ করা হয়েছে`);
      return filtered;
    });
  };

  const archiveStudent = (studentId: string) => {
    setStudentRoster((prev) =>
      prev.map((s) => (s.id === studentId ? { ...s, status: 'ARCHIVED' } : s))
    );
    triggerSyncPulse('শিক্ষার্থীকে আর্কাইভ / উত্তীর্ণ তালিকায় স্থানান্তর করা হয়েছে');
  };

  const restoreStudent = (studentId: string) => {
    setStudentRoster((prev) =>
      prev.map((s) => (s.id === studentId ? { ...s, status: 'ACTIVE' } : s))
    );
    triggerSyncPulse('শিক্ষার্থীকে সক্রিয় তালিকায় পুনরুদ্ধার করা হয়েছে');
  };

  const toggleStudentPaidMonth = (studentId: string, month: string) => {
    setStudentRoster((prev) =>
      prev.map((s) => {
        if (s.id === studentId) {
          const currentMonths = s.paidMonths || [];
          const exists = currentMonths.some(
            (m) => m.toLowerCase().trim() === month.toLowerCase().trim()
          );
          const updatedMonths = exists
            ? currentMonths.filter((m) => m.toLowerCase().trim() !== month.toLowerCase().trim())
            : [...currentMonths, month];

          const updatedStudent = { ...s, paidMonths: updatedMonths };
          if (currentStudent.id === studentId) {
            setCurrentStudent(updatedStudent);
          }
          return updatedStudent;
        }
        return s;
      })
    );
    triggerSyncPulse(`ফি পরিশোধের মাস আপডেট করা হয়েছে (${month})`);
  };

  return (
    <AppContext.Provider
      value={{
        activeViewMode,
        setActiveViewMode,
        isDarkMode,
        setIsDarkMode,
        lastSyncTimestamp,
        triggerSyncPulse,
        toasts,
        showToast,
        dismissToast,
        currentStudent,
        setCurrentStudent,
        studentRoster,
        addStudent,
        updateStudent,
        deleteStudent,
        archiveStudent,
        restoreStudent,
        toggleStudentPaidMonth,
        adminUser,
        adminLogin,
        adminLogout,
        studentLogout,
        studentLoginPhone,
        banners,
        addBanner,
        updateBanner,
        deleteBanner,
        recordings,
        addRecording,
        updateRecording,
        deleteRecording,
        classNotes,
        updateSecurityCode,
        addChapterNote,
        updateChapterNote,
        deleteChapterNote,
        notices,
        addNotice,
        deleteNotice,
        courses,
        enrollInCourse,
        feePayments,
        submitFeePayment,
        approvePayment,
        rejectPayment,
        attendance,
        setStudentAttendance,
        paymentSettings,
        updatePaymentSettings,
        resetPaymentSettings,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
